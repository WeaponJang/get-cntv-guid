```

███╗   ██╗        ███╗   ███╗██████╗ ██╗   ██╗ █████╗ ██████╗ ██╗       ██████╗██╗     ██╗
████╗  ██║        ████╗ ████║╚════██╗██║   ██║██╔══██╗██╔══██╗██║      ██╔════╝██║     ██║
██╔██╗ ██║        ██╔████╔██║ █████╔╝██║   ██║╚█████╔╝██║  ██║██║█████╗██║     ██║     ██║
██║╚██╗██║        ██║╚██╔╝██║ ╚═══██╗██║   ██║██╔══██╗██║  ██║██║╚════╝██║     ██║     ██║
██║ ╚████║███████╗██║ ╚═╝ ██║██████╔╝╚██████╔╝╚█████╔╝██████╔╝███████╗ ╚██████╗███████╗██║
╚═╝  ╚═══╝╚══════╝╚═╝     ╚═╝╚═════╝  ╚═════╝  ╚════╝ ╚═════╝ ╚══════╝  ╚═════╝╚══════╝╚═╝

```
---
[![img](https://img.shields.io/github/stars/nilaoda/N_m3u8DL-CLI?label=%E7%82%B9%E8%B5%9E)](https://github.com/nilaoda/N_m3u8DL-CLI)  [![img](https://img.shields.io/github/last-commit/nilaoda/N_m3u8DL-CLI?label=%E6%9C%80%E8%BF%91%E6%8F%90%E4%BA%A4)](https://github.com/nilaoda/N_m3u8DL-CLI)  [![img](https://img.shields.io/github/release/nilaoda/N_m3u8DL-CLI?label=%E6%9C%80%E6%96%B0%E7%89%88%E6%9C%AC)](https://github.com/nilaoda/N_m3u8DL-CLI/releases)  [![img](https://img.shields.io/github/license/nilaoda/N_m3u8DL-CLI?label=%E8%AE%B8%E5%8F%AF%E8%AF%81)](https://github.com/nilaoda/N_m3u8DL-CLI)  [![img](https://img.shields.io/badge/URL-%E7%94%A8%E6%88%B7%E6%96%87%E6%A1%A3-blue)](https://nilaoda.github.io/N_m3u8DL-CLI/)


# 关于本仓库（.NET 8 移植版）

本仓库是 [nilaoda/N_m3u8DL-CLI](https://github.com/nilaoda/N_m3u8DL-CLI) 的 **.NET 8 (LTS) 移植版**，命令行行为与原有功能保持不变。

| 项目 | 现状 |
|---|---|
| 目标框架 | `net8.0-windows`（用到注册表、UAC 提权、win32 控制台 API，仍面向 Windows） |
| 工程格式 | SDK 风格 `csproj` + `PackageReference`（原 `packages.config` / Costura.Fody 已移除） |
| 依赖包 | CommandLineParser 2.9.1、Newtonsoft.Json 13.0.3、NiL.JS 2.5.1428、HttpToSocks5Proxy 1.4.0 |
| 单文件发布 | 推荐产物 `publish\N_m3u8DL-CLI.exe`，自带 .NET 8 运行时，**约 13.9 MB 单个 exe**，免安装 |
| 与上游代码差异 | 仅 6 处，详见 [MIGRATION.md](MIGRATION.md) |
| 界面语言 | Debug / 常规构建按系统语言自动切换简/繁/英；推荐的 Release 单文件配置关闭了全球化数据，固定为简体中文（见 MIGRATION.md 5.3，删掉 `InvariantGlobalization` 即可恢复多语言） |

# [ENGLISH VERSION](https://github.com/nilaoda/N_m3u8DL-CLI/blob/master/README_ENG.md)（上游英文版）

# 下载使用
* 自行构建/发布：见下方「[构建与发布](#构建与发布)」或 [MIGRATION.md](MIGRATION.md)
* 原版（.NET Framework 4.6）发行版: https://github.com/nilaoda/N_m3u8DL-CLI/releases
* 原版自动构建版`(供测试)`: https://github.com/nilaoda/N_m3u8DL-CLI/actions

# 关于开源
本项目已于2019年10月9日开源，采用MIT许可证，各取所需。

# 关于跨平台
* N_m3u8DL-CLI `(本项目)`: 已升级到 .NET 8，但因使用 Windows 专属 API（注册表 / UAC / win32 控制台），**仍只支持 Windows**。

* [N_m3u8DL-RE](https://github.com/nilaoda/N_m3u8DL-RE) : 抛弃历史包袱从零做起, 支持Win/Linux/Mac, 更丰富的功能会在这里出现 ...

# N_m3u8DL-CLI
一个**简单易用的**m3u8下载器。本仓库为 .NET 8 移植版，构建方式见上方「构建与发布」；如需原版（.NET Framework 4.6）成品，请前往 https://github.com/nilaoda/N_m3u8DL-CLI/releases

支持下载m3u8链接或文件为`mp4`或`ts`格式，并提供丰富的命令行选项。
  * **不支持**优酷视频 DRM 解密（但可自动跳过优酷广告分片）
  * **不支持**气球云（yunc.163.com）视频解密
  * 支持`AES-128-CBC`加密自动解密，支持自定义 KEY/IV（`--useKeyFile` / `--useKeyBase64` / `--useKeyIV`）
  * 支持 ChaCha20 解密（`--enableChaCha20`）
  * 支持多线程下载 / 下载限速 / 断点续传
  * 支持`Master List`（自动选择最高码率，也可手动选择播放列表）
  * 支持 `#EXT-X-MAP`（fMP4）、`#EXT-X-BYTERANGE`、`#EXT-X-DISCONTINUITY`、`#EXT-X-PROGRAM-DATE-TIME`
  * 支持 MPEG-DASH（`<MPD>`）地址，自动转换为分片列表下载
  * 支持爱奇艺 DRM-JSON（`{"payload":...}`）自动转换为 m3u8
  * 内置站点专用 key 解密：51CTO、Cdeledu、虎课网、IMOOC、Nfmovies、ddYun 等
  * 支持直播流录制(`BETA`，可用 `--liveRecDur` 限制录制时长)
  * 支持自定义`HTTP Headers`（`--headers`，或程序目录下的 `headers.txt`）
  * 支持自动合并 (二进制合并或使用ffmpeg合并)、FastStart
  * 支持选择下载`m3u8`中的指定时间段/分片内容（`--downloadRange`）
  * 支持下载路径为网络驱动器的情况
  * 支持下载外挂字幕轨道、音频轨道，或仅合并音频（`--enableAudioOnly`）
  * 支持设置 HTTP/SOCKS5 代理（`--proxyAddress`）
  * 支持自动使用系统代理（默认行为, 可禁止 `--noProxy`）
  * 支持m3u8dl链接协议（通过web链接调用本机客户端，需管理员权限注册）
  * 启动时自动检测新版本（程序目录放 `NO_UPDATE` 文件可关闭）
  * SimpleG 图形界面**不在本仓库**（原项目中为独立工程）



![运行截图](https://nilaoda.github.io/N_m3u8DL-CLI/source/images/%E7%9B%B4%E6%8E%A5%E4%BD%BF%E7%94%A8.gif)

# 构建与发布

需要 [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)（Windows 上推荐 VS2022 17.8+）。最小编译配置已预先写入 `N_m3u8DL-CLI.csproj` 的 Release 属性组。

```bash
# 日常编译
dotnet build -c Release

# 单文件 + 自包含运行时（推荐：约 13.9 MB，目标机无需安装任何运行时）
dotnet publish -c Release -r win-x64 --self-contained true -o publish

# 依赖框架的单文件（体积更小，目标机需装 .NET 8 运行时）
dotnet publish -c Release -r win-x64 --self-contained false -o publish-fx
```

运行时依赖：**ffmpeg**（放在程序目录、当前工作目录或 PATH 中均可），用于分片合并；找不到时程序会提示下载地址并退出。

体积优化开关（压缩、裁剪、`InvariantGlobalization` 等）与各自的代价详见 [MIGRATION.md 第五节](MIGRATION.md)。

常用示例：

```bash
# 最简用法（默认保存到当前目录的 Downloads）
N_m3u8DL-CLI.exe "https://example.com/video.m3u8"

# 指定目录/文件名，只下载第 0~9 个分片
N_m3u8DL-CLI.exe "https://example.com/video.m3u8" --workDir "%USERPROFILE%\Downloads" --saveName demo --downloadRange 0-9

# 仅解析，不下载（只生成 meta.json）
N_m3u8DL-CLI.exe "https://example.com/video.m3u8" --enableParseOnly
```

# 命令行选项
```
N_m3u8DL-CLI

USAGE:

  N_m3u8DL-CLI <URL|JSON|FILE> [OPTIONS]

OPTIONS:

  --workDir                  设定程序工作目录
  --saveName                 设定存储文件名(不包括后缀)
  --baseUrl                  设定Baseurl
  --headers                  设定请求头，格式 key:value 使用|分割不同的key&value
  --maxThreads               (Default: 32) 设定程序的最大线程数
  --minThreads               (Default: 16) 设定程序的最小线程数
  --retryCount               (Default: 15) 设定程序的重试次数
  --timeOut                  (Default: 10) 设定程序网络请求的超时时间(单位为秒)
  --muxSetJson               使用外部json文件定义混流选项
  --useKeyFile               使用外部16字节文件定义AES-128解密KEY
  --useKeyBase64             使用Base64字符串定义AES-128解密KEY
  --useKeyIV                 使用HEX字符串定义AES-128解密IV
  --downloadRange            仅下载视频的一部分分片或长度
  --liveRecDur               直播录制时，达到此长度自动退出软件(HH:MM:SS)
  --stopSpeed                当速度低于此值时，重试(单位为KB/s)
  --maxSpeed                 设置下载速度上限(单位为KB/s)
  --proxyAddress             设置HTTP/SOCKS5代理, 如 http://127.0.0.1:8080
  --enableDelAfterDone       开启下载后删除临时文件夹的功能
  --enableMuxFastStart       开启混流mp4的FastStart特性
  --enableBinaryMerge        开启二进制合并分片
  --enableParseOnly          开启仅解析模式(程序只进行到meta.json)
  --enableAudioOnly          合并时仅封装音频轨道
  --disableDateInfo          关闭混流中的日期写入
  --disableIntegrityCheck    不检测分片数量是否完整
  --noMerge                  禁用自动合并
  --noProxy                  不自动使用系统代理
  --registerUrlProtocol      注册m3u8dl链接协议
  --unregisterUrlProtocol    取消注册m3u8dl链接协议
  --enableChaCha20           enableChaCha20
  --chaCha20KeyBase64        ChaCha20KeyBase64
  --chaCha20NonceBase64      ChaCha20NonceBase64
  --help                     Display this help screen.
  --version                  Display version information.
```

# 关于`m3u8dl://`协议
新增命令行参数：
```
--registerUrlProtocol          注册m3u8dl链接协议
--unregisterUrlProtocol     取消注册m3u8dl链接协议
```

URI格式：
```
m3u8dl://<base64编码的客户端命令行文本>
```

URI示例：
```
m3u8dl://Imh0dHBzOi8vZXhhbXBsZS5jb20vYWJjLm0zdTgiIC0td29ya0RpciAiJVVTRVJQUk9GSUxFJVxEb3dubG9hZHNcbTN1OGRsIiAtLXNhdmVOYW1lICJhYmMiIC0tZW5hYmxlRGVsQWZ0ZXJEb25lIC0tZGlzYWJsZURhdGVJbmZvIC0tbm9Qcm94eQ==
```

URI解码结果：
```
"https://example.com/abc.m3u8" --workDir "%USERPROFILE%\Downloads\m3u8dl" --saveName "abc" --enableDelAfterDone --disableDateInfo --noProxy
```

# 用户文档
https://nilaoda.github.io/N_m3u8DL-CLI/（上游文档，参数与本仓库一致）

# 聊聊
https://discord.gg/SSGwKrjC44

# 赞赏
![Wow](https://nilaoda.github.io/N_m3u8DL-CLI/source/images/alipay.png)
