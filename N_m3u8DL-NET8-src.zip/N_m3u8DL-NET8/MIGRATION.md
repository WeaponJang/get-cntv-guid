# N_m3u8DL-CLI — .NET 8 移植版说明

原项目 [nilaoda/N_m3u8DL-CLI](https://github.com/nilaoda/N_m3u8DL-CLI)（本仓库 Tontonnow fork 同源）基于 **.NET Framework 4.6**。本目录为移植到 **.NET 8 (LTS)** 的完整工程，保持原有功能与命令行行为不变。

## 一、结论：能不能迁移？

**可以，而且工作量很小。** 该项目主体是纯 C# 的控制台程序，对 .NET Framework 专有 API 的依赖极少，全部都有官方等价替代。真正改动的代码只有 **6 处**（合计约 65 行），其中 2 处不改会导致运行时直接不可用（TLS 设置导致启动崩溃、Uri 反射导致空引用），详见第四节。

## 二、工程层面的变化

| 项目 | 原 (.NET Framework 4.6) | 现 (.NET 8) |
|---|---|---|
| 工程格式 | 旧式 `csproj`（309 行，显式列出每个文件） | SDK 风格 `csproj`（67 行，自动包含 `*.cs`/`*.resx`，另含 Release 发布配置） |
| 包管理 | `packages.config` + `packages\` 目录 | `PackageReference` 行内引用 |
| 单文件发布 | Costura.Fody + Fody（IL 织入把 DLL 嵌入 EXE） | 官方 `PublishSingleFile` + 压缩 + 裁剪（单文件约 13.9 MB，见 5.2） |
| 版本信息 | `Properties/AssemblyInfo.cs` | `csproj` 内 `<Version>` 等属性 |
| 目标框架 | net46 | `net8.0-windows` |

> 想用 **.NET 6**：把 `N_m3u8DL-CLI.csproj` 里的 `<TargetFramework>net8.0-windows</TargetFramework>` 改成 `net6.0-windows` 即可，代码零改动（.NET 6 于 2024 年 11 月已停止支持，建议仍用 .NET 8 LTS）。

## 三、依赖包的取舍

| NuGet 包 | 处理方式 |
|---|---|
| CommandLineParser 2.8.0 | 升级到 **2.9.1**（新增 netstandard2.0 资产，API 兼容） |
| Newtonsoft.Json 13.0.1 | 升级到 **13.0.3**，原样保留 |
| NiL.JS 2.5.1428 | **原版保留**，其自带 netstandard1.6 资产，.NET 8 可直接使用 |
| HttpToSocks5Proxy 1.4.0 | **原版保留**，其自带 netstandard2.0 资产 |
| BrotliSharpLib 0.3.3 | **删除**，改用 .NET 6/8 内置的 `System.IO.Compression.BrotliStream`（`Global.cs` 中去掉了 `using BrotliSharpLib;`，调用处签名完全相同） |
| UACHelper 1.3.0.5 | **删除**，该库无 netstandard 版本；在 `Program.cs` 中用 ~30 行等价实现替代（`WindowsPrincipal` 判断管理员权限 + `ProcessStartInfo.Verb = "runas"` 提权） |
| TaskScheduler 2.8.7 | **删除**，全工程检索确认从未使用 |
| Costura.Fody / Fody / Resource.Embedder | **删除**，单文件发布由 SDK 自带的 `PublishSingleFile` 替代 |
| System.Runtime.CompilerServices.Unsafe | **删除**，.NET 8 运行时自带 |

## 四、代码修改明细（共 6 处）

1. **`Global.cs` — GetNum()**
   原 `Microsoft.JScript.GlobalObject.parseInt(str, numBase)`（JScript 引擎在 .NET Core 中不存在）→ `Convert.ToInt32(str, numBase)`。
   ⚠️ 两者并非完全等价：JScript 的 `parseInt("0x1A", 16)` 支持 `0x` 前缀，而 `Convert.ToInt32("0x1A", 16)` 会抛 `FormatException`。已确认全工程**没有任何调用点**（原代码遗留死代码），所以不影响功能；若将来要启用，需先剥离 `0x` 前缀。

2. **`Global.cs` — GetUrlFileName()**
   原 `System.Web.HttpUtility.UrlDecode`（System.Web 不再默认提供）→ `System.Net.WebUtility.UrlDecode`，`+` 转空格等行为一致。

3. **`Program.cs` — Main() 中的 TLS 设置（重要，不改会启动崩溃）**
   原代码把 `Ssl3 | Tls(1.0) | Tls11 | Tls12` 写入 `ServicePointManager.SecurityProtocol`。.NET 6/8 中写入 Ssl3/Tls1.0 会直接抛 `NotSupportedException`，程序一启动就崩。已改为 `Tls12 | Tls13`。

4. **`Program.cs` — RequireElevated()**
   UACHelper 库替换为等价的 `IsElevated()` / `StartElevated()` 内置实现（见上文表）。

5. **`Program.cs` — 单文件发布下的自身路径**
   原两处 `Assembly.GetExecutingAssembly().Location`（用于注册 URL 协议和 UAC 重启自身）在 .NET 单文件发布模式下永远返回空字符串，会导致这两个功能失效。新增 `GetExecutablePath()`，优先用 .NET 6+ 新增的 `Environment.ProcessPath`（单文件模式下也能取到真实 exe 路径）。

6. **`Parser.cs` — ForceCanonicalPathAndQuery()（重要，不改任何 m3u8 都解析不了）**
   该方法为绕过老 .NET Framework（XP）的 Uri 编码 BUG，用反射读写 `typeof(Uri)` 的私有字段 `m_Flags`。.NET Core / .NET 5+ 已修复该 BUG，且内部字段改名为 `_flags`（类型也由 `ulong` 改为 `UriFlags`），反射取 `m_Flags` 得到 `null`，紧接着 `flagsFieldInfo.GetValue(uri)` 就抛 `NullReferenceException`。而该方法被 `CombineURL()` 调用，`CombineURL()` 又是拼接分片 URL / 子播放列表 URL 的必经之路 —— 即：**原同步版本在 .NET 8 下 100% 无法解析任何 m3u8**（实测报错 `NullReferenceException at Parser.ForceCanonicalPathAndQuery`）。已改为「取不到该字段则直接 return」，在 .NET 8 上等价于 no-op，旧框架下行为不变。

另外：删除了两个 0 字节的空 Designer 文件（`strings.en-US.Designer.cs`、`strings.zh-TW.Designer.cs`）；`.resx` 多语言资源由 SDK 自动编译为附属程序集（`en-US/`、`zh-TW/` 子目录），原有按系统语言自动切换中/繁/英的机制不变（**仅限 Debug 构建或去掉 `InvariantGlobalization` 的发布包**；当前推荐的发布配置为了省 20 MB 关闭了全球化数据，界面固定为简体中文，详见 5.3）。

## 五、如何编译与发布

需要 [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)（Windows 上开发推荐 VS2022 17.8+）。

### 5.1 日常编译

```bash
dotnet build -c Release
```

### 5.2 单文件自包含发布（推荐）

最小编译配置已固化在 `N_m3u8DL-CLI.csproj` 的 Release 属性组里（`PublishSingleFile` / `EnableCompressionInSingleFile` / `IncludeNativeLibrariesForSelfExtract` / `PublishTrimmed` / `TrimMode=partial` / `DebugType=none` / `InvariantGlobalization` / `SatelliteResourceLanguages`），所以一条命令即可：

```bash
dotnet publish -c Release -r win-x64 --self-contained true -o publish
```

产物：`publish\N_m3u8DL-CLI.exe`，**单文件约 13.9 MB**，自带 .NET 8 运行时，目标机无需安装任何东西。

体积对比（同一份源码、win-x64）：

| 发布方式 | 体积 |
|---|---|
| 自包含单文件（不压缩、不裁剪） | 约 69 MB |
| + `EnableCompressionInSingleFile` | 约 35.8 MB |
| + `PublishTrimmed`(partial) | 约 **13.9 MB** |

### 5.3 体积优化选项说明

- `EnableCompressionInSingleFile`：对单文件内容压缩，约减 50%，代价是首次启动多几百毫秒解压。
- `PublishTrimmed` + `TrimMode=partial`：只裁剪运行时中标记 `IsTrimmable` 的部分，**保留** Newtonsoft.Json / NiL.JS / CommandLineParser 等依赖反射的第三方库，实测功能完好。不建议改成 `TrimMode=full`（实测体积无进一步下降，但反射裁剪风险变大）。
- `InvariantGlobalization=true`：不内置 ICU/全球化数据，省约 20 MB。**副作用**：界面固定为内置的简体中文，不再按系统语言自动切换繁中/英文；若需要多语言，删掉这一行重新发布即可（体积会增大约 20 MB）。
- `SatelliteResourceLanguages=zh-TW;en-US`：只保留这两种语言的附属程序集。
- 未开启 `PublishReadyToRun`（会显著增大体积）和 `UseSystemResourceKeys`（会丢失可读的异常消息）。

### 5.4 依赖框架的单文件发布（体积更小，但目标机需装 .NET 8 桌面运行时）

```bash
dotnet publish -c Release -r win-x64 --self-contained false -o publish-fx
```

> 目标框架为 `net8.0-windows`（程序用到注册表、UAC 提权、win32 控制台 API），仍面向 Windows。如需要跨平台版本（注册表/UAC 相关功能需按平台裁剪），可再讨论。

## 六、验证情况

### 6.1 编译

- `dotnet build -c Release`（.NET SDK 8/10，win-x64）**0 错误**；15 个警告全部为原代码固有的代码质量提示（CS0168/CS0642/CS0219/CS8981），与迁移无关。
- 仅剩 WebClient 系列的过时提示（`SYSLIB0014`，已在 csproj 中降级为不告警；功能正常，.NET 8 仍完整支持 WebClient）。

### 6.2 运行时冒烟测试（Windows + .NET 8，均实测通过）

| 测试项 | 结果 |
|---|---|
| `--version` / `--help` | 正常输出，参数表与 README 一致 |
| Master List（`test-streams.mux.dev/x36xhzz`） | 自动选择最高码率（1080p）并重新解析，`meta.json` / `master.m3u8` / `playLists.json` 均正确 |
| Media Playlist 多线程下载 + ffmpeg 合并 | 64 分片源取 `--downloadRange 0-2`，输出 mp4 经 ffprobe 校验（320x184 / h264+aac / 30s） |
| AES-128 加密流（`playertest.longtailvideo.com/.../oceans_aes`） | 自动下载 KEY 并解密，合并产物 1264x528 / h264+aac / 32.7s 可正常播放 |
| 央视源完整下载（`hls.cntv.lxdns.com/.../850.m3u8?maxbr=2048`） | 10/10 分片、10.1MB、94.46s，合并产物 640x360 / h264+aac，与 meta 时长一致 |
| `--enableDelAfterDone` / `--enableParseOnly` / `--timeOut` / `--retryCount` | 行为正常 |

### 6.3 未验证 / 待完善

- **SimpleG GUI 未随本仓库迁移**（原项目为独立工程），README 中「提供 SimpleG 简易 GUI」一项在此仓库不适用。
- 直播录制（`HLSLiveDownloader`）、`--enableChaCha20`、`--registerUrlProtocol`（需管理员写注册表）以及各站点专用解密器（`Decode51CtoKey` / `DecodeCdeledu` / `DecodeDdyun` / `DecodeHuke88Key` / `DecodeImooc` / `DecodeNfmovies`）仅做了代码级兼容性检查，未做实网验证。
- `Global.GetNum()` 注释写「支持 0x 前缀」不准确：`Convert.ToInt32("0x1A", 16)` 会抛异常（JScript `parseInt` 支持 0x 前缀）。但全工程检索确认该方法无任何调用（原代码遗留死代码），不影响功能。
- 单文件自包含发布已在本机完整验证：`publish\N_m3u8DL-CLI.exe`（约 13.9 MB）的 `--version`、Master List 解析、10 分片下载 + ffmpeg 合并均通过，合并产物与源码运行版字节级一致。
- 程序启动后会异步请求 GitHub releases 检查更新（目录放 `NO_UPDATE` 文件可关闭），无网络环境下仅多一次失败请求。

