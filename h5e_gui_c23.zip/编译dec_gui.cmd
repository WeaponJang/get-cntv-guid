@echo off
chcp 65001 >nul
cls
cd /d "%~dp0"

echo. ======== 编译脚本（dec_gui.c ^-^-^> dec_gui.exe） ==========
:: 可配置项
set "CC=gcc"
set "WRES=windres"
set "SRC=dec_gui.c"
set "RC=version.rc"
set "EXE=dec_gui.exe"
set "RES=dec_gui.res"
set "MANIFEST=dec_gui.manifest"
set "NODEF=_nodefault"

echo. 界面：Direct2D + DirectWrite 全自绘（只用 Windows 自带 DLL，无三方库）
echo. 公共编译参数：C23 / 体积优化 / 链接期裁剪未引用段 / 关闭断言
echo. GUI 专用：-municode（wWinMain 入口） -mwindows（窗口子系统，双击不弹黑框）
set "COMMON=-std=c23 -Os -s -flto -ffunction-sections -fdata-sections -Wl,--gc-sections -DNDEBUG"
set "GUIFLAGS=-municode -mwindows"
set "LIBS=-ld2d1 -ldwrite -ldxguid -lole32 -lcomdlg32 -limm32 -lshell32 -lgdi32 -luser32"
echo. 如用 clang：把 CC 设为 clang,并加 --target=x86_64-w64-windows-gnu；较旧 clang 可把 -std=c23 换成 -std=c2x
echo. 清单 %MANIFEST% 由 %RC% 以 BUILD_TARGET_GUI 嵌入：Per-Monitor V2 DPI + comctl32 v6
echo. ========================================================

if not exist "%SRC%" (echo. [ERROR] source not found: %SRC% & goto :end)

set "NOFAKE=-B./%NODEF%/"
if not exist "%NODEF%\default-manifest.o" (
    echo. MinGW-w64 的 gcc 会在 *endfile 里无条件附带 default-manifest.o（只含 longPathAware），
    echo. 与我们的清单同时存在时 ld 报 .rsrc merge failure。这里生成一个空的同名 stub 顶掉它。
    if not exist "%NODEF%" mkdir "%NODEF%"
    %CC% -c -x c -o "%NODEF%\default-manifest.o" nul || (echo. [ERROR] stub object failed & goto :end)
)

if not exist "%RC%" goto :nores
if not exist "%MANIFEST%" goto :nores

echo. ^[1^/2^] Version resource + manifest (windres, 文件名=%EXE%)
%WRES% -i "%RC%" -O coff -o "%RES%" -DNDEBUG -DBUILD_TARGET_GUI || (echo. [ERROR] windres res failed & goto :end)

echo. ^[2^/2^] Build EXE: %EXE%  (from %SRC% + version info + manifest)
%CC% %COMMON% %GUIFLAGS% %NOFAKE% -o "%EXE%" "%SRC%" "%RES%" %LIBS% || (echo. [ERROR] EXE build failed & goto :end)

del /q "%RES%" 2>nul
goto :ok

:nores
echo. ^[1^/1^] Build EXE: %EXE%  (from %SRC%，无版本资源/清单：DPI 退回系统缩放)
%CC% %COMMON% %GUIFLAGS% %NOFAKE% -o "%EXE%" "%SRC%" %LIBS% || (echo. [ERROR] EXE build failed & goto :end)

:ok
echo. ^[OK^] Done: %EXE%
for %%F in ("%EXE%") do echo.      大小：%%~zF 字节
echo.
echo. 运行示例（处理顺序：输入 -^> FFmpeg 转分片 MP4 -^> 解密 -^> FFmpeg 转 MP4）：
echo.   .\dec_gui.exe              （不带参数：打开图形界面，可拖入文件，Esc 退出）
echo.   .\dec_gui.exe "输入000.ts" "输出000.mp4"
echo.   .\dec_gui.exe "带 空格 的输入.mp4" "输出 结果.mp4" --ffmpeg "C:\cc\ffmpeg\bin\ffmpeg.exe"
echo.
echo. 带参数时仍走与 dec_tui.exe 完全相同的命令行流水线（附加到当前控制台输出日志）。

:end
pause
