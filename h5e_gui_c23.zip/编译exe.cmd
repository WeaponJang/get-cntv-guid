@echo off
cd /d "%~dp0"
chcp 65001
cls

echo. ======== 编译脚本（dec.c ^=^=^> dec.exe） ==========
:: 可配置项
set "CC=gcc"
set "WRES=windres"
set "SRC=dec.c"
set "RC=version.rc"
set "EXE=dec.exe"
set "RES=dec.res"

echo. 公共编译参数：C23 / 体积优化 / 链接期裁剪未引用段 / 关闭断言
echo. 源码已是 UTF-8^,gcc/clang 默认即按 UTF-8 读取^；不加 -finput-charset/-fexec-charset（clang 不支持）
set "COMMON=-std=c23 -Os -s -flto -ffunction-sections -fdata-sections -Wl,--gc-sections -DNDEBUG"
echo. 如用 clang：把 CC 设为 clang^,并加 --target=x86_64-w64-windows-gnu^；较旧 clang 可把 -std=c23 换成 -std=c2x
echo. 想追求极限速度可把 -Os 换成 -O2（体积变大）^；dec.c 与 dec.c 必须用同一组参数才可比
echo. ========================================================

if not exist "%SRC%" (echo. [ERROR] source not found: %SRC% & goto :end)
if not exist "%RC%"  (echo. [ERROR] resource not found: %RC% & goto :end)

echo. ========================================================

echo. ^[1^/2^] Version resource ( windres^, 文件名^=dec.exe )
%WRES% -i "%RC%" -O coff -o "%RES%" -DNDEBUG -DBUILD_TARGET || (echo. [ERROR] windres EXE res failed & goto :end)

echo. ^[2^/2^] Build EXE: %EXE%  (from %SRC% + version info)
%CC% %COMMON% -o "%EXE%" "%SRC%" "%RES%" -lshell32 || (echo. [ERROR] EXE build failed & goto :end)

del /q "%RES%" 2>nul

echo. ^[OK^] Done: %EXE%  (含文件版本属性)

:end
pause
