@echo off
chcp 65001 >nul
cls
cd /d "%~dp0"

echo. ======== 编译脚本（dec_tui.c ^-^-^> dec_tui.exe） ==========
:: 可配置项
set "CC=gcc"
set "WRES=windres"
set "SRC=dec_tui.c"
set "RC=version.rc"
set "EXE=dec_tui.exe"
set "RES=dec_tui.res"

echo. 公共编译参数：C23 / 体积优化 / 链接期裁剪未引用段 / 关闭断言
echo. 源码已是 UTF-8,gcc/clang 默认即按 UTF-8 读取；不加 -finput-charset/-fexec-charset（clang 不支持）
set "COMMON=-std=c23 -Os -s -flto -ffunction-sections -fdata-sections -Wl,--gc-sections -DNDEBUG"
echo. 如用 clang：把 CC 设为 clang,并加 --target=x86_64-w64-windows-gnu；较旧 clang 可把 -std=c23 换成 -std=c2x
echo. 链接需 -lshell32：程序用 CommandLineToArgvW 取宽字符命令行（路径支持空格与中文）
echo. ========================================================

if not exist "%SRC%" (echo. [ERROR] source not found: %SRC% & goto :end)
if not exist "%RC%" goto :nores

echo. ^[1^/2^] Version resource (windres, 文件名=dec_tui.exe)
%WRES% -i "%RC%" -O coff -o "%RES%" -DNDEBUG -DBUILD_TARGET_TUI || (echo. [ERROR] windres res failed & goto :end)

echo. ^[2^/2^] Build EXE: %EXE%  (from %SRC% + version info)
%CC% %COMMON% -o "%EXE%" "%SRC%" "%RES%" -lshell32 || (echo. [ERROR] EXE build failed & goto :end)

del /q "%RES%" 2>nul
goto :ok

:nores
echo. ^[1^/1^] Build EXE: %EXE%  (from %SRC%，无版本资源)
%CC% %COMMON% -o "%EXE%" "%SRC%" -lshell32 || (echo. [ERROR] EXE build failed & goto :end)

:ok
echo. ^[OK^] Done: %EXE%
echo.
echo. 运行示例（处理顺序：输入 -^> FFmpeg 转分片 MP4 -^> 解密 -^> FFmpeg 转 MP4）：
echo.   .\dec_tui.exe              （不带参数：进入 TUI 界面填写参数，Esc 退出）
echo.   .\dec_tui.exe "输入000.ts" "输出000.mp4"
echo.   .\dec_tui.exe "输入测试.ts" "输出测试.mp4"
echo.   .\dec_tui.exe "带 空格 的输入.mp4" "输出 结果.mp4" --ffmpeg "C:\cc\ffmpeg\bin\ffmpeg.exe"

:end
pause
