/* ============================================================================
 * dec_gui.c —— “输入媒体 → FFmpeg 转封装 MP4(分片) → 解密 → FFmpeg 转封装 MP4”
 * ============================================================================
 *
 * 与 dec_tui.c 的关系：本文件由 dec_tui.c 复制派生，只把控制台 TUI 换成
 * Direct2D + DirectWrite 全自绘的 Win32 窗口。解密引擎（TEA-16 / EPB / 网格布局 /
 * type1、type5、classic 分派 / 会话状态）与 dec.c 逐字节相同，解密算法一行未改；
 * MP4 分片解析与样本改写也逐字节相同。流水线只多了三件与界面相关的事：
 * 日志改走 h5e_logf()（可被 GUI 接管）、按已读字节报告进度、可被取消。
 *
 * 与 dec.c 的关系：解密引擎相同，区别只在“视频 NAL 从哪里来、解密后写回哪里”：
 *
 *   dec.c     : 输入本身就是加密 TS → 按 188 字节包 + 视频 PID 重组 PES →
 *               扫 NAL start code → 原地解密 → 撑 AF 补差额 → 写回 TS
 *   dec_gui.c : 输入(TS/MP4) 先由 ffmpeg 命令行流复制成分片 MP4，再从 moof/trun
 *               描述的样本里按 AVCC 长度前缀取 NAL → 同一套引擎解密 →
 *               把变短的 NAL 连同新长度写回样本 → 改写 trun 的样本字节数与
 *               mdat 大小 → 仍是分片 MP4 → 再交给 ffmpeg 流复制成最终 MP4
 *
 * 三个阶段严格串行，不调换、不跳过、不合并：
 *   ① ffmpeg -i <输入> -map 0:v:0 -c copy -movflags +frag_keyframe+empty_moov
 *            +default_base_moof -f mp4 <临时>/stage1.m4v
 *            -map 0:a:0 -c copy -f mp4 <临时>/audio.m4a
 *      （真实落盘；一条命令行两个输出：输入只解复用一次，视频流复制进分片 MP4、音频流
 *        同时复制进 MP4 音频轨 —— 音频旁路。输入没有音频流时这条命令在“解析输出参数”
 *        阶段就失败，程序退回“只转视频”，再探测输入有没有音频流决定是否旁路）
 *   ② 本程序：stage1.m4v → stage2.m4v（视频 NAL 解密，容器仍是分片 MP4）
 *   ③ ffmpeg -i stage2.m4v -i audio.m4a -map 0:v:0 -map 1:a:0 -c copy \
 *      -movflags +faststart
 *            -f mp4 <输出>.part  → 原子替换 <输出>
 *
 * 用法：dec_gui.exe <输入.ts|.mp4> <输出.mp4> [--ffmpeg <ffmpeg路径>]
 *       dec_gui.exe      （不带任何参数：打开 GUI 窗口填写参数，点“开始处理”；
 *                            走的就是上面同一条流水线，只是改在工作线程里跑）
 * 界面：窗口客户区全部由 Direct2D 绘制、文本全部由 DirectWrite 排版，没有子控件、
 *       没有三方库；只用 Windows 自带的 d2d1 / dwrite / comdlg32 / imm32 / shell32。
 *       路径编辑框自己实现光标、选区、剪贴板与输入法（ImmSetCompositionWindow）。
 * 编译：gcc -std=c23 -Os -s -flto -ffunction-sections -fdata-sections
 *              -Wl,--gc-sections -DNDEBUG -municode -mwindows
 *              -o dec_gui.exe dec_gui.c dec_gui.res
 *              -ld2d1 -ldwrite -ldxguid -lole32 -lcomdlg32 -limm32 -lshell32
 *       （见 编译dec_gui.cmd）
 * ========================================================================== */
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <wchar.h>
#include <wctype.h>
#include <math.h>

#if !defined(_WIN32)
/* 非 Windows 平台没有 Direct2D / 宽字符文件 API，直接提示退出 */
int main(void) {
    fputs("dec_gui.exe 仅支持 Windows\n", stderr);
    return 1;
}
#else

#ifndef WIN32_LEAN_AND_MEAN
#  define WIN32_LEAN_AND_MEAN
#endif
#define COBJMACROS /* dwrite.h 的 C 语言 vtable 宏由此开启；d2d1.h 无条件提供 */
#define INITGUID   /* IID_ID2D1Factory / IID_IDWriteFactory 等在本翻译单元内定义 */
#include <windows.h>
#include <shellapi.h>  /* CommandLineToArgvW / DragAcceptFiles：链接需 -lshell32 */
#include <commdlg.h>   /* GetOpenFileNameW / GetSaveFileNameW：链接需 -lcomdlg32 */
#include <imm.h>       /* ImmSetCompositionWindow / ImmGetCompositionStringW：-limm32 */
#include <d2d1.h>
#include <dwrite.h>

#define H5E_VERSION "cctv_h5e MP4 pipeline 4.0.0.0 (F5/F1+EPB+AF/audio-bypass)"

/* MP4 路径下的默认视频选择：stage1.m4v 只有一条视频轨，pid 退化为此常量（与 dec.c 默认一致） */
#define H5E_DEFAULT_VIDEO_PID 0x100u

/* 会话句柄：状态结构定义见引擎段末尾 */
typedef struct cctv_h5e_session cctv_h5e_session;

#if defined(__GNUC__) || defined(__clang__)
#  define H5E_UNUSED __attribute__((unused))
#else
#  define H5E_UNUSED
#endif

#define H5E_GRID_TAIL_GUARD 17u   /* 网格单元起点处至少要剩余这么多字节（跟随播放器判定） */
#define H5E_TYPE1_MIN_LEN   129u  /* 短于该长度的 type1 原样透传（不网格解密、不丢 EPB） */
#define H5E_CLASSIC_MIN_LEN 48u   /* classic 网格的最小 NAL / RBSP 长度（type5 与 type1 共用） */

/* 解析密钥窗口时的有界前缀长度：只需覆盖 RBSP[0..31] 对应的 EBSP 字节。
 * 最坏情况（00 00 03 反复）下第 31 个 RBSP 字节落在偏移 48 之前，64 留足余量。 */
#define H5E_PREFIX_WINDOW   64u

/* ===================== 流水线 ↔ 界面 的三个钩子 ===================== */
/* 命令行模式下三者都为空/零，流水线的行为与 dec_tui.c 完全一致：日志写 stderr、
 * 不报进度、不可取消。GUI 模式在启动工作线程前挂上钩子，跑完再摘掉。
 * 声明放在引擎段之前，是为了让引擎段本身一个字节都不用动。 */

/* 一行日志（已去掉行尾换行）。由工作线程调用，实现方必须自己加锁。 */
typedef void (*h5e_log_sink)(const wchar_t *line);
static h5e_log_sink g_log_sink;

/* stage = 1..3；frac 为 0..1，负值表示“进度不可知”（ffmpeg 阶段画跑马灯） */
typedef void (*h5e_progress_sink)(int stage, double frac);
static h5e_progress_sink g_progress_sink;

/* 取消标志：UI 线程置 1，工作线程在阶段边界、每个分片处、以及等待 ffmpeg 的
 * 轮询间隙里检查。ffmpeg 子进程也由工作线程自己 TerminateProcess，句柄不跨线程共享。 */
static volatile LONG g_cancel;

static void h5e_report(int stage, double frac) {
    if (g_progress_sink) g_progress_sink(stage, frac);
}

/* ============================ 解密引擎开始 ============================ */
/* 以下到“解密引擎（NAL 级）结束”为止的代码与 dec.c 逐字节一致，勿单独改动；
 * 要与 dec.c 同步修改。 */

/* TEA-16：8 字节分组、小端 32 位字、delta = 0x9E3779B9、16 轮。
 * 加密版只在自查时用来验证解密，CLI 路径不调用。 */
static H5E_UNUSED void h5e_tea_encrypt_block(uint8_t out[8], const uint8_t in[8],
                                            const uint8_t key[16]) {
    uint32_t v0, v1, k0, k1, k2, k3;
    memcpy(&v0, in, 4);
    memcpy(&v1, in + 4, 4);
    memcpy(&k0, key, 4);
    memcpy(&k1, key + 4, 4);
    memcpy(&k2, key + 8, 4);
    memcpy(&k3, key + 12, 4);
    uint32_t sum = 0;
    const uint32_t delta = 0x9E3779B9u;
    for (int i = 0; i < 16; i++) {
        sum += delta;
        v0 += (((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >> 5) + k1));
        v1 += (((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >> 5) + k3));
    }
    memcpy(out, &v0, 4);
    memcpy(out + 4, &v1, 4);
}

/* TEA-16 解密：轮序与轮数和加密一致，sum 从 delta*16 递减回 0。 */
static void h5e_tea_decrypt_block(uint8_t out[8], const uint8_t in[8], const uint8_t key[16]) {
    uint32_t v0, v1, k0, k1, k2, k3;
    memcpy(&v0, in, 4);
    memcpy(&v1, in + 4, 4);
    memcpy(&k0, key, 4);
    memcpy(&k1, key + 4, 4);
    memcpy(&k2, key + 8, 4);
    memcpy(&k3, key + 12, 4);
    const uint32_t delta = 0x9E3779B9u;
    uint32_t sum = delta * 16u;
    for (int i = 0; i < 16; i++) {
        v1 -= (((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >> 5) + k3));
        v0 -= (((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >> 5) + k1));
        sum -= delta;
    }
    memcpy(out, &v0, 4);
    memcpy(out + 4, &v1, 4);
}

/* 收集 NAL 中所有 EPB（00 00 03）的起点偏移，供网格解密后统一丢弃 0x03。
 * 用 memchr 批量找 0x00（内部是字宽/SIMD 实现），再验证后两个字节；
 * 命中后跳 3 字节——00 00 03 的第二、三个字节不可能再是 EPB 起点。
 * 返回 0 成功；-1 为内存不足。 */
static int h5e_collect_epb(const uint8_t *nal, size_t len, size_t **out_pos, size_t *out_n) {
    *out_pos = NULL;
    *out_n = 0;
    if (!nal || len < 3) return 0;
    size_t cap = len / 3 + 1;
    size_t *epbs = (size_t *)malloc(cap * sizeof(size_t));
    if (!epbs) return -1;
    size_t n = 0;
    size_t i = 0;
    const size_t limit = len - 2; /* 候选起点 i 必须满足 i + 2 < len */
    while (i < limit) {
        const uint8_t *p = (const uint8_t *)memchr(nal + i, 0, limit - i);
        if (!p) break;
        size_t e = (size_t)(p - nal);
        if (nal[e + 1] == 0 && nal[e + 2] == 3) {
            epbs[n++] = e;
            i = e + 3;
        } else {
            i = e + 1;
        }
    }
    *out_pos = epbs;
    *out_n = n;
    return 0;
}

/* 按记录好的位置丢掉 EPB 的第三个字节 0x03，返回删除后的长度。
 * 删掉的字节集合与 dec.c 一致（每个 epbs[i] + 2），只是把逆序逐次 memmove 换成
 * 前向按段批量搬运：读游标 r 到下一个删除点之间的整段一次搬完，整体 O(n)。
 * dec.c 的 require_intact 恒为 false（播放器按解密前的位置盲删），故不再保留。 */
static size_t h5e_drop_epb_03(uint8_t *nal, size_t len, const size_t *epbs, size_t n) {
    if (!nal || n == 0) return len;
    size_t w = 0; /* 写游标 */
    size_t r = 0; /* 读游标（未搬运的起点） */
    for (size_t i = 0; i < n; i++) {
        const size_t del = epbs[i] + 2;
        if (del >= len) continue; /* 与 dec.c 的 "e + 2 >= nlen" 保护对应（实际不可达） */
        if (del < r) continue;    /* 防御：EPB 间距 >= 3，实际不会触发 */
        memmove(nal + w, nal + r, del - r);
        w += del - r;
        r = del + 1;
    }
    if (r < len) {
        memmove(nal + w, nal + r, len - r);
        w += len - r;
    }
    return w;
}

/* RBSP 下标 → EBSP 偏移（取代 dec.c 的 r2e[] 整表）。
 * 游标 k 只前进不回退：k = max{ m : epbs[m] + 2 - m <= r }，则 e = r + k。
 * epbs 严格升序且间距 >= 3，该式对 k 单调，所以线性推进就能拿到最大值，
 * 结果与 dec.c 的 r2e[r] 逐值相同。 */
typedef struct {
    const size_t *epbs; /* 升序 EPB 起点（EBSP 坐标） */
    size_t nep;
    size_t k; /* 已越过的 EPB 数 */
} h5e_rbsp_map;

static void h5e_rbsp_map_init(h5e_rbsp_map *m, const size_t *epbs, size_t nep) {
    m->epbs = epbs;
    m->nep = nep;
    m->k = 0;
}

/* 前置条件：调用方保证 r 单调不减，且 r < nr（RBSP 总长）。 */
static size_t h5e_rbsp_at(h5e_rbsp_map *m, size_t r) {
    while (m->k < m->nep && m->epbs[m->k] + 2 - m->k <= r) m->k++;
    return r + m->k;
}

/* 有界前缀解析：把 RBSP[start .. start+n) 的字节取到 out，只看前 64 字节。
 * 返回 0 成功；1 表示窗口内确定不了（调用方须回退到 h5e_gather_rbsp_full）。
 * EPB 的前两个 0x00 仍算 RBSP 字节，只跳过第三个字节 0x03——
 * 即 dec.c 里“先填 i、i+1，再 i += 3”的等价写法。 */
static int h5e_gather_rbsp_prefix(const uint8_t *nal, size_t len, size_t start, uint8_t *out,
                                  size_t n) {
    const size_t wlen = (len < (size_t)H5E_PREFIX_WINDOW) ? len : (size_t)H5E_PREFIX_WINDOW;
    size_t r = 0, e = 0, got = 0;
    while (e < wlen && got < n) {
        if (e + 2 < wlen && nal[e] == 0 && nal[e + 1] == 0 && nal[e + 2] == 3) {
            for (int t = 0; t < 2 && got < n; t++) {
                if (r >= start) out[got++] = nal[e + t];
                r++;
            }
            e += 3; /* 跳过 EPB 的 03：RBSP 下标不前进 */
            continue;
        }
        if (r >= start) out[got++] = nal[e];
        r++;
        e++;
    }
    return (got == n) ? 0 : 1;
}

/* 全量回退路径：结果与 dec.c 的 r2e[] 完全等价，只在前缀窗口不够时才走。
 * 返回 0 成功；1 表示下标越界或内存不足（对应 dec.c 返回 0 的情形）。 */
static int h5e_gather_rbsp_full(const uint8_t *nal, size_t len, size_t start, uint8_t *out,
                                size_t n) {
    size_t *epbs = NULL, nep = 0;
    if (h5e_collect_epb(nal, len, &epbs, &nep) != 0) return 1;
    const size_t nr = len - nep;
    if (start + n > nr) {
        free(epbs);
        return 1;
    }
    h5e_rbsp_map m;
    h5e_rbsp_map_init(&m, epbs, nep);
    for (size_t b = 0; b < n; b++) out[b] = nal[h5e_rbsp_at(&m, start + b)];
    free(epbs);
    return 0;
}

/* 步长闭式解：直接由密钥字节算出网格间隔，不做查表拟合 */
static const uint16_t h5e_type5_f5_base[6] = {160, 192, 224, 256, 288, 320};

/* F5 步长：把密钥前 4 字节当小端 32 位数，模 6 选中 BASE 档位，
 * 再或上同下标的密钥字节——所以间隔总是落在 160..320 这 6 个档位里。
 * key16 只需前 6 字节有效。 */
static uint32_t h5e_type5_stride_f5(const uint8_t *key16) {
    uint32_t le = (uint32_t)key16[0] | ((uint32_t)key16[1] << 8) |
                  ((uint32_t)key16[2] << 16) | ((uint32_t)key16[3] << 24);
    unsigned idx = (unsigned)(le % 6u);
    return (uint32_t)h5e_type5_f5_base[idx] | (uint32_t)key16[idx];
}

/* 从 type5 NAL 取密钥（RBSP[5:11] 共 6 字节）算 F5 步长。
 * 只读 6 字节，因此先走有界前缀，窗口不够时回退全量；
 * 两条路径取到的字节相同，步长自然相同。取不到时返回 0。 */
static uint32_t h5e_type5_stride_from_nal(const uint8_t *nal, size_t len) {
    if (!nal || len < 21) return 0;
    uint8_t key[6];
    if (h5e_gather_rbsp_prefix(nal, len, 5, key, 6) != 0 &&
        h5e_gather_rbsp_full(nal, len, 5, key, 6) != 0) {
        return 0; /* 对应 dec.c 的 nr < 11 或建表失败 */
    }
    return h5e_type5_stride_f5(key);
}

/* type1 的 F1 步长：档位选择规则与 F5 相同，只是密钥改成 RBSP[1:7]。 */
static uint32_t h5e_type1_stride_from_nal(const uint8_t *nal, size_t len) {
    if (!nal || len < 7) return 0;
    uint8_t key[6];
    if (h5e_gather_rbsp_prefix(nal, len, 1, key, 6) != 0 &&
        h5e_gather_rbsp_full(nal, len, 1, key, 6) != 0) {
        return 0; /* 对应 dec.c 的 nr < 7 或建表失败 */
    }
    return h5e_type5_stride_f5(key);
}

/* type1 的 G 变换：16 步移位寄存器运算，每步由 fbit 反馈产生一个输出位；
 * 帧头所属的“族”决定其中若干步的反馈位要取反（翻转掩码）。 */
static int h5e_type1_fbit(uint32_t W) {
    const int w0 = (W >> 0) & 1;
    const int w8 = (W >> 8) & 1;
    const int w15 = (W >> 15) & 1;
    const int w19 = (W >> 19) & 1;
    const int w25 = (W >> 25) & 1;
    const int w30 = (W >> 30) & 1;
    const int w31 = (W >> 31) & 1;
    const int t = w0 | w8;
    return (w31 ^ w15 ^ t ^ (w8 & w19) ^ (w25 & (w0 ^ w19)) ^ (w0 & (1 ^ w8) & w30) ^
            ((1 ^ w0) & w19 & w30) ^ (w25 & w30 & (w8 ^ w19))) & 1;
}

/* 注入位闭式：切片头第 2、3 字节拼成 16 位字后按位反转。
 * 第 s 步 (0..7) 注入 nal[2] 的第 (7-s) 位，第 s 步 (8..15) 注入 nal[1] 的第 (15-s) 位。
 * 取代按帧头“家族”拟合的翻转表 + B 步常量叠加：后者只覆盖已观测到的帧头，
 * 且 0x61 族的掩码与 nal[1] 无关，遇到未拟合的 (nal[1], nal[2]) 组合会整帧解错。 */
static uint16_t h5e_type1_header_bits(uint8_t b1, uint8_t b2) {
    const uint32_t w = ((uint32_t)b2 << 8) | b1;
    uint16_t m = 0;
    for (int s = 0; s < 16; s++) m = (uint16_t)(m | (uint16_t)(((w >> (15 - s)) & 1u) << s));
    return m;
}

/* G 变换主体：W = Y:X 拼成 32 位寄存器，跑 16 步。
 * 每步输出位 = fbit ^ 注入位，输出按 s=0 对应最高位拼成 P1，
 * 寄存器左移并把输出位回填。X/Y 是小端读出的两个 16 位单元，P1 即解密后的前 2 字节。 */
static uint16_t h5e_type1_G(uint16_t X, uint16_t Y, uint16_t bits) {
    uint32_t W = (uint32_t)X | ((uint32_t)Y << 16);
    uint16_t P1 = 0;
    for (int s = 0; s < 16; s++) {
        const int b = h5e_type1_fbit(W) ^ ((bits >> s) & 1);
        P1 = (uint16_t)(P1 | (b << (15 - s)));
        W = ((W << 1) | (uint32_t)b) & 0xFFFFFFFFu;
    }
    return P1;
}

/* type1 新模式网格：起始下标、间隔、尾部余量都由会话给出（默认 64 / F1 步长 / 17）。
 * 单元只 4 字节，尾部仍要求留足 guard 字节；字节一律经映射表按 RBSP 取。
 * 与 type5 的差别：只要存在 EPB 就丢 03，不看有没有解过单元。
 * 返回处理后的 NAL 长度。 */
static size_t h5e_decrypt_type1_new(uint8_t *nal, size_t len, uint32_t stride, size_t start,
                                    size_t guard) {
    if (!nal || stride < 4 || len < H5E_TYPE1_MIN_LEN) return len;
    /* 帧头在循环前快照，注入位是它的纯函数，提出来只算一次；
     * 没有任何单元能写到 RBSP[0..2]（start >= 32），所以提前算安全。 */
    const uint16_t bits = h5e_type1_header_bits(nal[1], nal[2]);
    size_t *epbs = NULL, nep = 0;
    if (h5e_collect_epb(nal, len, &epbs, &nep) != 0) return len;
    const size_t nr = len - nep; /* 与 dec.c 的 nr 完全相同 */
    h5e_rbsp_map m;
    h5e_rbsp_map_init(&m, epbs, nep);
    bool any_cell = false;
    for (size_t k = 0;; k++) {
        const size_t o = start + k * (size_t)stride;
        if (o + guard > nr || o + 4 > nr) break;
        size_t off[4];
        for (size_t b = 0; b < 4; b++) off[b] = h5e_rbsp_at(&m, o + b);
        const uint16_t X = (uint16_t)(nal[off[0]] | (nal[off[1]] << 8));
        const uint16_t Y = (uint16_t)(nal[off[2]] | (nal[off[3]] << 8));
        const uint16_t P1 = h5e_type1_G(X, Y, bits);
        nal[off[0]] = (uint8_t)(P1 & 0xFF);
        nal[off[1]] = (uint8_t)((P1 >> 8) & 0xFF);
        nal[off[2]] = (uint8_t)(X & 0xFF);
        nal[off[3]] = (uint8_t)((X >> 8) & 0xFF);
        any_cell = true;
    }
    /* 与 type5/classic 一致：一个单元都没解过的 NAL 原样透传，不丢 EPB。 */
    size_t out_len = len;
    if (nep != 0 && any_cell) out_len = h5e_drop_epb_03(nal, len, epbs, nep);
    free(epbs);
    return out_len;
}

/* type5 新模式网格：TEA 密钥取 RBSP[5:21]，单元从 RBSP[64] 开始、间隔 stride，
 * 每个单元 8 字节。密钥与单元都按 RBSP 编号，因此 EPB 必须靠映射表换算。
 * 至少解过一个单元才丢 EPB 03。返回处理后的 NAL 长度。 */
static size_t h5e_decrypt_type5_new(uint8_t *nal, size_t len, uint32_t stride) {
    if (!nal || len < 21 || stride < 8) return len;
    size_t *epbs = NULL, nep = 0;
    if (h5e_collect_epb(nal, len, &epbs, &nep) != 0) return len;
    const size_t nr = len - nep;
    if (nr < 21) {
        free(epbs);
        return len;
    }
    /* 密钥窗口内若有 EPB，EBSP 与 RBSP 的偏移就错开了，
     * 必须经映射表取字节，否则密钥错、后面所有单元全解错。 */
    h5e_rbsp_map m;
    h5e_rbsp_map_init(&m, epbs, nep);
    uint8_t key[16];
    for (size_t b = 0; b < 16; b++) key[b] = nal[h5e_rbsp_at(&m, 5 + b)];
    uint8_t tmp[8];
    bool any_cell = false;
    for (size_t k = 0;; k++) {
        const size_t o = 64 + k * (size_t)stride;
        if (o + H5E_GRID_TAIL_GUARD > nr || o + 8 > nr) break;
        size_t off[8];
        for (size_t b = 0; b < 8; b++) off[b] = h5e_rbsp_at(&m, o + b);
        for (size_t b = 0; b < 8; b++) tmp[b] = nal[off[b]];
        h5e_tea_decrypt_block(tmp, tmp, key);
        for (size_t b = 0; b < 8; b++) nal[off[b]] = tmp[b];
        any_cell = true;
    }
    /* 丢 EPB 03 属于网格处理：一个单元都没解过的 NAL 原样透传 */
    size_t out_len = len;
    if (nep != 0 && any_cell) out_len = h5e_drop_epb_03(nal, len, epbs, nep);
    free(epbs);
    return out_len;
}

/* classic 网格（老流：type25 出现的是 01 06 而不是 01 09）：起点 32、间隔 80、
 * 每单元 8 字节 TEA-16，密钥取 RBSP[16:32]；尾单元要求还剩一整个 stride。
 * 至少解过一个单元才丢 EPB 03。返回处理后的 NAL 长度。 */
static size_t h5e_decrypt_classic_grid(uint8_t *nal, size_t len) {
    if (!nal || len < H5E_CLASSIC_MIN_LEN) return len;
    size_t *epbs = NULL, nep = 0;
    if (h5e_collect_epb(nal, len, &epbs, &nep) != 0) return len;
    const size_t nr = len - nep;
    if (nr < H5E_CLASSIC_MIN_LEN) {
        free(epbs);
        return len;
    }
    h5e_rbsp_map m;
    h5e_rbsp_map_init(&m, epbs, nep);
    uint8_t key[16];
    for (size_t b = 0; b < 16; b++) key[b] = nal[h5e_rbsp_at(&m, 16 + b)];
    bool any_cell = false;
    for (size_t k = 0;; k++) {
        const size_t o = 32 + k * (size_t)80;
        if (o + 80 > nr) break;
        size_t off[8];
        for (size_t b = 0; b < 8; b++) off[b] = h5e_rbsp_at(&m, o + b);
        uint8_t blk[8];
        for (size_t b = 0; b < 8; b++) blk[b] = nal[off[b]];
        h5e_tea_decrypt_block(blk, blk, key);
        for (size_t b = 0; b < 8; b++) nal[off[b]] = blk[b];
        any_cell = true;
    }
    /* 连一个 classic 单元（32+80）都放不下的 NAL 原样透传：
     * 此时丢 EPB 只会让长度变短，却没解出任何内容。 */
    size_t out_len = len;
    if (nep != 0 && any_cell) out_len = h5e_drop_epb_03(nal, len, epbs, nep);
    free(epbs);
    return out_len;
}

/* 会话：跨 NAL、跨分块保留的解密状态 */
struct cctv_h5e_session {
    bool new_mode;       /* 网格布局：true = 新模式（type25 魔数 01 09），false = classic（01 06） */
    bool should_decrypt; /* 是否解密：看 type25 的 payload[0] 是不是 1 */
    size_t type1_start;  /* type1 新模式网格的起始 RBSP 下标 */
    size_t type1_guard;  /* type1 网格的尾部判定余量 */
    size_t type1_min_len;/* 短于该长度的 type1 不解密 */
};

/* 会话初始状态：classic 布局、不解密 type1/type5，等 type25 把开关打开 */
static void h5e_session_init(cctv_h5e_session *s) {
    s->new_mode = false;
    s->should_decrypt = false;
    s->type1_start = 64;
    s->type1_guard = H5E_GRID_TAIL_GUARD;
    s->type1_min_len = H5E_TYPE1_MIN_LEN;
}

/* 单条 NAL 的分派入口：type25 只更新会话状态（开关 + 网格布局）；
 * type1/type5 在开关打开时按当前布局解密，并把新长度写回 *io_len。 */
static void h5e_session_on_nal(cctv_h5e_session *s, uint8_t *nal, size_t *io_len) {
    if (!s || !nal || !io_len || *io_len < 1) return;
    const size_t len = *io_len;
    const int ntype = nal[0] & 0x1f;
    if (ntype == 25) {
        s->should_decrypt = (len >= 2 && nal[1] == 1);
        /* 魔数决定网格布局，且允许中途双向切换（老流先 01 06 classic，
         * 后续分片再切到 01 09 新模式）：01 09 → 新模式；01 06 → classic。 */
        if (len >= 4 && nal[2] == 0x01) {
            if (nal[3] == 0x09) s->new_mode = true;
            else if (nal[3] == 0x06) s->new_mode = false;
        }
        return;
    }
    if ((ntype != 1 && ntype != 5) || !s->should_decrypt) return;
    if (!s->new_mode) {
        /* classic 的 type1 仍按 type1_min_len 透传；type5 只受 classic 网格的 48 字节门槛约束 */
        if (ntype == 1 && len < s->type1_min_len) return;
        *io_len = h5e_decrypt_classic_grid(nal, len);
        return;
    }
    if (ntype == 5) {
        uint32_t S = h5e_type5_stride_from_nal(nal, len);
        if (S >= 8) *io_len = h5e_decrypt_type5_new(nal, len, S);
        return;
    }
    if (ntype == 1) {
        if (len < s->type1_min_len) return;
        uint32_t S = h5e_type1_stride_from_nal(nal, len);
        if (S == 0) S = 511u;
        *io_len = h5e_decrypt_type1_new(nal, len, S, s->type1_start, s->type1_guard);
    }
}

/* ===================== 解密引擎（NAL 级）结束 ===================== */

/* ================= MPEG-TS 层（保留语义，MP4 路径不调用） ================= */
/*
 * 下面这一段是 dec.c 的 TS 处理层，原样保留：
 *   - 它体现“视频 PID → PES 重组 → PES 内的 NAL → 解密后按 188 字节回填”的
 *     原始语义，与 MP4 路径共用同一个会话与同一套 NAL 解密核心；
 *   - MP4 路径不需要它，因为样本里已经带 NALU 长度前缀，解密变短后直接改写长度即可，
 *     等价于这里的“撑 AF 补偿”；
 *   - 保留它是为了让两条路径的语义可对照，也便于将来把中间格式换回 TS 时直接复用。
 */

/* 把单个 TS 包的 AF 撑大，从 payload 尾部抢走 need 字节（用 0xFF 填）。
 * 本来只有 payload 的包新建 AF（afc 1→3），已有 AF 的包则延长 AF 体。
 * 返回实际抢到的字节数。 */
static H5E_UNUSED size_t h5e_expand_af_steal(uint8_t *data, size_t len, size_t pkt_off, size_t need) {
    if (!data || need == 0 || pkt_off + 188 > len) return 0;
    int afc = (data[pkt_off + 3] & 0x30) >> 4;
    if (afc == 1) {
        /* 无 AF：新建 AF，占用 1（长度字节）+ af_len 字节 */
        if (need < 1) return 0;
        size_t af_len = need - 1;
        if (af_len > 182) af_len = 182;
        size_t steal = 1 + af_len;
        uint8_t old_payload[184];
        memcpy(old_payload, data + pkt_off + 4, 184);
        data[pkt_off + 3] = (uint8_t)((data[pkt_off + 3] & 0xCF) | 0x30); /* afc=3：AF + payload */
        data[pkt_off + 4] = (uint8_t)af_len;
        if (af_len > 0) {
            data[pkt_off + 5] = 0x00; /* AF flags：无随机接入点、无 PCR */
            for (size_t i = 1; i < af_len; i++) data[pkt_off + 5 + i] = 0xFF;
        }
        size_t new_pl = 184 - steal;
        memcpy(data + pkt_off + 5 + af_len, old_payload, new_pl);
        return steal;
    }
    if (afc == 2 || afc == 3) {
        size_t af_len = data[pkt_off + 4];
        size_t pi = 5 + af_len;
        if (pi >= 188) return 0;
        size_t old_payload_len = 188 - pi;
        size_t add = need < old_payload_len ? need : old_payload_len;
        if (add == 0) return 0;
        if (af_len + add > 182) {
            add = 182 - af_len;
            if (add == 0) return 0;
        }
        size_t new_af_len = af_len + add;
        uint8_t old_payload[184];
        memcpy(old_payload, data + pkt_off + pi, old_payload_len);
        /* 新腾出的空间填 0xFF（TS 标准的 AF 保留值） */
        for (size_t i = 0; i < add; i++) data[pkt_off + 5 + af_len + i] = 0xFF;
        data[pkt_off + 4] = (uint8_t)new_af_len;
        size_t new_pl = old_payload_len - add;
        memcpy(data + pkt_off + 5 + new_af_len, old_payload, new_pl);
        if (new_pl == 0) data[pkt_off + 3] = (uint8_t)((data[pkt_off + 3] & 0xCF) | 0x20); /* 只剩 AF：afc=2 */
        else data[pkt_off + 3] = (uint8_t)((data[pkt_off + 3] & 0xCF) | 0x30);            /* 还有 payload：afc=3 */
        return add;
    }
    return 0;
}

/* 一个 TS 包在缓冲里的 payload 区间，用于把重组后的 PES 按原顺序散写回去。 */
typedef struct {
    size_t pkt_off; /* 包起始在 TS 缓冲内的偏移 */
    size_t pi;      /* 包内 payload 起始（afc=1 时 4，否则 5 + AF 长度） */
    size_t pl;      /* 包内 payload 字节数 */
} h5e_span;

/* ES 内找到的一处 NAL start code。 */
typedef struct {
    size_t pos; /* start code 在 ES 内的偏移 */
    size_t sc;  /* start code 长度：3（00 00 01）或 4（00 00 00 01） */
} h5e_sc;

/* 缓冲按需扩容：*cap 是当前元素容量，elem 是单元素字节数，need 是所需元素数。
 * 容量从 64 起按 2 倍递增；缓冲只在单个 PES 规模内增长，与块大小无关。
 * 返回 0 成功；-1 为溢出或内存不足，此时原缓冲仍然有效。
 * MP4 路径也复用它做分片缓冲的扩容。 */
static int h5e_reserve(void **buf, size_t *cap, size_t need, size_t elem) {
    if (need <= *cap) return 0;
    size_t ncap = *cap ? *cap : 64;
    while (ncap < need) {
        if (ncap > SIZE_MAX / 2) {
            ncap = need;
            break;
        }
        ncap <<= 1;
    }
    if (elem == 0 || ncap > SIZE_MAX / elem) return -1;
    void *p = realloc(*buf, ncap * elem);
    if (!p) return -1;
    *buf = p;
    *cap = ncap;
    return 0;
}

/* 处理 PES 的工作区：所有缓冲都按需增长并跨 PES 复用，不逐块释放。 */
typedef struct {
    cctv_h5e_session *session; /* 跨 PES、跨块复用的解密状态 */
    uint8_t *pes;              /* 累积的 PES 字节，同时也存放重建结果（省掉单独的 out 缓冲） */
    h5e_span *spans;           /* 该 PES 各包 payload 区间 */
    h5e_sc *starts;            /* 该 PES 内的 NAL start code 列表 */
    size_t pes_n, pes_cap;
    size_t spans_n, spans_cap;
    size_t starts_n, starts_cap;
    size_t nal_count; /* 经过会话的 NAL 数，用于判断是否真的解到了东西 */
    bool oom;         /* 扩容失败标记：上层据此区分“内存不足”与“没有 NAL” */
} h5e_ts_ctx;

/* 处理一个完整 PES，分四个阶段：跳过 PES 头 → 扫 NAL start code → 逐条解密并
 * 原地重建 → 撑 AF 补差额后散写回各包 payload。 */
static H5E_UNUSED void h5e_flush_pes(uint8_t *data, size_t len, h5e_ts_ctx *ctx) {
    if (ctx->pes_n == 0) return;
    uint8_t *pes = ctx->pes;
    const size_t pes_n = ctx->pes_n;

    size_t base_skip = 0;
    if (pes_n >= 9 && pes[0] == 0 && pes[1] == 0 && pes[2] == 1) base_skip = 9 + pes[8];
    if (base_skip > pes_n) {
        ctx->pes_n = 0;
        ctx->spans_n = 0;
        return;
    }

    const size_t es_off = base_skip;
    const size_t es_n = pes_n - es_off;
    uint8_t *es = pes + es_off;

    /* 扫描 ES 内的 NAL start code：memchr 找 0x00，再判 4 字节 / 3 字节；
     * 优先次序与推进方式与 dec.c 的逐字节版一致 */
    size_t ns = 0;
    for (size_t i = 0; i + 3 < es_n;) {
        const uint8_t *p = (const uint8_t *)memchr(es + i, 0, (es_n - 3) - i);
        if (!p) break;
        const size_t j = (size_t)(p - es);
        size_t sc = 0;
        if (j + 4 <= es_n && es[j + 1] == 0 && es[j + 2] == 0 && es[j + 3] == 1) {
            sc = 4;
        } else if (es[j + 1] == 0 && es[j + 2] == 1) {
            sc = 3;
        }
        if (sc == 0) {
            i = j + 1;
            continue;
        }
        if (h5e_reserve((void **)&ctx->starts, &ctx->starts_cap, ns + 1, sizeof(h5e_sc)) != 0) {
            ctx->oom = true;
            ctx->pes_n = 0;
            ctx->spans_n = 0;
            ctx->starts_n = 0;
            return;
        }
        ctx->starts[ns].pos = j;
        ctx->starts[ns].sc = sc;
        ns++;
        i = j + sc;
    }
    ctx->starts_n = ns;

    /* 原地重建：out_n 是 pes 内的写游标，恒不越过“已消费的读位置” */
    size_t out_n = base_skip;

    size_t cursor = 0;
    for (size_t idx = 0; idx < ns; idx++) {
        const size_t pos = ctx->starts[idx].pos;
        const size_t sc = ctx->starts[idx].sc;
        const size_t end = (idx + 1 < ns) ? ctx->starts[idx + 1].pos : es_n;
        if (cursor < pos) {
            memmove(pes + out_n, es + cursor, pos - cursor);
            out_n += pos - cursor;
        }
        memmove(pes + out_n, es + pos, sc);
        out_n += sc;
        if (pos + sc >= end) {
            cursor = end;
            continue;
        }
        /* 就地解密：解密只会丢 EPB 的 03（收缩），所以直接改 PES 缓冲安全 */
        uint8_t *nal = es + pos + sc;
        size_t nlen = end - (pos + sc);
        size_t io = nlen;
        h5e_session_on_nal(ctx->session, nal, &io);
        ctx->nal_count++;
        memmove(pes + out_n, nal, io);
        out_n += io;
        cursor = end;
    }
    if (cursor < es_n) {
        memmove(pes + out_n, es + cursor, es_n - cursor);
        out_n += es_n - cursor;
    }

    /* 解密后变短了：从最后一个包往前逐个撑 AF，把差额吃回来；
     * capacity 取 AF 扩展前各包 payload 之和。 */
    size_t capacity = 0;
    for (size_t i = 0; i < ctx->spans_n; i++) capacity += ctx->spans[i].pl;
    if (capacity > out_n) {
        size_t remaining = capacity - out_n;
        for (size_t i = ctx->spans_n; i-- > 0 && remaining > 0;) {
            size_t got = h5e_expand_af_steal(data, len, ctx->spans[i].pkt_off, remaining);
            remaining -= got;
        }
        /* AF 长度变了，按新包头重算各包 payload 区间（无 payload 的包直接丢弃） */
        size_t nn = 0;
        for (size_t i = 0; i < ctx->spans_n; i++) {
            const size_t pkt_off = ctx->spans[i].pkt_off;
            int afc = (data[pkt_off + 3] & 0x30) >> 4;
            if (afc == 0 || afc == 2) continue;
            size_t pi = (afc == 1) ? 4 : (size_t)(5 + data[pkt_off + 4]);
            if (pi >= 188) continue;
            ctx->spans[nn].pkt_off = pkt_off;
            ctx->spans[nn].pi = pi;
            ctx->spans[nn].pl = 188 - pi;
            nn++;
        }
        ctx->spans_n = nn;
    }

    size_t off = 0;
    for (size_t i = 0; i < ctx->spans_n; i++) {
        const size_t pkt_off = ctx->spans[i].pkt_off;
        const size_t pi = ctx->spans[i].pi;
        const size_t pl = ctx->spans[i].pl;
        size_t chunk = (off < out_n) ? (out_n - off) : 0;
        if (chunk > pl) chunk = pl;
        if (chunk > 0) memcpy(data + pkt_off + pi, pes + off, chunk);
        if (chunk < pl) {
            /* AF 吸收不下的残留尾部用 0xFF 填满 */
            memset(data + pkt_off + pi + chunk, 0xFF, pl - chunk);
        }
        off += pl;
    }

    ctx->pes_n = 0;
    ctx->spans_n = 0;
}

/* 原地解密一个 TS 缓冲里指定 PID 的全部视频 NAL。
 * 做法：按 188 字节遍历 TS 包，把同一个 PES 的 payload 依次攒起来，
 * 遇到 PUSI（新 PES 的起点）就先把上一个 PES 冲掉。
 * 返回 >= 0 为经过会话的 NAL 数；-1 为内存不足。 */
static H5E_UNUSED long long h5e_decrypt_ts_inplace(uint8_t *data, size_t len,
                                                   cctv_h5e_session *session, uint16_t vpid) {
    if (!data || len < 188) return 0;

    h5e_ts_ctx ctx;
    memset(&ctx, 0, sizeof ctx);
    ctx.session = session;

    for (size_t off = 0; off + 188 <= len; off += 188) {
        if (data[off] != 0x47) continue;
        uint16_t pid = (uint16_t)(((data[off + 1] & 0x1f) << 8) | data[off + 2]);
        if (pid != vpid) continue;
        bool pusi = (data[off + 1] & 0x40) != 0;
        int afc = (data[off + 3] & 0x30) >> 4;
        if (afc == 0 || afc == 2) continue;
        size_t pi = (afc == 1) ? 4 : (size_t)(5 + data[off + 4]);
        if (pi >= 188) continue;
        size_t payload_len = 188 - pi;
        if (pusi) h5e_flush_pes(data, len, &ctx);
        if (h5e_reserve((void **)&ctx.pes, &ctx.pes_cap, ctx.pes_n + payload_len, 1) != 0 ||
            h5e_reserve((void **)&ctx.spans, &ctx.spans_cap, ctx.spans_n + 1, sizeof(h5e_span)) != 0) {
            ctx.oom = true;
            break;
        }
        memcpy(ctx.pes + ctx.pes_n, data + off + pi, payload_len);
        ctx.pes_n += payload_len;
        ctx.spans[ctx.spans_n].pkt_off = off;
        ctx.spans[ctx.spans_n].pi = pi;
        ctx.spans[ctx.spans_n].pl = payload_len;
        ctx.spans_n++;
    }
    if (!ctx.oom) h5e_flush_pes(data, len, &ctx);

    const size_t nal_count = ctx.nal_count;
    const bool oom = ctx.oom;
    free(ctx.pes);
    free(ctx.spans);
    free(ctx.starts);
    return oom ? -1 : (long long)nal_count;
}

/* ====================== 通用工具：宽字符 / 路径 / UTF-8 ====================== */

/* 宽字符转 UTF-8，只为把中文路径打印到控制台 */
static char *h5e_utf8_from_wide(const wchar_t *w) {
    if (!w) return NULL;
    int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, NULL, 0, NULL, NULL);
    if (n <= 0) return NULL;
    char *s = (char *)malloc((size_t)n);
    if (!s) return NULL;
    if (WideCharToMultiByte(CP_UTF8, 0, w, -1, s, n, NULL, NULL) <= 0) {
        free(s);
        return NULL;
    }
    return s;
}

/* UTF-8 窄串 → 宽串（有界；失败或空串时 dst 置为空串） */
static void h5e_wide_from_utf8_buf(const char *s, wchar_t *dst, size_t cap) {
    if (!dst || cap == 0) return;
    dst[0] = L'\0';
    if (!s || !*s) return;
    if (MultiByteToWideChar(CP_UTF8, 0, s, -1, dst, (int)cap) <= 0) dst[0] = L'\0';
    dst[cap - 1] = L'\0';
}

/* 流水线的统一日志出口。格式串与参数仍是 UTF-8 窄字符，调用点与 dec_tui.c 的
 * fprintf(stderr, ...) 逐字一致；命令行模式原样写 stderr，GUI 模式转宽字符后
 * 按行喂给界面（一次调用可能含续行，所以在这里拆行）。 */
static void h5e_logf(const char *fmt, ...) {
    char buf[4096];
    va_list ap;
    va_start(ap, fmt);
    const int n = vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if (!g_log_sink) {
        fputs(buf, stderr);
        return;
    }
    wchar_t w[4096];
    h5e_wide_from_utf8_buf(buf, w, sizeof w / sizeof w[0]);
    wchar_t *p = w;
    while (*p) {
        wchar_t *nl = wcschr(p, L'\n');
        if (nl) *nl = L'\0';
        size_t len = wcslen(p);
        while (len > 0 && p[len - 1] == L'\r') p[--len] = L'\0';
        if (*p) g_log_sink(p);
        if (!nl) break;
        p = nl + 1;
    }
}

/* 打印一行带路径的中文提示。路径可能很长，所以不经过 h5e_logf 的定长缓冲。 */
static void h5e_msg_path(const char *prefix, const wchar_t *path) {
    if (!g_log_sink) {
        char *u = h5e_utf8_from_wide(path);
        fprintf(stderr, "%s%s\n", prefix, u ? u : "?");
        free(u);
        return;
    }
    wchar_t pre[256];
    h5e_wide_from_utf8_buf(prefix, pre, sizeof pre / sizeof pre[0]);
    const size_t n = wcslen(pre) + (path ? wcslen(path) : 1u);
    wchar_t *line = (wchar_t *)malloc((n + 1) * sizeof(wchar_t));
    if (!line) return;
    memcpy(line, pre, wcslen(pre) * sizeof(wchar_t));
    wcscpy(line + wcslen(pre), path ? path : L"?");
    g_log_sink(line);
    free(line);
}

static wchar_t *h5e_wcsdup(const wchar_t *s) {
    if (!s) return NULL;
    const size_t n = wcslen(s);
    wchar_t *p = (wchar_t *)malloc((n + 1) * sizeof(wchar_t));
    if (!p) return NULL;
    memcpy(p, s, (n + 1) * sizeof(wchar_t));
    return p;
}

/* 拼接目录与文件名：自动补一个反斜杠 */
static wchar_t *h5e_path_join(const wchar_t *dir, const wchar_t *name) {
    if (!dir || !name) return NULL;
    const size_t a = wcslen(dir), b = wcslen(name);
    const bool need_sep = (a > 0 && dir[a - 1] != L'\\' && dir[a - 1] != L'/');
    wchar_t *p = (wchar_t *)malloc((a + (need_sep ? 1u : 0u) + b + 1) * sizeof(wchar_t));
    if (!p) return NULL;
    memcpy(p, dir, a * sizeof(wchar_t));
    size_t k = a;
    if (need_sep) p[k++] = L'\\';
    memcpy(p + k, name, b * sizeof(wchar_t));
    p[k + b] = L'\0';
    return p;
}

/* 给输出路径加上 .part 后缀：与目标同目录，后续改名才是同卷原子重命名 */
static wchar_t *h5e_part_path(const wchar_t *out_path) {
    const size_t len = wcslen(out_path);
    if (len == 0 || len > 32000) return NULL;
    wchar_t *p = (wchar_t *)malloc((len + 8) * sizeof(wchar_t));
    if (!p) return NULL;
    memcpy(p, out_path, (len + 1) * sizeof(wchar_t));
    memcpy(p + len, L".part", 6 * sizeof(wchar_t));
    return p;
}

/* 取绝对路径：避免 ffmpeg 子进程相对路径与当前目录产生歧义 */
static wchar_t *h5e_full_path(const wchar_t *p) {
    if (!p || !*p) return NULL;
    wchar_t *buf = NULL;
    size_t cap = 512;
    for (;;) {
        wchar_t *t = (wchar_t *)realloc(buf, cap * sizeof(wchar_t));
        if (!t) {
            free(buf);
            return NULL;
        }
        buf = t;
        DWORD n = GetFullPathNameW(p, (DWORD)cap, buf, NULL);
        if (n == 0) {
            free(buf);
            return NULL;
        }
        if ((size_t)n < cap) return buf;
        cap = (size_t)n + 1; /* 缓冲区不够：按返回值重新分配 */
    }
}

/* 存在且是普通文件（不是目录） */
static bool h5e_is_regular_file(const wchar_t *p) {
    DWORD attr = GetFileAttributesW(p);
    if (attr == INVALID_FILE_ATTRIBUTES) return false;
    return (attr & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

/* 取扩展名（不含点），用于判定输入格式 */
static const wchar_t *h5e_extension_of(const wchar_t *p) {
    if (!p) return L"";
    const wchar_t *dot = NULL;
    for (const wchar_t *q = p; *q; q++) {
        if (*q == L'.') dot = q;
        else if (*q == L'\\' || *q == L'/') dot = NULL; /* 目录里的点不算扩展名 */
    }
    return dot ? dot + 1 : L"";
}

static bool h5e_ext_is(const wchar_t *ext, const wchar_t *want) {
    if (!ext || !want) return false;
    for (size_t i = 0;; i++) {
        const wchar_t a = (wchar_t)towlower(ext[i]);
        const wchar_t b = (wchar_t)towlower(want[i]);
        if (a != b) return false;
        if (a == L'\0') return true;
    }
}

/* 文件大小（-1 表示取不到） */
static long long h5e_file_size(const wchar_t *p) {
    HANDLE h = CreateFileW(p, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
                           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return -1;
    LARGE_INTEGER sz;
    const bool ok = GetFileSizeEx(h, &sz) != 0 && sz.QuadPart >= 0;
    CloseHandle(h);
    return ok ? (long long)sz.QuadPart : -1;
}

/* 唯一临时目录：%TEMP%\cctv_h5e_<pid>_<tick>_<n>，n 递增以避开并发冲突 */
static wchar_t *h5e_temp_dir_new(void) {
    wchar_t base[MAX_PATH + 2];
    const DWORD n = GetTempPathW(MAX_PATH, base);
    if (n == 0 || n >= MAX_PATH) return NULL;
    for (unsigned tries = 0; tries < 1000; tries++) {
        wchar_t name[80];
        swprintf(name, 80, L"cctv_h5e_%lu_%llu_%u", (unsigned long)GetCurrentProcessId(),
                 (unsigned long long)GetTickCount64(), tries);
        wchar_t *dir = h5e_path_join(base, name);
        if (!dir) return NULL;
        if (CreateDirectoryW(dir, NULL)) return dir;
        const DWORD err = GetLastError();
        free(dir);
        if (err != ERROR_ALREADY_EXISTS) return NULL;
    }
    return NULL;
}

/* 清掉临时目录里登记的所有中间文件（stage1.m4v / stage2.m4v / audio.m4a），再删目录本身 */
static void h5e_temp_dir_remove(const wchar_t *dir, wchar_t *const *files, size_t n) {
    for (size_t i = 0; files && i < n; i++)
        if (files[i]) DeleteFileW(files[i]);
    if (dir) RemoveDirectoryW(dir);
}

/* ================= MP4 分片解析与视频样本解密（本文件新增部分） ================= */
/*
 * 为什么在 MP4 样本层解密：
 *   阶段 1 产出的分片 MP4 里，每条样本是 AVCC 格式：NALU 前面带 lengthSize（1..4）
 *   字节大端长度。它天然把“NAL 边界”写在数据里，因此：
 *     - 取 NAL 不需要扫描 start code（等价于 dec.c 扫 00 00 01/00 00 00 01）；
 *     - 解密后 NAL 变短（丢 EPB 03）只需重写长度前缀、trun 里的样本字节数和 mdat 大小。
 *   解密核心 h5e_session_on_nal() 的入参永远是“去掉 start code / 长度前缀的 NAL
 *   本体”，两条路径完全一致；EPB 的收集与丢弃也仍然发生在核心内部。
 */

#define H5E_MP4_MAX_BOX  (256u << 20) /* 单个 moof / mdat 荷载上限：挡住坏文件 */
#define H5E_MP4_MAX_MOOV (64u << 20)  /* moov 上限（正常只有几百字节到几 MB） */
#define H5E_MP4_MAX_TRUN 4u           /* 允许一个 moof 内出现的 trun 数 */

/* FourCC 常量：与 box 里的 4 个字节按大端一一对应 */
#define H5E_CC(a, b, c, d) \
    (((uint32_t)(a) << 24) | ((uint32_t)(b) << 16) | ((uint32_t)(c) << 8) | (uint32_t)(d))

/* 视频轨信息：全部来自 moov，阶段 1 的中间文件里只有这一条轨 */
typedef struct {
    uint32_t track_id;    /* moov/trak/tkhd 的 track_ID，tfhd 必须与之一致 */
    uint32_t length_size; /* NALU 长度前缀字节数 1..4（avcC[4] / hvcC[21] 的低 2 位 + 1） */
} h5e_mp4_track;

/* 一个 box 头：size 含头部，hdr 是头部长度（8，或 largesize 的 16） */
typedef struct {
    uint64_t size;
    uint64_t hdr;
    uint32_t type;
} h5e_box;

/* moof 里一条 trun 的样本尺寸表位置：尺寸表按 stride 排列，size 字段不一定在首 4 字节 */
typedef struct {
    uint8_t *first;   /* moof 缓冲内首条记录的起点（可写，回写时就地改 size 字段） */
    size_t stride;    /* 每条记录的字节数（duration / size / flags / cts 的组合） */
    size_t size_off;  /* size 字段相对记录起点的偏移 */
    uint32_t count;   /* 样本条数 */
    int64_t data_off; /* trun 的 data-offset；没有该字段时为 -1 */
} h5e_trun;

static uint32_t h5e_be_read(const uint8_t *p, size_t n) {
    uint32_t v = 0;
    for (size_t i = 0; i < n; i++) v = (v << 8) | (uint32_t)p[i];
    return v;
}

static void h5e_be_write(uint8_t *p, size_t n, uint32_t v) {
    for (size_t i = 0; i < n; i++) p[i] = (uint8_t)(v >> (8 * (n - 1 - i)));
}

static uint64_t h5e_be_read64(const uint8_t *p) {
    return ((uint64_t)h5e_be_read(p, 4) << 32) | (uint64_t)h5e_be_read(p + 4, 4);
}

static void h5e_be_write64(uint8_t *p, uint64_t v) {
    h5e_be_write(p, 4, (uint32_t)(v >> 32));
    h5e_be_write(p + 4, 4, (uint32_t)(v & 0xFFFFFFFFu));
}

/* 读一个 box 头。*at_eof 表示已经到文件尾（正常结束）；size 字段为 0 按“到文件尾”折算。
 * 返回 0 成功；-2 读失败；-5 结构非法（大小自相矛盾）。 */
static int h5e_box_read(FILE *f, long long fsize, h5e_box *b, bool *at_eof) {
    *at_eof = false;
    uint8_t h[16];
    const size_t got = fread(h, 1, 8, f);
    if (got == 0) {
        *at_eof = true;
        return 0;
    }
    if (got != 8) return -2;
    uint64_t size = h5e_be_read(h, 4);
    b->type = h5e_be_read(h + 4, 4);
    b->hdr = 8;
    if (size == 1) { /* largesize：紧跟 8 字节 64 位长度 */
        if (fread(h + 8, 1, 8, f) != 8) return -2;
        size = h5e_be_read64(h + 8);
        b->hdr = 16;
    }
    if (size == 0) { /* 到文件尾 */
        const long long pos = _ftelli64(f);
        if (pos < 0 || fsize < pos) return -5;
        size = (uint64_t)(fsize - pos);
    }
    if (size < b->hdr) return -5;
    b->size = size;
    return 0;
}

/* 写回 box 头：宽度沿用原头（8 或 16），不把小 box 悄悄升级成 largesize */
static bool h5e_box_write_hdr(FILE *f, uint32_t type, uint64_t size, uint64_t hdr) {
    uint8_t h[16];
    if (hdr == 16) {
        h5e_be_write(h, 4, 1);
        h5e_be_write(h + 4, 4, type);
        h5e_be_write64(h + 8, size);
    } else {
        if (size > 0xFFFFFFFFull) return false;
        h5e_be_write(h, 4, (uint32_t)size);
        h5e_be_write(h + 4, 4, type);
    }
    return fwrite(h, 1, (size_t)hdr, f) == (size_t)hdr;
}

/* 在父 box 荷载 p[0..n) 里顺序取子 box：*cur 为游标，每调用一次前进一个 box。
 * 越界或 size 非法返回 false（调用方按“结构异常”处理）。 */
static bool h5e_mp4_next(const uint8_t *p, size_t n, size_t *cur, uint32_t *type, size_t *pay,
                         size_t *pay_n) {
    const size_t o = *cur;
    if (o + 8 > n) return false;
    uint64_t size = h5e_be_read(p + o, 4);
    const uint32_t t = h5e_be_read(p + o + 4, 4);
    size_t hdr = 8;
    if (size == 1) {
        if (o + 16 > n) return false;
        size = h5e_be_read64(p + o + 8);
        hdr = 16;
    } else if (size == 0) {
        size = (uint64_t)(n - o);
    }
    if (size < hdr || size > (uint64_t)(n - o)) return false;
    *type = t;
    *pay = o + hdr;
    *pay_n = (size_t)size - hdr;
    *cur = o + (size_t)size;
    return true;
}

/* 找第一个指定类型的子 box，返回其荷载指针；找不到返回 NULL */
static const uint8_t *h5e_mp4_child(const uint8_t *p, size_t n, uint32_t type, size_t *out_n) {
    size_t cur = 0, pay = 0, pay_n = 0;
    uint32_t t = 0;
    while (h5e_mp4_next(p, n, &cur, &t, &pay, &pay_n)) {
        if (t == type) {
            if (out_n) *out_n = pay_n;
            return p + pay;
        }
    }
    return NULL;
}

/* 从 moov 里取视频轨：track_ID 与 NALU 长度前缀字节数。
 *   AVC  : 样本条目 avc1/avc3 → avcC，[4] 的低 2 位是 lengthSizeMinusOne
 *   HEVC : 样本条目 hvc1/hev1 → hvcC，[21] 的低 2 位是 lengthSizeMinusOne
 * 返回 0 成功；1 没有视频轨；2 视频编码不是 AVC/HEVC；3 结构异常。 */
static int h5e_mp4_parse_moov(const uint8_t *moov, size_t n, h5e_mp4_track *tr) {
    size_t cur = 0, pay = 0, pay_n = 0;
    uint32_t type = 0;
    while (h5e_mp4_next(moov, n, &cur, &type, &pay, &pay_n)) {
        if (type != H5E_CC('t', 'r', 'a', 'k')) continue;
        const uint8_t *trak = moov + pay;

        size_t mdia_n = 0, hdlr_n = 0, tkhd_n = 0, minf_n = 0, stbl_n = 0, stsd_n = 0;
        const uint8_t *mdia = h5e_mp4_child(trak, pay_n, H5E_CC('m', 'd', 'i', 'a'), &mdia_n);
        if (!mdia) continue;
        const uint8_t *hdlr = h5e_mp4_child(mdia, mdia_n, H5E_CC('h', 'd', 'l', 'r'), &hdlr_n);
        /* hdlr 荷载：version/flags(4) + pre_defined(4) + handler_type(4) */
        if (!hdlr || hdlr_n < 12 || h5e_be_read(hdlr + 8, 4) != H5E_CC('v', 'i', 'd', 'e'))
            continue;

        /* tkhd 荷载：version 0 时 track_ID 在偏移 12，version 1 时在 20 */
        const uint8_t *tkhd = h5e_mp4_child(trak, pay_n, H5E_CC('t', 'k', 'h', 'd'), &tkhd_n);
        if (!tkhd || tkhd_n < 24) return 3;
        const uint32_t track_id =
            (tkhd[0] == 1) ? h5e_be_read(tkhd + 20, 4) : h5e_be_read(tkhd + 12, 4);

        const uint8_t *minf = h5e_mp4_child(mdia, mdia_n, H5E_CC('m', 'i', 'n', 'f'), &minf_n);
        const uint8_t *stbl =
            minf ? h5e_mp4_child(minf, minf_n, H5E_CC('s', 't', 'b', 'l'), &stbl_n) : NULL;
        const uint8_t *stsd =
            stbl ? h5e_mp4_child(stbl, stbl_n, H5E_CC('s', 't', 's', 'd'), &stsd_n) : NULL;
        if (!stsd || stsd_n < 8) return 3;

        /* stsd 荷载：version/flags(4) + entry_count(4)，随后是样本条目 */
        const uint8_t *e = stsd + 8;
        const uint8_t *end = stsd + stsd_n;
        while ((size_t)(end - e) >= 8) {
            const uint64_t esz = h5e_be_read(e, 4);
            const uint32_t fmt = h5e_be_read(e + 4, 4);
            if (esz < 8 || esz > (uint64_t)(end - e)) return 3;
            const bool avc =
                (fmt == H5E_CC('a', 'v', 'c', '1') || fmt == H5E_CC('a', 'v', 'c', '3'));
            const bool hevc =
                (fmt == H5E_CC('h', 'v', 'c', '1') || fmt == H5E_CC('h', 'e', 'v', '1'));
            if (!avc && !hevc) return 2; /* av01 等：不做 NAL 级解密 */
            /* 视觉样本条目头 = box 头(8) + 78 字节固定字段，之后才是 avcC / hvcC */
            if (esz < 86) return 3;
            size_t cfg_n = 0;
            const uint8_t *cfg =
                h5e_mp4_child(e + 86, (size_t)esz - 86,
                              hevc ? H5E_CC('h', 'v', 'c', 'C') : H5E_CC('a', 'v', 'c', 'C'),
                              &cfg_n);
            const size_t at = hevc ? 21u : 4u;
            if (!cfg || cfg_n <= at) return 3;
            tr->track_id = track_id;
            tr->length_size = (uint32_t)(cfg[at] & 3) + 1u;
            return 0;
        }
        return 3; /* 样本条目里没有 avc1/avc3/hvc1/hev1 */
    }
    return 1;
}

/* 从 moof 荷载里收集全部 trun（阶段 1 只写纯视频，所以限定单 traf）。
 * 返回 0 成功；3 结构不支持：多 traf、track_ID 不是视频轨、trun 里没有逐样本字节数表、
 * 带 base-data-offset（改长度后该绝对偏移会错）、字段越界等。 */
static int h5e_mp4_parse_moof(uint8_t *moof, size_t n, uint32_t track_id, h5e_trun *truns,
                              size_t *ntrun) {
    *ntrun = 0;
    size_t cur = 0, pay = 0, pay_n = 0;
    uint32_t type = 0;
    size_t ntraf = 0;
    while (h5e_mp4_next(moof, n, &cur, &type, &pay, &pay_n)) {
        if (type != H5E_CC('t', 'r', 'a', 'f')) continue;
        if (++ntraf > 1) return 3;

        const uint8_t *traf = moof + pay;
        size_t tcur = 0, tpay = 0, tpay_n = 0;
        uint32_t ttype = 0;
        bool have_tfhd = false;
        while (h5e_mp4_next(traf, pay_n, &tcur, &ttype, &tpay, &tpay_n)) {
            const uint8_t *kid = traf + tpay;
            if (ttype == H5E_CC('t', 'f', 'h', 'd')) {
                if (tpay_n < 8) return 3;
                const uint32_t flags = h5e_be_read(kid, 4) & 0xFFFFFFu;
                if (h5e_be_read(kid + 4, 4) != track_id) return 3; /* 不是视频轨 */
                if (flags & 0x000001u) return 3; /* base-data-offset：样本变短后偏移会错 */
                have_tfhd = true;
            } else if (ttype == H5E_CC('t', 'r', 'u', 'n')) {
                if (!have_tfhd || *ntrun >= H5E_MP4_MAX_TRUN || tpay_n < 8) return 3;
                const uint32_t flags = h5e_be_read(kid, 4) & 0xFFFFFFu;
                const uint32_t cnt = h5e_be_read(kid + 4, 4);
                if (!(flags & 0x000200u)) return 3; /* 没有逐样本字节数表，改不了长度 */
                size_t off = 8;
                int64_t data_off = -1;
                if (flags & 0x000001u) {
                    if (off + 4 > tpay_n) return 3;
                    data_off = (int64_t)(int32_t)h5e_be_read(kid + off, 4);
                    off += 4;
                }
                if (flags & 0x000004u) off += 4; /* first_sample_flags */
                /* 记录字段顺序固定为 duration → size → flags → cts */
                size_t stride = 0;
                if (flags & 0x000100u) stride += 4; /* duration */
                const size_t size_off = stride;
                stride += 4;                        /* size */
                if (flags & 0x000400u) stride += 4; /* flags */
                if (flags & 0x000800u) stride += 4; /* composition time offset */
                if (off > tpay_n || (uint64_t)cnt * stride > (uint64_t)(tpay_n - off)) return 3;
                h5e_trun *t = &truns[(*ntrun)++];
                t->first = (uint8_t *)kid + off;
                t->stride = stride;
                t->size_off = size_off;
                t->count = cnt;
                t->data_off = data_off;
            }
        }
    }
    return (*ntrun > 0) ? 0 : 3;
}

/* 重写一条样本：样本就是“长度前缀 + NALU”的序列，没有额外头部（不像 FLV 那样有
 * 帧类型/CTS）。out 与 in 等长即可（解密只会缩短）。返回新的样本字节数。 */
static size_t h5e_mp4_rewrite_sample(cctv_h5e_session *s, uint32_t ls, uint8_t *in, size_t n,
                                     uint8_t *out, size_t *nalus) {
    size_t w = 0, r = 0;
    while (r + ls <= n) {
        const uint32_t len = h5e_be_read(in + r, ls);
        r += ls;
        if (len == 0) { /* 空 NALU：只写回长度 0 */
            h5e_be_write(out + w, ls, 0);
            w += ls;
            continue;
        }
        if ((size_t)len > n - r) { /* 长度越界：剩下的原样拷贝，不再解 */
            memcpy(out + w, in + r, n - r);
            w += n - r;
            r = n;
            break;
        }
        uint8_t *nal = in + r;
        size_t io = (size_t)len;
        h5e_session_on_nal(s, nal, &io);
        if (io > (size_t)len) io = (size_t)len; /* 防御：核心只会收缩，不允许变长 */
        (*nalus)++;
        h5e_be_write(out + w, ls, (uint32_t)io);
        w += ls;
        memcpy(out + w, nal, io);
        w += io;
        r += len;
    }
    if (r < n) { /* 尾部残字节原样保留 */
        memcpy(out + w, in + r, n - r);
        w += n - r;
    }
    return w;
}

/* 从文件读 need 字节到按需扩容的缓冲；返回 0 成功、-2 读失败、-3 内存不足 */
static int h5e_read_block(FILE *f, uint8_t **buf, size_t *cap, size_t need) {
    if (h5e_reserve((void **)buf, cap, need ? need : 1u, 1) != 0) return -3;
    if (need && fread(*buf, 1, need, f) != need) return -2;
    return 0;
}

/* 搬运 n 字节：fo 为 NULL 时只读不写（相当于跳过）。用调用方给的小缓冲分块，
 * 所以再大的 box 也不会一次性占内存。返回 0 成功、-2 读失败、-4 写失败 */
static int h5e_copy_bytes(FILE *fi, FILE *fo, uint64_t n, uint8_t *scratch, size_t scratch_n) {
    while (n > 0) {
        const size_t chunk = (n < (uint64_t)scratch_n) ? (size_t)n : scratch_n;
        if (fread(scratch, 1, chunk, fi) != chunk) return -2;
        if (fo && fwrite(scratch, 1, chunk, fo) != chunk) return -4;
        n -= chunk;
    }
    return 0;
}

/* stage1.m4v → stage2.m4v：逐分片重写视频样本（会话跨分片复用）。
 * 返回 >= 0：经过会话的 NAL 数；负数：
 *   -1 参数错 -2 读失败 -3 内存不足 -4 写失败 -5 不是合法 MP4
 *   -6 没有视频轨 / 编码不支持 / 没有任何 NAL（对应 dec.c 的 nal_total == 0 失败判定）
 *   -7 分片结构与预期不符（多轨、缺逐样本字节数表、base-data-offset、字段越发等）
 *   -8 用户取消（g_cancel 被置位；命令行模式下恒为 0，不会出现） */
static long long h5e_decrypt_mp4_w(const wchar_t *in_path, const wchar_t *out_path,
                                   size_t *frags_out, size_t *written_out, bool *unsupported_out) {
    if (frags_out) *frags_out = 0;
    if (written_out) *written_out = 0;
    if (unsupported_out) *unsupported_out = false;
    if (!in_path || !out_path) return -1;

    const long long fsize = h5e_file_size(in_path);
    if (fsize < 8) return -5;
    FILE *fi = _wfopen(in_path, L"rb");
    if (!fi) return -2;
    FILE *fo = _wfopen(out_path, L"wb");
    if (!fo) {
        fclose(fi);
        return -4;
    }

    cctv_h5e_session session;
    h5e_session_init(&session);
    h5e_mp4_track track;
    memset(&track, 0, sizeof track);
    bool have_track = false;
    bool unsupported = false;

    uint8_t *box_buf = NULL, *mdat_buf = NULL, *out_buf = NULL;
    size_t box_cap = 0, mdat_cap = 0, out_cap = 0;
    uint8_t scratch[64 * 1024];
    size_t nalus = 0, frags = 0, written = 0;
    int rc = 0;

    for (;;) {
        if (g_cancel) { /* 每个 box 检查一次：取消最多再跑完当前分片 */
            rc = -8;
            goto done;
        }
        h5e_box b;
        bool at_eof = false;
        int r = h5e_box_read(fi, fsize, &b, &at_eof);
        if (r != 0) {
            rc = r;
            goto done;
        }
        if (at_eof) break;
        const uint64_t payload = b.size - b.hdr;

        if (b.type == H5E_CC('m', 'o', 'o', 'v')) {
            /* moov：取视频轨的 track_ID 与 NALU 长度前缀字节数，然后原样写回 */
            if (payload > H5E_MP4_MAX_MOOV) {
                rc = -5;
                goto done;
            }
            if ((r = h5e_read_block(fi, &box_buf, &box_cap, (size_t)payload)) != 0) {
                rc = r;
                goto done;
            }
            const int pr = h5e_mp4_parse_moov(box_buf, (size_t)payload, &track);
            if (pr == 2) { /* 视频编码不是 AVC/HEVC：根本没法 NAL 级解密 */
                unsupported = true;
                rc = -6;
                goto done;
            }
            if (pr != 0) {
                rc = (pr == 1) ? -6 : -5;
                goto done;
            }
            have_track = true;
            if (!h5e_box_write_hdr(fo, b.type, b.size, b.hdr)) {
                rc = -4;
                goto done;
            }
            if (payload && fwrite(box_buf, 1, (size_t)payload, fo) != (size_t)payload) {
                rc = -4;
                goto done;
            }
            written += (size_t)b.size;
        } else if (b.type == H5E_CC('m', 'o', 'o', 'f')) {
            /* 一个分片 = moof（样本说明）+ mdat（样本数据）。
             * 样本变短后只需改 trun 里的逐样本字节数与 mdat 大小：moof 长度不变
             * （字段定长、条数不变），所以 trun 的 data-offset 仍然成立。 */
            if (!have_track || payload > H5E_MP4_MAX_BOX) {
                rc = -7;
                goto done;
            }
            if ((r = h5e_read_block(fi, &box_buf, &box_cap, (size_t)payload)) != 0) {
                rc = r;
                goto done;
            }
            h5e_trun truns[H5E_MP4_MAX_TRUN];
            size_t ntrun = 0;
            if (h5e_mp4_parse_moof(box_buf, (size_t)payload, track.track_id, truns, &ntrun) != 0) {
                rc = -7;
                goto done;
            }
            h5e_box mb;
            if ((r = h5e_box_read(fi, fsize, &mb, &at_eof)) != 0) {
                rc = r;
                goto done;
            }
            if (at_eof || mb.type != H5E_CC('m', 'd', 'a', 't') ||
                mb.size - mb.hdr > H5E_MP4_MAX_BOX) {
                rc = -7;
                goto done;
            }
            const size_t mpay = (size_t)(mb.size - mb.hdr);
            if ((r = h5e_read_block(fi, &mdat_buf, &mdat_cap, mpay)) != 0) {
                rc = r;
                goto done;
            }
            if (h5e_reserve((void **)&out_buf, &out_cap, mpay ? mpay : 1u, 1) != 0) {
                rc = -3;
                goto done;
            }

            /* 样本数据在 mdat 荷载内首尾相接；trun 的 data-offset 相对 moof 起点 */
            const size_t data_base = (size_t)b.size + (size_t)mb.hdr;
            size_t rp = 0, wp = 0;
            for (size_t i = 0; i < ntrun; i++) {
                const h5e_trun *t = &truns[i];
                if (t->data_off >= 0) {
                    const size_t want = (size_t)t->data_off;
                    if ((uint64_t)t->data_off < (uint64_t)data_base || want - data_base > mpay ||
                        want - data_base < rp) {
                        rc = -7;
                        goto done;
                    }
                    const size_t at = want - data_base;
                    if (at > rp) { /* 分片内的 padding：原样搬运，保持偏移不变 */
                        memcpy(out_buf + wp, mdat_buf + rp, at - rp);
                        wp += at - rp;
                        rp = at;
                    }
                }
                for (uint32_t k = 0; k < t->count; k++) {
                    uint8_t *rec = t->first + (size_t)k * t->stride;
                    const uint32_t sz = h5e_be_read(rec + t->size_off, 4);
                    if ((size_t)sz > mpay - rp) {
                        rc = -7;
                        goto done;
                    }
                    const size_t nw = h5e_mp4_rewrite_sample(&session, track.length_size, mdat_buf + rp,
                                                             (size_t)sz, out_buf + wp, &nalus);
                    h5e_be_write(rec + t->size_off, 4, (uint32_t)nw);
                    rp += sz;
                    wp += nw;
                }
            }
            if (rp < mpay) { /* 没有样本描述覆盖到的尾部原样保留 */
                memcpy(out_buf + wp, mdat_buf + rp, mpay - rp);
                wp += mpay - rp;
            }

            if (!h5e_box_write_hdr(fo, b.type, b.size, b.hdr)) {
                rc = -4;
                goto done;
            }
            if (payload && fwrite(box_buf, 1, (size_t)payload, fo) != (size_t)payload) {
                rc = -4;
                goto done;
            }
            if (!h5e_box_write_hdr(fo, mb.type, mb.hdr + (uint64_t)wp, mb.hdr)) {
                rc = -4;
                goto done;
            }
            if (wp && fwrite(out_buf, 1, wp, fo) != wp) {
                rc = -4;
                goto done;
            }
            written += (size_t)b.size + (size_t)mb.hdr + wp;
            frags++;
            /* 进度 = 已消费的输入字节 / 输入总字节。解密是顺序读，文件游标就是真实
             * 进度，不必先扫一遍数分片；每处理完一个分片报一次，界面据此画进度条。 */
            if (g_progress_sink && fsize > 0) {
                const long long pos = _ftelli64(fi);
                double f = (pos > 0) ? (double)pos / (double)fsize : 0.0;
                if (f > 1.0) f = 1.0;
                h5e_report(2, f);
            }
        } else if (b.type == H5E_CC('m', 'f', 'r', 'a') || b.type == H5E_CC('s', 'i', 'd', 'x')) {
            /* mfra / sidx 按“字节偏移”记账，样本变短后必然失效；两者都是可选的，直接丢弃。
             * 这会让后续 box 的绝对位置前移，但 trun 的 data-offset 相对 moof 起点，不受影响
             * （带 base-data-offset 的分片已在 h5e_mp4_parse_moof 里拒绝）。 */
            if ((r = h5e_copy_bytes(fi, NULL, payload, scratch, sizeof scratch)) != 0) {
                rc = r;
                goto done;
            }
        } else {
            /* ftyp / styp / free / mdat（无 moof 描述）等：与样本长度无关，原样搬运 */
            if (!h5e_box_write_hdr(fo, b.type, b.size, b.hdr)) {
                rc = -4;
                goto done;
            }
            if ((r = h5e_copy_bytes(fi, fo, payload, scratch, sizeof scratch)) != 0) {
                rc = r;
                goto done;
            }
            written += (size_t)b.size;
        }
    }

    /* 一个视频 NAL 都没经过会话：中间文件里没有可解密的视频，按失败处理，
     * 绝不产出“看着成功其实是原文”的副本（与 dec.c 的判定一致）。 */
    if (!have_track || frags == 0 || nalus == 0) {
        rc = -6;
        goto done;
    }

done:
    free(box_buf);
    free(mdat_buf);
    free(out_buf);
    if (rc == 0 && fflush(fo) != 0) rc = -4;
    fclose(fo);
    fclose(fi);
    if (rc == 0) {
        if (frags_out) *frags_out = frags;
        if (written_out) *written_out = written;
        if (unsupported_out) *unsupported_out = unsupported;
        return (long long)nalus;
    }
    return rc;
}

/* ========================= 文件探测小工具 ========================= */

/* MP4 的 ftyp box 位于偏移 4（.m4v / .m4a / .mp4 都一样） */
static bool h5e_file_is_mp4(const wchar_t *p) {
    HANDLE h = CreateFileW(p, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
                           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    uint8_t buf[12];
    DWORD got = 0;
    const bool ok = ReadFile(h, buf, 12, &got, NULL) != 0 && got == 12 &&
                    memcmp(buf + 4, "ftyp", 4) == 0;
    CloseHandle(h);
    return ok;
}

/* ===================== ffmpeg 子进程调用（命令行，不是 libav*） ===================== */

typedef struct {
    wchar_t *p;
    size_t n, cap;
} h5e_wbuf;

static bool h5e_wbuf_add(h5e_wbuf *b, const wchar_t *s, size_t n) {
    if (b->n + n + 1 > b->cap) {
        size_t cap = b->cap ? b->cap : 256;
        while (cap < b->n + n + 1) cap <<= 1;
        wchar_t *t = (wchar_t *)realloc(b->p, cap * sizeof(wchar_t));
        if (!t) return false;
        b->p = t;
        b->cap = cap;
    }
    if (n) memcpy(b->p + b->n, s, n * sizeof(wchar_t));
    b->n += n;
    b->p[b->n] = L'\0';
    return true;
}

static bool h5e_wbuf_adds(h5e_wbuf *b, const wchar_t *s) {
    return h5e_wbuf_add(b, s, s ? wcslen(s) : 0);
}

static bool h5e_wbuf_addc(h5e_wbuf *b, wchar_t c) {
    return h5e_wbuf_add(b, &c, 1);
}

/* 按 CreateProcessW 的解析规则拼一个参数：
 *   - 空参数或含空格 / 制表 / 换行 / 引号时必须用双引号包住；
 *   - 引号前的反斜杠要加倍；字符串结尾的反斜杠也要加倍（否则会转义掉收尾引号）。 */
static bool h5e_wbuf_add_arg(h5e_wbuf *b, const wchar_t *arg) {
    if (!arg) arg = L"";
    if (b->n > 0 && !h5e_wbuf_addc(b, L' ')) return false;
    if (*arg != L'\0' && wcspbrk(arg, L" \t\n\v\"") == NULL) return h5e_wbuf_adds(b, arg);
    if (!h5e_wbuf_addc(b, L'"')) return false;
    const wchar_t *p = arg;
    for (;;) {
        size_t bs = 0;
        while (*p == L'\\') {
            p++;
            bs++;
        }
        if (*p == L'\0') {
            for (size_t i = 0; i < bs * 2; i++)
                if (!h5e_wbuf_addc(b, L'\\')) return false;
            break;
        }
        if (*p == L'"') {
            for (size_t i = 0; i < bs * 2 + 1; i++)
                if (!h5e_wbuf_addc(b, L'\\')) return false;
            if (!h5e_wbuf_addc(b, L'"')) return false;
            p++;
        } else {
            for (size_t i = 0; i < bs; i++)
                if (!h5e_wbuf_addc(b, L'\\')) return false;
            if (!h5e_wbuf_addc(b, *p)) return false;
            p++;
        }
    }
    return h5e_wbuf_addc(b, L'"');
}

/* 子进程输出的行组装器。UTF-8 的多字节序列里不会出现 0x0A，所以只要攒到整行
 * 再转宽字符，就不会把汉字从中间切开（逐次 ReadFile 的边界是任意的）。 */
typedef struct {
    char buf[4096];
    size_t n;
} h5e_pipe_line;

static void h5e_pipe_emit(h5e_pipe_line *pl) {
    while (pl->n > 0 && pl->buf[pl->n - 1] == '\r') pl->n--;
    pl->buf[pl->n] = '\0';
    if (pl->n > 0 && g_log_sink) {
        wchar_t w[4096];
        h5e_wide_from_utf8_buf(pl->buf, w, sizeof w / sizeof w[0]);
        if (w[0]) g_log_sink(w);
    }
    pl->n = 0;
}

static void h5e_pipe_feed(h5e_pipe_line *pl, const char *data, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (data[i] == '\n') {
            h5e_pipe_emit(pl);
            continue;
        }
        if (pl->n + 1 >= sizeof pl->buf) h5e_pipe_emit(pl); /* 超长行截断，不让它无限攒 */
        pl->buf[pl->n++] = data[i];
    }
}

/* 启动 ffmpeg 并等它退出。
 * 命令行模式：子进程继承 stdout/stderr，ffmpeg 自己的报错直接出现在控制台。
 * GUI 模式：没有控制台可继承，改用匿名管道收 stdout+stderr，CREATE_NO_WINDOW
 *           避免每次调用闪一个黑框；边等边读，管道写满导致子进程阻塞的死锁不会发生。
 *           等待期间轮询 g_cancel，一旦取消就 TerminateProcess 并收尾。
 * *spawn_failed 区分“启动不了（不存在/无权限）”与“跑完但返回非 0”。 */
static DWORD h5e_run_ffmpeg(const wchar_t *exe, wchar_t *const *args, int nargs,
                            bool *spawn_failed) {
    if (spawn_failed) *spawn_failed = false;
    h5e_wbuf b;
    memset(&b, 0, sizeof b);
    bool ok = h5e_wbuf_add_arg(&b, exe);
    for (int i = 0; ok && i < nargs; i++) ok = h5e_wbuf_add_arg(&b, args[i]);
    if (!ok) {
        free(b.p);
        if (spawn_failed) *spawn_failed = true;
        return (DWORD)-1;
    }

    const bool gui = (g_log_sink != NULL);
    HANDLE rd = NULL, wr = NULL;
    if (gui) {
        SECURITY_ATTRIBUTES sa;
        sa.nLength = sizeof sa;
        sa.lpSecurityDescriptor = NULL;
        sa.bInheritHandle = TRUE;
        if (!CreatePipe(&rd, &wr, &sa, 0)) {
            free(b.p);
            if (spawn_failed) *spawn_failed = true;
            return (DWORD)-1;
        }
        (void)SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0); /* 读端只属于本进程 */
    }

    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof si);
    memset(&pi, 0, sizeof pi);
    si.cb = sizeof si;
    DWORD flags = 0;
    if (gui) {
        flags = CREATE_NO_WINDOW;
        si.dwFlags = STARTF_USESTDHANDLES;
        si.hStdOutput = wr;
        si.hStdError = wr;
        si.hStdInput = NULL; /* 所有调用点都带 -nostdin，不会去读标准输入 */
    }
    const BOOL created = CreateProcessW(exe, b.p, NULL, NULL, TRUE, flags, NULL, NULL, &si, &pi);
    free(b.p);
    if (wr) CloseHandle(wr); /* 父进程必须关掉写端，否则子进程退出后读不到 EOF */
    if (!created) {
        if (rd) CloseHandle(rd);
        if (spawn_failed) *spawn_failed = true;
        return (DWORD)-1;
    }

    if (!gui) {
        WaitForSingleObject(pi.hProcess, INFINITE);
    } else {
        h5e_pipe_line pl;
        pl.n = 0;
        bool killed = false;
        for (;;) {
            DWORD avail = 0;
            if (PeekNamedPipe(rd, NULL, 0, NULL, &avail, NULL) && avail > 0) {
                char tmp[4096];
                DWORD got = 0;
                const DWORD want = (avail < (DWORD)sizeof tmp) ? avail : (DWORD)sizeof tmp;
                if (ReadFile(rd, tmp, want, &got, NULL) && got > 0) {
                    h5e_pipe_feed(&pl, tmp, got);
                    continue;
                }
            }
            if (g_cancel && !killed) {
                (void)TerminateProcess(pi.hProcess, 1);
                killed = true;
            }
            if (WaitForSingleObject(pi.hProcess, 30) != WAIT_OBJECT_0) continue;
            for (;;) { /* 子进程已退出：把管道里剩下的读干净 */
                char tmp[4096];
                DWORD got = 0;
                if (!ReadFile(rd, tmp, sizeof tmp, &got, NULL) || got == 0) break;
                h5e_pipe_feed(&pl, tmp, got);
            }
            h5e_pipe_emit(&pl);
            break;
        }
        CloseHandle(rd);
    }

    DWORD code = (DWORD)-1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return code;
}

/* 定位 ffmpeg：显式 --ffmpeg（可给 exe 或所在目录）优先，否则搜索 PATH */
static wchar_t *h5e_find_ffmpeg(const wchar_t *want) {
    if (want && *want) {
        wchar_t *full = h5e_full_path(want);
        if (!full) return NULL;
        DWORD attr = GetFileAttributesW(full);
        if (attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY)) {
            wchar_t *j = h5e_path_join(full, L"ffmpeg.exe");
            free(full);
            if (!j) return NULL;
            full = j;
            attr = GetFileAttributesW(full);
        }
        if (attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0) return full;
        free(full);
        return NULL;
    }
    wchar_t buf[MAX_PATH];
    const DWORD n = SearchPathW(NULL, L"ffmpeg.exe", NULL, MAX_PATH, buf, NULL);
    if (n > 0 && n < MAX_PATH) return h5e_wcsdup(buf);
    return NULL;
}

/* 判定输入里到底有没有音频流：让 ffmpeg 把 0:a:0 映射到一个空输出，-t 0 表示不写任何数据，
 * 所以这一步只解析容器头，代价与文件大小无关。
 * 有音频流：映射成功、正常退出（0）；没有音频流：在“解析输出参数”阶段就失败（退出码 22）。
 * 返回 0 已得出结论；-1 表示 ffmpeg 启动不了（无法判断）。 */
static int h5e_ffmpeg_has_audio(const wchar_t *ffmpeg, const wchar_t *in_path, bool *has_audio) {
    if (has_audio) *has_audio = false;
    if (!ffmpeg || !in_path || !has_audio) return -1;
    wchar_t *args[] = {L"-hide_banner", L"-nostdin", L"-loglevel", L"error",
                       L"-i",         (wchar_t *)in_path,
                       L"-map",       L"0:a:0",     L"-t",        L"0",
                       L"-c",         L"copy",      L"-f",        L"null",
                       L"-"}; /* 路径只作为命令行参数传递，不会被回写 */
    bool spawn_failed = false;
    const DWORD code = h5e_run_ffmpeg(ffmpeg, args, (int)(sizeof args / sizeof args[0]),
                                      &spawn_failed);
    if (spawn_failed) return -1;
    *has_audio = (code == 0);
    return 0;
}

/* ============================== 三阶段流水线 ============================== */

/* 退出码：成功 0，其余按失败阶段区分，便于批处理定位 */
enum {
    H5E_RC_OK = 0,
    H5E_RC_USAGE = 1,          /* 参数错误 */
    H5E_RC_INPUT = 2,          /* 输入不存在 / 扩展名不支持 */
    H5E_RC_FFMPEG_MISSING = 3, /* ffmpeg 不存在或无法启动 */
    H5E_RC_STAGE1 = 4,         /* 第一次 ffmpeg 转封装 / 音频旁路抽取失败 */
    H5E_RC_DECRYPT = 5,        /* 解密失败 */
    H5E_RC_STAGE2 = 6,         /* 第二次 ffmpeg 转封装失败 */
    H5E_RC_OUTPUT = 7,         /* 输出目录不可写 / 最终替换失败 */
    H5E_RC_CANCELLED = 8       /* 用户在 GUI 里点了“停止”（命令行模式不会出现） */
};

static int h5e_pipeline(const wchar_t *in_arg, const wchar_t *out_arg, const wchar_t *ffmpeg_arg) {
    int rc = H5E_RC_OK;
    wchar_t *in_full = NULL, *out_full = NULL, *ffmpeg = NULL;
    wchar_t *dir = NULL, *m4v1 = NULL, *m4v2 = NULL, *audio = NULL, *part = NULL;
    wchar_t *temps[3] = {NULL, NULL, NULL}; /* 临时目录内的中间文件，统一由 cleanup 清理 */
    bool audio_ready = false;                /* 音频旁路是否已成功抽出音频 */
    bool dual_ok = false; /* 阶段 1 是否用“一条命令双输出”同时拿到视频与音频 */
    bool part_kept = false;

    /* ---------- 0. 前置检查：输入文件、扩展名、输出目录可写、ffmpeg ---------- */
    if (!h5e_is_regular_file(in_arg)) {
        h5e_msg_path("错误：输入文件不存在或不是普通文件：", in_arg);
        rc = H5E_RC_INPUT;
        goto cleanup;
    }
    const wchar_t *ext = h5e_extension_of(in_arg);
    if (!h5e_ext_is(ext, L"ts") && !h5e_ext_is(ext, L"mp4")) {
        h5e_msg_path("错误：不支持的输入格式（仅支持 .ts / .mp4）：", in_arg);
        rc = H5E_RC_INPUT;
        goto cleanup;
    }
    in_full = h5e_full_path(in_arg);
    out_full = h5e_full_path(out_arg);
    part = out_full ? h5e_part_path(out_full) : NULL;
    if (!in_full || !out_full || !part) {
        h5e_logf("错误：路径解析失败（参数过长或内存不足）\n");
        rc = H5E_RC_USAGE;
        goto cleanup;
    }
    if (h5e_ext_is(h5e_extension_of(out_full), L"ts")) {
        h5e_msg_path("警告：输出扩展名不是 .mp4，内容仍为 MP4：", out_full);
    }

    /* 输出目录可写：先建出 <输出>.part 再删掉。这一步能提前暴露“目录只读/无权限”，
     * 不至于白跑完解密才发现写不进去。 */
    {
        HANDLE probe = CreateFileW(part, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                                   FILE_ATTRIBUTE_NORMAL, NULL);
        if (probe == INVALID_HANDLE_VALUE) {
            h5e_msg_path("错误：输出目录不可写，无法创建：", part);
            rc = H5E_RC_OUTPUT;
            goto cleanup;
        }
        CloseHandle(probe);
        DeleteFileW(part);
    }

    ffmpeg = h5e_find_ffmpeg(ffmpeg_arg);
    if (!ffmpeg) {
        if (ffmpeg_arg && *ffmpeg_arg) {
            h5e_msg_path("错误：指定的 ffmpeg 不存在：", ffmpeg_arg);
        } else {
            h5e_logf("错误：找不到 ffmpeg.exe（可用 --ffmpeg <路径> 指定）\n");
        }
        rc = H5E_RC_FFMPEG_MISSING;
        goto cleanup;
    }

    dir = h5e_temp_dir_new();
    m4v1 = dir ? h5e_path_join(dir, L"stage1.m4v") : NULL;
    m4v2 = dir ? h5e_path_join(dir, L"stage2.m4v") : NULL;
    audio = dir ? h5e_path_join(dir, L"audio.m4a") : NULL; /* 音频旁路（与两个 m4v 同目录） */
    temps[0] = m4v1;
    temps[1] = m4v2;
    temps[2] = audio;
    if (!dir || !m4v1 || !m4v2 || !audio) {
        h5e_logf("错误：无法创建临时目录（%%TEMP%% 不可写或内存不足）\n");
        rc = H5E_RC_OUTPUT;
        goto cleanup;
    }

    /* ---------- 1. 输入 → 分片 MP4（纯视频 m4v）+ 音频旁路（一条命令行，双输出，流复制不重编码） ----------
     * ffmpeg 支持一条命令行写多个输出：输入只解复用一次，视频流复制成分片 MP4、音频流同时
     * 复制进 MP4 音频轨；省掉的是重复解复用与一次进程启动。
     *
     * 视频输出固定带 -movflags +frag_keyframe+empty_moov+default_base_moof：
     *   - frag_keyframe：关键帧处分片，才能让“每条样本多少字节”写在 moof/trun 里，
     *     第 2 阶段只改字段值、不动布局；
     *   - empty_moov：moov 立即落盘（分片输出的标准写法）；
     *   - default_base_moof：trun 的 data-offset 相对 moof 起点，mdat 变短也不会失配。
     * 视频输出只映射 0:v:0：中间文件必须是纯视频，才能保证“单 traf、可按轨改写”。
     *
     * 第二个输出故意用 -map 0:a:0（不带 ?）：输入没有音频流时 ffmpeg 在“解析输出参数”
     * 阶段就失败（退出码 22），两个中间文件都不会落盘，于是下面走回退路径——只转视频，
     * 再探测输入有没有音频流决定是否旁路。 */
    h5e_report(1, -1.0); /* ffmpeg 阶段拿不到可靠的总量，界面画跑马灯 */
    h5e_logf("[1/3] FFmpeg 转封装：输入 -> 分片 MP4（视频）+ 音频旁路（-c copy）\n");
    h5e_msg_path("      输入：", in_full);
    h5e_msg_path("      视频：", m4v1);
    h5e_msg_path("      音频：", audio);
    {
        /* 两个输出：先分片 MP4（纯视频），再音频旁路 MP4 音频轨 */
        wchar_t *args[] = {L"-hide_banner", L"-nostdin", L"-loglevel", L"error", L"-y",
                           L"-i",         in_full,     L"-map",      L"0:v:0",     L"-c",
                           L"copy",       L"-movflags",
                           L"+frag_keyframe+empty_moov+default_base_moof",
                           L"-f",         L"mp4",      m4v1,         L"-map",      L"0:a:0",
                           L"-c",         L"copy",     L"-f",        L"mp4",       audio};
        bool spawn_failed = false;
        const DWORD code = h5e_run_ffmpeg(ffmpeg, args, (int)(sizeof args / sizeof args[0]),
                                          &spawn_failed);
        if (spawn_failed) {
            h5e_msg_path("错误：ffmpeg 无法启动：", ffmpeg);
            rc = H5E_RC_FFMPEG_MISSING;
            goto cleanup;
        }
        dual_ok = (code == 0);
        if (!dual_ok && g_cancel) { /* 是被“停止”杀掉的，不是缺音频流：别再跑一次回退 */
            rc = H5E_RC_CANCELLED;
            goto cleanup;
        }
        if (!dual_ok) {
            h5e_logf(
                    "      [1/3] 单命令双输出未成功（退出码 %ld）：多半是输入没有音频流；\n"
                    "      回退为只转视频，再探测输入有没有音频流决定是否旁路\n",
                    (long)(int32_t)code);
        }
    }
    if (!dual_ok) {
        /* 回退：只产出 stage1.m4v（不映射音频，输入无音频也能成功） */
        wchar_t *args[] = {L"-hide_banner", L"-nostdin", L"-loglevel", L"error", L"-y",
                           L"-i",         in_full,     L"-map",      L"0:v:0",     L"-c",
                           L"copy",       L"-movflags",
                           L"+frag_keyframe+empty_moov+default_base_moof",
                           L"-f",         L"mp4",      m4v1};
        bool spawn_failed = false;
        const DWORD code = h5e_run_ffmpeg(ffmpeg, args, (int)(sizeof args / sizeof args[0]),
                                          &spawn_failed);
        if (spawn_failed) {
            h5e_msg_path("错误：ffmpeg 无法启动：", ffmpeg);
            rc = H5E_RC_FFMPEG_MISSING;
            goto cleanup;
        }
        if (code != 0) {
            h5e_logf(
                    "错误：第一次 FFmpeg 转封装失败（退出码 %ld）——输入可能不是可识别的 TS/MP4，\n"
                    "      或其中的视频参数集(SPS/PPS)无法被解析\n",
                    (long)(int32_t)code);
            rc = H5E_RC_STAGE1;
            goto cleanup;
        }
    }
    {
        const long long sz = h5e_file_size(m4v1);
        if (sz < 64 || !h5e_file_is_mp4(m4v1)) {
            h5e_logf("错误：FFmpeg 未生成有效的 MP4 中间文件（大小 %lld）\n", sz);
            rc = H5E_RC_STAGE1;
            goto cleanup;
        }
        h5e_logf("      分片 MP4 已生成：%lld 字节\n", sz);
    }
    if (g_cancel) {
        rc = H5E_RC_CANCELLED;
        goto cleanup;
    }

    /* ---------- 1b. 音频旁路：判定 / 校验（除回退路径外不再单跑 ffmpeg） ----------
     * 单命令双输出成功时，audio.m4a 已与 stage1.m4v 一起产出，这里只做校验。
     * 只有回退路径才需要判断“输入到底有没有音频”：直接问 ffmpeg（-t 0 只解容器头，
     * 不读内容）——有，就单独抽一次；没有，就降级为只合成视频，并在日志里明说，绝不静默产出。
     * 抽音频失败按“第一次转封装失败”返回非零，不产出一个看着成功、音频却不一致的成品。 */
    if (dual_ok) {
        const long long asz = h5e_file_size(audio);
        if (asz < 64 || !h5e_file_is_mp4(audio)) {
            h5e_logf("错误：FFmpeg 未生成有效的音频旁路文件（大小 %lld）\n", asz);
            rc = H5E_RC_STAGE1;
            goto cleanup;
        }
        audio_ready = true;
        h5e_logf("      音频已抽出：%lld 字节（来自原始输入，与视频分开成两个中间文件）\n",
                asz);
    } else {
        bool has_audio = false;
        const int prc = h5e_ffmpeg_has_audio(ffmpeg, in_full, &has_audio);
        if (g_cancel) { /* 探测被杀掉时 has_audio 会是假阴性，不能据此降级 */
            rc = H5E_RC_CANCELLED;
            goto cleanup;
        }
        if (prc != 0) {
            h5e_logf(
                    "[1/3] 注意：无法判定输入是否带音频（ffmpeg 无法启动），跳过音频旁路，\n"
                    "      最终 MP4 只含视频\n");
        } else if (!has_audio) {
            h5e_logf(
                    "[1/3] 注意：输入里没有音频流，跳过音频旁路，最终 MP4 只含视频\n");
        } else {
            h5e_logf("[1/3] FFmpeg 抽音频：输入 -> 音频旁路（-c copy，不重编码）\n");
            h5e_msg_path("      音频：", audio);
            /* 只做流复制：不重编码、不裁剪（-map 已限定只取音频流，无需 -vn 之类副作用） */
            wchar_t *aargs[] = {L"-hide_banner", L"-nostdin", L"-loglevel", L"error", L"-y",
                                L"-i",         in_full,     L"-map",      L"0:a:0",     L"-c",
                                L"copy",       L"-f",        L"mp4",       audio};
            bool spawn_failed = false;
            const DWORD code = h5e_run_ffmpeg(ffmpeg, aargs, (int)(sizeof aargs / sizeof aargs[0]),
                                              &spawn_failed);
            if (spawn_failed) {
                h5e_msg_path("错误：ffmpeg 无法启动：", ffmpeg);
                rc = H5E_RC_FFMPEG_MISSING;
                goto cleanup;
            }
            if (code != 0) {
                h5e_logf(
                        "错误：音频旁路抽取失败（退出码 %ld）——输入的音频流无法用 -c copy\n"
                        "      流复制进 MP4 音频轨（编码不受 MP4 支持？）；为避免产出音频\n"
                        "      与参考不一致的成品，本次处理中止\n",
                        (long)(int32_t)code);
                rc = H5E_RC_STAGE1;
                goto cleanup;
            }
            const long long asz = h5e_file_size(audio);
            if (asz < 64 || !h5e_file_is_mp4(audio)) {
                h5e_logf("错误：FFmpeg 未生成有效的音频旁路文件（大小 %lld）\n", asz);
                rc = H5E_RC_STAGE1;
                goto cleanup;
            }
            audio_ready = true;
            h5e_logf("      音频已抽出：%lld 字节（来自原始输入，与视频分开成两个中间文件）\n",
                    asz);
        }
    }

    /* ---------- 2. 分片 MP4 → 解密后的分片 MP4（本程序的 hls_h5e 核心） ---------- */
    if (g_cancel) {
        rc = H5E_RC_CANCELLED;
        goto cleanup;
    }
    h5e_report(2, 0.0); /* 这一阶段是本程序自己跑，能按已读字节报真实百分比 */
    h5e_logf("[2/3] 解密 MP4 视频样本（复用 dec.c 引擎，容器仍为分片 MP4）\n");
    h5e_msg_path("      解密结果：", m4v2);
    {
        size_t frags = 0, written = 0;
        bool unsupported = false;
        const long long nalus = h5e_decrypt_mp4_w(m4v1, m4v2, &frags, &written, &unsupported);
        if (nalus < 0) {
            const char *why = "未知错误";
            switch ((int)nalus) {
                case -1: why = "参数错误"; break;
                case -2: why = "读取 MP4 中间文件失败"; break;
                case -3: why = "内存不足"; break;
                case -4: why = "写出解密中间文件失败（磁盘空间不足？）"; break;
                case -5: why = "MP4 中间文件格式不合法"; break;
                case -6:
                    why = unsupported ? "MP4 里的视频编码不是 AVC/HEVC，无法 NAL 级解密"
                                      : "MP4 里没有可解密的视频样本（缺视频轨或数据异常）";
                    break;
                case -7:
                    why = "MP4 分片结构与预期不符（多轨 / 缺逐样本字节数表 / base-data-offset）";
                    break;
                case -8: why = "用户取消"; break;
                default: break;
            }
            if (nalus == -8 || g_cancel) {
                h5e_logf("已取消：解密中止，未产出成品\n");
                rc = H5E_RC_CANCELLED;
                goto cleanup;
            }
            h5e_logf("错误：解密失败 rc=%lld (%s)\n", nalus, why);
            rc = H5E_RC_DECRYPT;
            goto cleanup;
        }
        h5e_logf("      分片：%zu，经过会话的 NAL：%lld，解密结果：%zu 字节\n", frags, nalus,
                written);
    }

    /* ---------- 3. 解密后的分片 MP4（+ 音频旁路）→ 最终 MP4（先写 .part） ---------- */
    if (g_cancel) {
        rc = H5E_RC_CANCELLED;
        goto cleanup;
    }
    h5e_report(3, -1.0);
    h5e_logf("[3/3] FFmpeg 转封装：解密结果%s -> MP4（-c copy）\n",
            audio_ready ? " + 音频旁路" : "");
    if (audio_ready) {
        h5e_msg_path("      视频（解密后）：", m4v2);
        h5e_msg_path("      音频（旁路）：", audio);
    }
    h5e_msg_path("      输出：", part);
    {
        /* 双输入合成：0 = 解密后的视频分片 MP4，1 = 从原始输入抽出的音频轨。
         * 视频轨经历样本改写，音频轨保持原样，所以分两个文件再合起来。 */
        wchar_t *args_ab[] = {L"-hide_banner", L"-nostdin", L"-loglevel", L"error", L"-y",
                             L"-i",         m4v2,        L"-i",         audio,        L"-map",
                             L"0:v:0",     L"-map",     L"1:a:0",     L"-c",        L"copy",
                             L"-movflags",  L"+faststart", L"-f",      L"mp4",      part};
        /* 降级路径：无音频可旁路时只合成视频（仍用可选映射，不会因缺音频流报错） */
        wchar_t *args_sv[] = {L"-hide_banner", L"-nostdin", L"-loglevel", L"error", L"-y",
                             L"-i",         m4v2,        L"-map",      L"0:v:0",    L"-map",
                             L"0:a:0?",     L"-c",       L"copy",     L"-movflags", L"+faststart",
                             L"-f",         L"mp4",      part};
        wchar_t **args = audio_ready ? args_ab : args_sv;
        const int nargs = audio_ready ? (int)(sizeof args_ab / sizeof args_ab[0])
                                      : (int)(sizeof args_sv / sizeof args_sv[0]);
        bool spawn_failed = false;
        const DWORD code = h5e_run_ffmpeg(ffmpeg, args, nargs, &spawn_failed);
        if (spawn_failed) {
            h5e_msg_path("错误：ffmpeg 无法启动：", ffmpeg);
            rc = H5E_RC_FFMPEG_MISSING;
            goto cleanup;
        }
        if (code != 0) {
            h5e_logf("错误：第二次 FFmpeg 转封装失败（退出码 %ld）\n", (long)(int32_t)code);
            rc = H5E_RC_STAGE2;
            goto cleanup;
        }
    }
    {
        const long long sz = h5e_file_size(part);
        if (sz <= 0 || !h5e_file_is_mp4(part)) {
            h5e_logf("错误：FFmpeg 未生成有效的 MP4（大小 %lld）\n", sz);
            rc = H5E_RC_STAGE2;
            goto cleanup;
        }
        h5e_logf("      MP4 已写出：%lld 字节\n", sz);
    }

    /* ---------- 4. 原子替换：成功后才让 <输出> 出现在磁盘上 ---------- */
    if (!MoveFileExW(part, out_full, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        part_kept = true; /* 成品留在 .part 里，方便手动改名 */
        h5e_msg_path("错误：最终替换失败（目标被占用/只读？），成品保留在：", part);
        rc = H5E_RC_OUTPUT;
        goto cleanup;
    }

    h5e_msg_path("完成：", out_full);
    h5e_logf("      处理顺序已确认：输入 -> 分片 MP4 -> 解密 -> MP4（视频）%s\n",
            audio_ready ? "；音频：输入 -> MP4 音频轨（旁路 -c copy，未经过视频中间文件）"
                        : "；音频：无（已跳过音频旁路）");
    h5e_logf("      引擎版本：%s\n", H5E_VERSION);
    h5e_report(3, 1.0);

cleanup:
    /* 取消可能表现为“ffmpeg 退出码非 0”“中间文件没生成”等各种阶段失败，
     * 统一归到取消码，界面据此显示“已停止”而不是一串误导性的报错。 */
    if (g_cancel && rc != H5E_RC_OK) rc = H5E_RC_CANCELLED;
    if (rc != H5E_RC_OK && part && !part_kept) DeleteFileW(part);
    h5e_temp_dir_remove(dir, temps, 3);
    free(in_full);
    free(out_full);
    free(ffmpeg);
    free(dir);
    free(m4v1);
    free(m4v2);
    free(audio);
    free(part);
    return rc;
}

/* ======================= Direct2D + DirectWrite 图形界面 ======================= */
/*
 * 取代 dec_tui.c 的控制台 TUI。整个客户区由 Direct2D 绘制、所有文本由 DirectWrite
 * 排版，没有子控件、没有对话框资源、没有三方库：路径编辑框的光标/选区/剪贴板/横向
 * 滚动/输入法全部自己实现，文件挑选交给 comdlg32 的原生对话框。
 *
 * 线程模型：
 *   UI 线程   —— 消息循环 + 绘制。只有它碰 D2D/DWrite 与 g_rows。
 *   工作线程 —— 跑 h5e_pipeline()，与命令行模式是同一条流水线、同一套解密引擎。
 *                它只通过 g_log_sink / g_progress_sink 往外报，日志行在临界区里
 *                追加，再 PostMessage 让 UI 去排版；进度用 LONG 原子量传递。
 *   取消      —— UI 置 g_cancel，工作线程在阶段边界/每个分片/等 ffmpeg 的轮询间隙
 *                里检查，ffmpeg 子进程也由工作线程自己 TerminateProcess。
 *
 * 坐标：一律用 DIP（1/96 英寸）布局，渲染目标按窗口真实 DPI 创建，D2D 自己换算成
 *       像素，所以高 DPI 下文字与线条都是清晰的矢量，不需要手工缩放每个坐标。
 */

#include <windowsx.h> /* GET_X_LPARAM / GET_WHEEL_DELTA_WPARAM */

#define GUI_CLASS    L"cctv_h5e_dec_gui"
#define GUI_CAP      1024  /* 单个路径字段的最大 UTF-16 单元数 */
#define GUI_LOG_CAP  2000  /* 日志原始行上限 */
#define GUI_LOG_TRIM 500   /* 满了就丢最旧的一批，并整量重排显示行 */
#define GUI_MIN_W    600.0f /* 客户区最小尺寸（DIP） */
#define GUI_MIN_H    440.0f

#define WM_GUI_LOG  (WM_APP + 1) /* 工作线程：有新日志行，去排版 */
#define WM_GUI_DONE (WM_APP + 2) /* 工作线程：流水线结束，wParam 是退出码 */

#define GUI_TIMER_CARET 1 /* 光标闪烁 */
#define GUI_TIMER_ANIM  2 /* 跑马灯 + 读进度原子量 */

/* 调色板下标：画刷按此顺序建一次，渲染目标重建时跟着重建 */
enum {
    B_BG, B_PANEL, B_FIELD, B_BORDER, B_FOCUS, B_TEXT, B_DIM, B_ACCENT,
    B_OK, B_ERR, B_WARN, B_BTN, B_BTN_HOV, B_BTN_DN, B_PRIMARY, B_PRI_HOV,
    B_SEL, B_TRACK, B_LOGTEXT, B_COUNT
};

static const unsigned gui_palette[B_COUNT] = {
    0x1b1d21, /* BG      */
    0x23262b, /* PANEL   */
    0x14161a, /* FIELD   */
    0x363b44, /* BORDER  */
    0x4c9aff, /* FOCUS   */
    0xe6e8eb, /* TEXT    */
    0x8b939e, /* DIM     */
    0x4c9aff, /* ACCENT  */
    0x59c26b, /* OK      */
    0xf0616d, /* ERR     */
    0xe3b341, /* WARN    */
    0x2c3037, /* BTN     */
    0x3a4048, /* BTN_HOV */
    0x22262c, /* BTN_DN  */
    0x2f6feb, /* PRIMARY */
    0x4180f5, /* PRI_HOV */
    0x2f5688, /* SEL     */
    0x2c3037, /* TRACK   */
    0xc3cad4  /* LOGTEXT */
};

/* 文本格式 */
enum { F_TITLE, F_BODY, F_SMALL, F_LOG, F_BTN, F_COUNT };

/* 日志行的语义色：按行首关键字判定，够用了，不需要流水线额外传标记 */
enum { LOG_NORMAL, LOG_STAGE, LOG_OK, LOG_ERR, LOG_WARN };

/* 命中区域 */
enum {
    HIT_NONE = 0,
    HIT_FIELD0, HIT_FIELD1, HIT_FIELD2,
    HIT_BROWSE0, HIT_BROWSE1, HIT_BROWSE2,
    HIT_START, HIT_STOP, HIT_EXIT,
    HIT_LOG, HIT_SCROLL
};

typedef struct { float x, y, w, h; } GuiRect;

typedef struct {
    wchar_t text[GUI_CAP];
    int len, caret, anchor; /* anchor == caret 表示没有选区 */
    float scroll;           /* 横向滚动量（DIP） */
} GuiEdit;

typedef struct { float caret_x, sel_a, sel_b, total; } GuiFieldMetrics;

typedef struct { wchar_t *s; int kind; } GuiLogLine;
typedef struct { int line, off, len; } GuiLogRow; /* 一条原始行折行后的一段 */

typedef struct {
    GuiRect title, version, subtitle;
    float sep_y;
    GuiRect label[3], field[3], browse[3];
    GuiRect progress, stage, status, log, log_scroll;
    GuiRect start, stop, exit;
    float w, h;
} GuiLayout;

/* ------------------------------- 全局状态 ------------------------------- */

static HWND g_hwnd;
static HINSTANCE g_inst;
static float g_dpi = 96.0f;
static int g_final_rc = H5E_RC_OK;

static ID2D1Factory *g_d2d;
static IDWriteFactory *g_dw;
static ID2D1HwndRenderTarget *g_rt;
static ID2D1Brush *g_brush[B_COUNT];
static IDWriteTextFormat *g_fmt[F_COUNT];
static float g_fmt_h[F_COUNT];
static float g_log_line_h = 18.0f;
static wchar_t g_version_w[128];

static GuiLayout g_lay;
static GuiEdit g_edit[3];
static GuiFieldMetrics g_fm[3];
static int g_focus = 0; /* 0..2；-1 = 焦点不在编辑框上 */
static int g_hot = HIT_NONE, g_pressed = HIT_NONE;
static int g_drag_field = -1;
static bool g_drag_scroll = false;
static float g_drag_scroll_off = 0.0f;
static GuiRect g_thumb;
static bool g_caret_on = true;
static float g_anim = 0.0f;

static wchar_t g_status[512];
static int g_status_kind = B_DIM;

static GuiLogLine g_log[GUI_LOG_CAP];
static int g_log_n = 0;
static CRITICAL_SECTION g_log_cs;
static bool g_cs_ready = false;
static int g_log_wrapped = 0;  /* 已折成显示行的原始行数 */
static bool g_log_dirty = true;
static float g_log_width = -1.0f;
static GuiLogRow *g_rows = NULL;
static int g_rows_n = 0, g_rows_cap = 0;
static float g_log_scroll = 0.0f, g_log_max = 0.0f;
static bool g_log_follow = true;

static volatile LONG g_running = 0;
static volatile LONG g_stage = 0;       /* 0 空闲，1..3 */
static volatile LONG g_frac_milli = -1; /* 千分比；-1 = 进度不可知 */
static HANDLE g_thread = NULL;
static wchar_t g_job_in[GUI_CAP], g_job_out[GUI_CAP], g_job_ff[GUI_CAP];
static bool g_close_when_done = false;

static const wchar_t *const gui_placeholder[3] = {
    L"选择或拖入 .ts / .mp4 文件（F2 浏览）",
    L"留空则自动生成 同名_dec.mp4（F2 浏览）",
    L"留空则自动搜索 PATH（F2 浏览）"
};
static const wchar_t *const gui_label[3] = {L"输入文件", L"输出文件", L"ffmpeg"};

/* ------------------------------- 小工具 ------------------------------- */

static float gui_clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

static bool gui_inside(GuiRect r, float x, float y) {
    return x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h;
}

static D2D1_RECT_F gui_d2rect(GuiRect r) {
    D2D1_RECT_F d;
    d.left = r.x; d.top = r.y; d.right = r.x + r.w; d.bottom = r.y + r.h;
    return d;
}

static void gui_wcopy(wchar_t *dst, size_t cap, const wchar_t *src) {
    if (!dst || cap == 0) return;
    size_t n = src ? wcslen(src) : 0;
    if (n >= cap) n = cap - 1;
    if (n) memcpy(dst, src, n * sizeof(wchar_t));
    dst[n] = L'\0';
}

static void gui_invalidate(void) {
    if (g_hwnd) InvalidateRect(g_hwnd, NULL, FALSE);
}

static void gui_status(int kind, const wchar_t *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vswprintf(g_status, sizeof g_status / sizeof g_status[0], fmt, ap);
    va_end(ap);
    g_status_kind = kind;
}

/* 客户区像素 → DIP */
static float gui_px2dip_x(LONG v) { return (float)v * 96.0f / g_dpi; }
static float gui_px2dip_y(LONG v) { return (float)v * 96.0f / g_dpi; }

/* --------------------------- D2D / DWrite 资源 --------------------------- */

static void gui_brushes_release(void) {
    for (int i = 0; i < B_COUNT; i++) {
        if (g_brush[i]) { ID2D1Brush_Release(g_brush[i]); g_brush[i] = NULL; }
    }
}

static bool gui_brushes_create(void) {
    ID2D1RenderTarget *rt = (ID2D1RenderTarget *)g_rt;
    for (int i = 0; i < B_COUNT; i++) {
        const unsigned rgb = gui_palette[i];
        D2D1_COLOR_F col;
        col.r = (float)((rgb >> 16) & 255) / 255.0f;
        col.g = (float)((rgb >> 8) & 255) / 255.0f;
        col.b = (float)(rgb & 255) / 255.0f;
        col.a = 1.0f;
        ID2D1SolidColorBrush *sb = NULL;
        if (FAILED(ID2D1RenderTarget_CreateSolidColorBrush(rt, &col, NULL, &sb)))
            return false;
        g_brush[i] = (ID2D1Brush *)sb;
    }
    return true;
}

static void gui_rt_release(void) {
    gui_brushes_release();
    if (g_rt) { ID2D1HwndRenderTarget_Release(g_rt); g_rt = NULL; }
}

static bool gui_rt_create(void) {
    if (g_rt) return true;
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    D2D1_SIZE_U px;
    px.width = (UINT32)(rc.right - rc.left);
    px.height = (UINT32)(rc.bottom - rc.top);
    if (px.width == 0 || px.height == 0) return false;

    D2D1_RENDER_TARGET_PROPERTIES p;
    p.type = D2D1_RENDER_TARGET_TYPE_DEFAULT;
    p.pixelFormat.format = DXGI_FORMAT_UNKNOWN; /* 交给 D2D 选（HWND 目标固定 BGRA） */
    p.pixelFormat.alphaMode = D2D1_ALPHA_MODE_IGNORE;
    p.dpiX = g_dpi; /* 告诉 D2D 真实 DPI，之后所有坐标就都是 DIP */
    p.dpiY = g_dpi;
    p.usage = D2D1_RENDER_TARGET_USAGE_NONE;
    p.minLevel = D2D1_FEATURE_LEVEL_DEFAULT;

    D2D1_HWND_RENDER_TARGET_PROPERTIES hp;
    hp.hwnd = g_hwnd;
    hp.pixelSize = px;
    hp.presentOptions = D2D1_PRESENT_OPTIONS_NONE;

    if (FAILED(ID2D1Factory_CreateHwndRenderTarget(g_d2d, &p, &hp, &g_rt)) || !g_rt) {
        g_rt = NULL;
        return false;
    }
    ID2D1RenderTarget *rt = (ID2D1RenderTarget *)g_rt;
    ID2D1RenderTarget_SetAntialiasMode(rt, D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);
    /* 深色底上 ClearType 的彩色边缘很明显，灰度抗锯齿更干净 */
    ID2D1RenderTarget_SetTextAntialiasMode(rt, D2D1_TEXT_ANTIALIAS_MODE_GRAYSCALE);
    return gui_brushes_create();
}

static void gui_rt_resize(void) {
    if (!g_rt) return;
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    D2D1_SIZE_U px;
    px.width = (UINT32)(rc.right - rc.left);
    px.height = (UINT32)(rc.bottom - rc.top);
    if (px.width == 0 || px.height == 0) return;
    if (FAILED(ID2D1HwndRenderTarget_Resize(g_rt, &px))) gui_rt_release();
}

/* 一种字体的单行高度：拿探针串量一次，之后垂直居中就不必每帧建 layout */
static float gui_probe_height(int i) {
    IDWriteTextLayout *lay = NULL;
    float h = 16.0f;
    if (SUCCEEDED(IDWriteFactory_CreateTextLayout(g_dw, L"Ag汉字", 4, g_fmt[i], 1000.0f,
                                                  1000.0f, &lay)) && lay) {
        DWRITE_TEXT_METRICS m;
        if (SUCCEEDED(IDWriteTextLayout_GetMetrics(lay, &m)) && m.height > 0) h = m.height;
        IDWriteTextLayout_Release(lay);
    }
    return h;
}

static void gui_formats_release(void) {
    for (int i = 0; i < F_COUNT; i++) {
        if (g_fmt[i]) { IDWriteTextFormat_Release(g_fmt[i]); g_fmt[i] = NULL; }
    }
}

static bool gui_formats_create(void) {
    static const struct {
        const wchar_t *family;
        float size;
        DWRITE_FONT_WEIGHT weight;
    } spec[F_COUNT] = {
        {L"Microsoft YaHei UI", 17.0f, DWRITE_FONT_WEIGHT_SEMI_BOLD}, /* TITLE */
        {L"Microsoft YaHei UI", 13.5f, DWRITE_FONT_WEIGHT_NORMAL},    /* BODY  */
        {L"Microsoft YaHei UI", 12.0f, DWRITE_FONT_WEIGHT_NORMAL},    /* SMALL */
        {L"Consolas",           12.0f, DWRITE_FONT_WEIGHT_NORMAL},    /* LOG   */
        {L"Microsoft YaHei UI", 13.0f, DWRITE_FONT_WEIGHT_NORMAL}     /* BTN   */
    };
    for (int i = 0; i < F_COUNT; i++) {
        if (FAILED(IDWriteFactory_CreateTextFormat(g_dw, spec[i].family, NULL, spec[i].weight,
                                                   DWRITE_FONT_STYLE_NORMAL,
                                                   DWRITE_FONT_STRETCH_NORMAL, spec[i].size,
                                                   L"zh-cn", &g_fmt[i])) || !g_fmt[i])
            return false;
        g_fmt_h[i] = gui_probe_height(i);
    }
    g_log_line_h = g_fmt_h[F_LOG] + 3.0f;
    return true;
}

static float gui_screen_dpi(void) {
    /* GetDpiForWindow 要 Win10 1607；动态取，取不到就用屏幕 DC 的系统 DPI */
    HMODULE u32 = GetModuleHandleW(L"user32.dll");
    if (u32) {
        typedef UINT(WINAPI * fn_t)(HWND);
        fn_t fn = (fn_t)(void *)GetProcAddress(u32, "GetDpiForWindow");
        if (fn && g_hwnd) {
            const UINT d = fn(g_hwnd);
            if (d >= 48 && d <= 960) return (float)d;
        }
    }
    HDC dc = GetDC(NULL);
    int d = dc ? GetDeviceCaps(dc, LOGPIXELSX) : 96;
    if (dc) ReleaseDC(NULL, dc);
    if (d < 48 || d > 960) d = 96;
    return (float)d;
}

/* --------------------------------- 布局 --------------------------------- */

static void gui_layout(float w, float h) {
    const float pad = 16.0f, label_w = 76.0f, btn_w = 76.0f, fh = 30.0f, gap = 10.0f;
    memset(&g_lay, 0, sizeof g_lay);
    g_lay.w = w;
    g_lay.h = h;

    g_lay.title = (GuiRect){pad, 12.0f, w * 0.5f, 26.0f};
    g_lay.version = (GuiRect){pad + w * 0.5f, 16.0f, w * 0.5f - pad, 20.0f};
    g_lay.subtitle = (GuiRect){pad, 42.0f, w - pad * 2, 18.0f};
    g_lay.sep_y = 68.0f;

    const float fx = pad + label_w + 8.0f;
    const float fw = w - pad - btn_w - 8.0f - fx;
    for (int i = 0; i < 3; i++) {
        const float y = 80.0f + (float)i * (fh + gap);
        g_lay.label[i] = (GuiRect){pad, y, label_w, fh};
        g_lay.field[i] = (GuiRect){fx, y, fw > 40.0f ? fw : 40.0f, fh};
        g_lay.browse[i] = (GuiRect){w - pad - btn_w, y, btn_w, fh};
    }

    g_lay.progress = (GuiRect){pad, 210.0f, w - pad * 2, 6.0f};
    g_lay.stage = (GuiRect){pad, 222.0f, w - pad * 2, 18.0f};
    g_lay.status = (GuiRect){pad, 244.0f, w - pad * 2, 20.0f};

    const float btn_h = 32.0f, btn_y = h - pad - btn_h;
    g_lay.exit = (GuiRect){w - pad - 76.0f, btn_y, 76.0f, btn_h};
    g_lay.stop = (GuiRect){g_lay.exit.x - 8.0f - 76.0f, btn_y, 76.0f, btn_h};
    g_lay.start = (GuiRect){g_lay.stop.x - 8.0f - 112.0f, btn_y, 112.0f, btn_h};

    const float log_y = 270.0f;
    const float log_b = btn_y - 12.0f;
    g_lay.log = (GuiRect){pad, log_y, w - pad * 2, (log_b > log_y + 40.0f) ? log_b - log_y : 40.0f};
    g_lay.log_scroll = (GuiRect){g_lay.log.x + g_lay.log.w - 13.0f, g_lay.log.y + 4.0f,
                                 9.0f, g_lay.log.h - 8.0f};
}

static void gui_layout_update(void) {
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    gui_layout(gui_px2dip_x(rc.right - rc.left), gui_px2dip_y(rc.bottom - rc.top));
}

/* --------------------------------- 日志 --------------------------------- */

static void gui_rows_clear(void) {
    g_rows_n = 0;
    g_log_wrapped = 0;
}

static void gui_rows_add(int line, int off, int len) {
    if (g_rows_n == g_rows_cap) {
        const int cap = g_rows_cap ? g_rows_cap * 2 : 256;
        GuiLogRow *p = (GuiLogRow *)realloc(g_rows, (size_t)cap * sizeof(GuiLogRow));
        if (!p) return;
        g_rows = p;
        g_rows_cap = cap;
    }
    g_rows[g_rows_n].line = line;
    g_rows[g_rows_n].off = off;
    g_rows[g_rows_n].len = len;
    g_rows_n++;
}

/* 用 DWrite 的行度量把一条原始行切成若干显示行：这样滚动高度就是行数×行高，
 * 绘制时不必再建 layout，滚一屏只画看得见的那十几行。 */
static void gui_log_wrap(int idx, float width) {
    const wchar_t *s = g_log[idx].s;
    const int len = (int)wcslen(s);
    IDWriteTextLayout *lay = NULL;
    if (len == 0 || width <= 1.0f ||
        FAILED(IDWriteFactory_CreateTextLayout(g_dw, s, (UINT32)len, g_fmt[F_LOG], width,
                                               100000.0f, &lay)) || !lay) {
        if (lay) IDWriteTextLayout_Release(lay);
        gui_rows_add(idx, 0, len);
        return;
    }
    UINT32 count = 0;
    IDWriteTextLayout_GetLineMetrics(lay, NULL, 0, &count);
    DWRITE_LINE_METRICS *m = count ? (DWRITE_LINE_METRICS *)malloc((size_t)count * sizeof(*m)) : NULL;
    bool ok = false;
    if (m && SUCCEEDED(IDWriteTextLayout_GetLineMetrics(lay, m, count, &count)) && count > 0) {
        UINT32 off = 0;
        for (UINT32 i = 0; i < count && off < (UINT32)len; i++) {
            UINT32 n = m[i].length;
            if (n == 0) n = 1; /* 防御：不让游标卡死 */
            if (off + n > (UINT32)len) n = (UINT32)len - off;
            gui_rows_add(idx, (int)off, (int)n);
            off += n;
        }
        ok = true;
    }
    free(m);
    if (!ok) gui_rows_add(idx, 0, len);
    IDWriteTextLayout_Release(lay);
}

/* 工作线程侧：只追加原始行，排版留给 UI。临界区保护 g_log 的追加与整批丢弃。 */
static void gui_log_sink(const wchar_t *line) {
    if (!line || !*line || !g_cs_ready) return;
    const wchar_t *p = line;
    while (*p == L' ' || *p == L'\t') p++;
    int kind = LOG_NORMAL;
    if (wcsncmp(p, L"错误", 2) == 0) kind = LOG_ERR;
    else if (wcsncmp(p, L"警告", 2) == 0 || wcsncmp(p, L"注意", 2) == 0) kind = LOG_WARN;
    else if (wcsncmp(p, L"已取消", 3) == 0 || wcsncmp(p, L"已停止", 3) == 0) kind = LOG_WARN;
    else if (wcsncmp(p, L"完成", 2) == 0) kind = LOG_OK;
    else if (*p == L'[') kind = LOG_STAGE;

    EnterCriticalSection(&g_log_cs);
    if (g_log_n == GUI_LOG_CAP) {
        for (int i = 0; i < GUI_LOG_TRIM; i++) free(g_log[i].s);
        memmove(g_log, g_log + GUI_LOG_TRIM,
                (size_t)(GUI_LOG_CAP - GUI_LOG_TRIM) * sizeof(GuiLogLine));
        g_log_n -= GUI_LOG_TRIM;
        g_log_dirty = true; /* 行号整体前移了，显示行必须重排 */
    }
    const size_t n = wcslen(line);
    wchar_t *s = (wchar_t *)malloc((n + 1) * sizeof(wchar_t));
    if (s) {
        memcpy(s, line, (n + 1) * sizeof(wchar_t));
        g_log[g_log_n].s = s;
        g_log[g_log_n].kind = kind;
        g_log_n++;
    }
    LeaveCriticalSection(&g_log_cs);
    PostMessageW(g_hwnd, WM_GUI_LOG, 0, 0);
}

static void gui_progress_sink(int stage, double frac) {
    InterlockedExchange(&g_stage, stage);
    InterlockedExchange(&g_frac_milli, (frac < 0.0) ? -1 : (LONG)(frac * 1000.0 + 0.5));
}

static void gui_log_reset(void) {
    EnterCriticalSection(&g_log_cs);
    for (int i = 0; i < g_log_n; i++) free(g_log[i].s);
    g_log_n = 0;
    g_log_dirty = true;
    LeaveCriticalSection(&g_log_cs);
    gui_rows_clear();
    g_log_scroll = 0.0f;
    g_log_max = 0.0f;
    g_log_follow = true;
}

/* UI 侧：把新增的原始行折成显示行，并算出滚动范围。调用时已持有 g_log_cs。 */
static void gui_log_sync(void) {
    const float width = g_lay.log.w - 34.0f; /* 左右内边距 + 滚动条槽 */
    if (g_log_dirty || width != g_log_width) {
        gui_rows_clear();
        g_log_width = width;
        g_log_dirty = false;
    }
    for (; g_log_wrapped < g_log_n; g_log_wrapped++) gui_log_wrap(g_log_wrapped, width);

    const float view = g_lay.log.h - 12.0f;
    const float total = (float)g_rows_n * g_log_line_h;
    g_log_max = (total > view) ? total - view : 0.0f;
    if (g_log_follow) g_log_scroll = g_log_max;
    else g_log_scroll = gui_clampf(g_log_scroll, 0.0f, g_log_max);

    if (g_log_max > 0.0f) {
        const GuiRect t = g_lay.log_scroll;
        float th = (view / total) * t.h;
        if (th < 24.0f) th = 24.0f;
        if (th > t.h) th = t.h;
        g_thumb = (GuiRect){t.x, t.y + (g_log_scroll / g_log_max) * (t.h - th), t.w, th};
    } else {
        g_thumb = (GuiRect){0, 0, 0, 0};
    }
}

/* -------------------------------- 编辑框 -------------------------------- */

static void gui_sel_range(const GuiEdit *e, int *a, int *b) {
    if (e->caret <= e->anchor) { *a = e->caret; *b = e->anchor; }
    else { *a = e->anchor; *b = e->caret; }
}

/* 光标不要停在代理对中间（一个 emoji 占两个 UTF-16 单元） */
static int gui_step_left(const wchar_t *s, int p) {
    if (p <= 0) return 0;
    p--;
    if (p > 0 && s[p] >= 0xDC00 && s[p] <= 0xDFFF && s[p - 1] >= 0xD800 && s[p - 1] <= 0xDBFF) p--;
    return p;
}

static int gui_step_right(const wchar_t *s, int len, int p) {
    if (p >= len) return len;
    p++;
    if (p < len && s[p - 1] >= 0xD800 && s[p - 1] <= 0xDBFF && s[p] >= 0xDC00 && s[p] <= 0xDFFF) p++;
    return p;
}

static void gui_edit_set(GuiEdit *e, const wchar_t *s) {
    gui_wcopy(e->text, GUI_CAP, s);
    e->len = (int)wcslen(e->text);
    e->caret = e->anchor = e->len;
    e->scroll = 0.0f;
}

/* 用 s[0..n) 替换当前选区（无选区就是在光标处插入） */
static void gui_edit_replace(GuiEdit *e, const wchar_t *s, int n) {
    int a, b;
    gui_sel_range(e, &a, &b);
    const int keep = e->len - (b - a);
    if (n > GUI_CAP - 1 - keep) n = GUI_CAP - 1 - keep;
    if (n < 0) n = 0;
    memmove(e->text + a + n, e->text + b, (size_t)(e->len - b + 1) * sizeof(wchar_t));
    if (n > 0) memcpy(e->text + a, s, (size_t)n * sizeof(wchar_t));
    e->len = keep + n;
    e->text[e->len] = L'\0';
    e->caret = e->anchor = a + n;
}

static void gui_edit_backspace(GuiEdit *e) {
    if (e->caret == e->anchor && e->caret > 0) e->anchor = gui_step_left(e->text, e->caret);
    gui_edit_replace(e, L"", 0);
}

static void gui_edit_delete(GuiEdit *e) {
    if (e->caret == e->anchor && e->caret < e->len) e->anchor = gui_step_right(e->text, e->len, e->caret);
    gui_edit_replace(e, L"", 0);
}

/* 去掉首尾空白与引号：资源管理器“复制为路径”常带双引号 */
static void gui_edit_trim(GuiEdit *e) {
    int b = 0, en = e->len;
    while (b < en && (e->text[b] == L' ' || e->text[b] == L'\t' || e->text[b] == L'"')) b++;
    while (en > b && (e->text[en - 1] == L' ' || e->text[en - 1] == L'\t' || e->text[en - 1] == L'"')) en--;
    if (b == 0 && en == e->len) return;
    const int n = en - b;
    if (n > 0) memmove(e->text, e->text + b, (size_t)n * sizeof(wchar_t));
    e->text[n] = L'\0';
    e->len = n;
    if (e->caret > n) e->caret = n;
    if (e->anchor > n) e->anchor = n;
}

static void gui_edit_select_all(GuiEdit *e) {
    e->anchor = 0;
    e->caret = e->len;
}

static void gui_copy(int i) {
    GuiEdit *e = &g_edit[i];
    int a, b;
    gui_sel_range(e, &a, &b);
    if (a == b || !OpenClipboard(g_hwnd)) return;
    EmptyClipboard();
    const size_t bytes = (size_t)(b - a + 1) * sizeof(wchar_t);
    HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (h) {
        wchar_t *p = (wchar_t *)GlobalLock(h);
        if (p) {
            memcpy(p, e->text + a, (size_t)(b - a) * sizeof(wchar_t));
            p[b - a] = L'\0';
            GlobalUnlock(h);
            if (!SetClipboardData(CF_UNICODETEXT, h)) GlobalFree(h);
        } else {
            GlobalFree(h);
        }
    }
    CloseClipboard();
}

static void gui_paste(int i) {
    if (!OpenClipboard(g_hwnd)) return;
    HANDLE h = GetClipboardData(CF_UNICODETEXT);
    if (h) {
        const wchar_t *p = (const wchar_t *)GlobalLock(h);
        if (p) {
            wchar_t tmp[GUI_CAP];
            int n = 0;
            for (; p[n] && n < GUI_CAP - 1; n++) {
                const wchar_t c = p[n];
                if (c == L'\r' || c == L'\n' || c == L'\t') continue; /* 路径是单行 */
                tmp[n] = c;
            }
            GlobalUnlock(h);
            gui_edit_replace(&g_edit[i], tmp, n);
        }
    }
    CloseClipboard();
}

/* 由输入路径推导默认输出：同目录、同主名 + _dec.mp4 */
static bool gui_derive_output(const wchar_t *in, wchar_t *out, size_t cap) {
    const size_t n = in ? wcslen(in) : 0;
    if (n == 0 || n + 9 > cap) return false;
    size_t dot = n;
    for (size_t i = n; i-- > 0;) {
        if (in[i] == L'.') { dot = i; break; }
        if (in[i] == L'\\' || in[i] == L'/') break; /* 目录里的点不算扩展名 */
    }
    if (dot) memcpy(out, in, dot * sizeof(wchar_t));
    memcpy(out + dot, L"_dec.mp4", 9 * sizeof(wchar_t));
    return true;
}

static bool gui_out_dir_ok(const wchar_t *path) {
    wchar_t dir[GUI_CAP];
    const size_t n = path ? wcslen(path) : 0;
    if (n == 0) return false;
    gui_wcopy(dir, GUI_CAP, path);
    size_t i = n;
    while (i > 0 && dir[i - 1] != L'\\' && dir[i - 1] != L'/') i--;
    if (i == 0) return true; /* 只有文件名：目录就是当前目录 */
    dir[i - 1] = L'\0';
    if (dir[0] == L'\0') return false;
    const DWORD attr = GetFileAttributesW(dir);
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

/* 校验三项参数（含自动补全）；不通过时把原因写进状态行并聚焦到出错字段 */
static bool gui_validate(void) {
    GuiEdit *fin = &g_edit[0], *fout = &g_edit[1], *fff = &g_edit[2];
    gui_edit_trim(fin);
    gui_edit_trim(fout);
    gui_edit_trim(fff);

    if (fin->len == 0) {
        gui_status(B_ERR, L"请先填写输入文件（.ts / .mp4）");
        g_focus = 0;
        return false;
    }
    if (!h5e_is_regular_file(fin->text)) {
        gui_status(B_ERR, L"输入文件不存在，或不是普通文件");
        g_focus = 0;
        return false;
    }
    const wchar_t *iext = h5e_extension_of(fin->text);
    if (!h5e_ext_is(iext, L"ts") && !h5e_ext_is(iext, L"mp4")) {
        gui_status(B_ERR, L"输入格式不支持：只接受 .ts / .mp4");
        g_focus = 0;
        return false;
    }
    if (fout->len == 0) {
        wchar_t derived[GUI_CAP];
        if (!gui_derive_output(fin->text, derived, GUI_CAP)) {
            gui_status(B_ERR, L"输出路径太长，请手动填写输出文件");
            g_focus = 1;
            return false;
        }
        gui_edit_set(fout, derived);
    }
    if (wcscmp(fout->text, fin->text) == 0) {
        gui_status(B_ERR, L"输出文件不能与输入文件相同");
        g_focus = 1;
        return false;
    }
    if (!gui_out_dir_ok(fout->text)) {
        gui_status(B_ERR, L"输出目录不存在，请改选一个已存在的目录");
        g_focus = 1;
        return false;
    }
    wchar_t *p = h5e_find_ffmpeg(fff->len ? fff->text : NULL);
    if (!p) {
        gui_status(B_ERR, fff->len ? L"指定的 ffmpeg 不存在（清空可改回 PATH 搜索）"
                                   : L"PATH 里找不到 ffmpeg.exe，请填写 ffmpeg 路径");
        g_focus = 2;
        return false;
    }
    if (fff->len) gui_edit_set(fff, p); /* 顺手换成解析后的完整路径 */
    free(p);
    return true;
}

/* 设置输入文件，并在输出为空时自动推导 */
static void gui_set_input(const wchar_t *path) {
    gui_edit_set(&g_edit[0], path);
    gui_edit_trim(&g_edit[0]);
    if (g_edit[1].len == 0) {
        wchar_t derived[GUI_CAP];
        if (gui_derive_output(g_edit[0].text, derived, GUI_CAP)) gui_edit_set(&g_edit[1], derived);
    }
    g_focus = 0;
}

/* ------------------------------ 绘制原语 ------------------------------ */

static void gui_fill(GuiRect r, int b) {
    const D2D1_RECT_F d = gui_d2rect(r);
    ID2D1RenderTarget_FillRectangle((ID2D1RenderTarget *)g_rt, &d, g_brush[b]);
}

static void gui_round(GuiRect r, float rad, int b) {
    D2D1_ROUNDED_RECT d;
    d.rect = gui_d2rect(r);
    d.radiusX = rad;
    d.radiusY = rad;
    ID2D1RenderTarget_FillRoundedRectangle((ID2D1RenderTarget *)g_rt, &d, g_brush[b]);
}

static void gui_round_border(GuiRect r, float rad, int b, float thick) {
    D2D1_ROUNDED_RECT d;
    d.rect = gui_d2rect(r);
    d.radiusX = rad;
    d.radiusY = rad;
    ID2D1RenderTarget_DrawRoundedRectangle((ID2D1RenderTarget *)g_rt, &d, g_brush[b], thick, NULL);
}

/* 单行文本，垂直居中，超出矩形裁掉 */
static void gui_text(GuiRect r, const wchar_t *s, int fmt, int b) {
    if (!s || r.w <= 0.0f || r.h <= 0.0f) return;
    const float th = g_fmt_h[fmt];
    GuiRect t = {r.x, r.y + (r.h - th) * 0.5f, r.w, th};
    const D2D1_RECT_F d = gui_d2rect(t);
    ID2D1RenderTarget_DrawText((ID2D1RenderTarget *)g_rt, s, (UINT32)wcslen(s), g_fmt[fmt], &d,
                               g_brush[b], D2D1_DRAW_TEXT_OPTIONS_CLIP,
                               DWRITE_MEASURING_MODE_NATURAL);
}

static void gui_text_n(GuiRect r, const wchar_t *s, int n, int fmt, int b) {
    if (!s || n <= 0 || r.w <= 0.0f) return;
    const D2D1_RECT_F d = gui_d2rect(r);
    ID2D1RenderTarget_DrawText((ID2D1RenderTarget *)g_rt, s, (UINT32)n, g_fmt[fmt], &d, g_brush[b],
                               D2D1_DRAW_TEXT_OPTIONS_NONE, DWRITE_MEASURING_MODE_NATURAL);
}

/* 水平+垂直都居中：按钮文字用，需要 layout 才能拿到对齐能力 */
static void gui_text_center(GuiRect r, const wchar_t *s, int fmt, int b) {
    IDWriteTextLayout *lay = NULL;
    const UINT32 n = (UINT32)wcslen(s);
    if (n == 0 || r.w <= 0.0f ||
        FAILED(IDWriteFactory_CreateTextLayout(g_dw, s, n, g_fmt[fmt], r.w, r.h, &lay)) || !lay) {
        if (lay) IDWriteTextLayout_Release(lay);
        return;
    }
    IDWriteTextLayout_SetTextAlignment(lay, DWRITE_TEXT_ALIGNMENT_CENTER);
    IDWriteTextLayout_SetParagraphAlignment(lay, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
    const D2D1_POINT_2F o = {r.x, r.y};
    ID2D1RenderTarget_DrawTextLayout((ID2D1RenderTarget *)g_rt, o, lay, g_brush[b],
                                     D2D1_DRAW_TEXT_OPTIONS_NONE);
    IDWriteTextLayout_Release(lay);
}

static void gui_push_clip(GuiRect r) {
    const D2D1_RECT_F d = gui_d2rect(r);
    ID2D1RenderTarget_PushAxisAlignedClip((ID2D1RenderTarget *)g_rt, &d,
                                        D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);
}

static void gui_pop_clip(void) {
    ID2D1RenderTarget_PopAxisAlignedClip((ID2D1RenderTarget *)g_rt);
}

/* ------------------------------ 各块绘制 ------------------------------ */

static void gui_draw_button(GuiRect r, const wchar_t *label, int hit, bool enabled, bool primary) {
    int bg, fg;
    if (!enabled) { bg = B_PANEL; fg = B_DIM; }
    else if (g_pressed == hit) { bg = primary ? B_PRIMARY : B_BTN_DN; fg = B_TEXT; }
    else if (g_hot == hit) { bg = primary ? B_PRI_HOV : B_BTN_HOV; fg = B_TEXT; }
    else { bg = primary ? B_PRIMARY : B_BTN; fg = B_TEXT; }
    gui_round(r, 5.0f, bg);
    if (!primary) gui_round_border(r, 5.0f, B_BORDER, 1.0f);
    gui_text_center(r, label, F_BTN, fg);
}

static void gui_draw_field(int i, IDWriteTextLayout *lay) {
    const GuiRect r = g_lay.field[i];
    const GuiEdit *e = &g_edit[i];
    const bool foc = (g_focus == i);
    gui_round(r, 4.0f, B_FIELD);
    gui_round_border(r, 4.0f, foc ? B_FOCUS : B_BORDER, foc ? 1.6f : 1.0f);

    const GuiRect inner = {r.x + 8.0f, r.y, r.w - 16.0f, r.h};
    if (inner.w <= 4.0f) return;
    gui_push_clip(inner);
    if (e->len == 0) {
        gui_text(inner, gui_placeholder[i], F_BODY, foc ? B_DIM : B_BORDER);
    } else {
        const float sx = inner.x - e->scroll;
        if (foc && g_fm[i].sel_b > g_fm[i].sel_a) {
            gui_fill((GuiRect){sx + g_fm[i].sel_a, r.y + 5.0f,
                               g_fm[i].sel_b - g_fm[i].sel_a, r.h - 10.0f}, B_SEL);
        }
        const float th = g_fmt_h[F_BODY];
        gui_text_n((GuiRect){sx, r.y + (r.h - th) * 0.5f, 1000000.0f, th}, e->text, e->len,
                   F_BODY, B_TEXT);
        if (foc && g_caret_on && e->caret == e->anchor) {
            gui_fill((GuiRect){sx + g_fm[i].caret_x, r.y + 6.0f, 1.0f, r.h - 12.0f}, B_TEXT);
        }
    }
    gui_pop_clip();
}

/* 量一个字段：总宽、光标与选区的 x，并据此调整横向滚动。lay 由调用方建好/释放。 */
static void gui_field_measure(int i, IDWriteTextLayout *lay) {
    GuiEdit *e = &g_edit[i];
    const float inner_w = g_lay.field[i].w - 16.0f;
    g_fm[i] = (GuiFieldMetrics){0, 0, 0, 0};
    if (inner_w < 4.0f) return;

    float total = 0.0f, cx = 0.0f, sa = 0.0f, sb = 0.0f;
    if (lay) {
        DWRITE_TEXT_METRICS m;
        if (SUCCEEDED(IDWriteTextLayout_GetMetrics(lay, &m))) total = m.widthIncludingTrailingWhitespace;
        DWRITE_HIT_TEST_METRICS hm;
        float x = 0.0f, y = 0.0f;
        if (e->caret >= e->len) cx = total;
        else if (SUCCEEDED(IDWriteTextLayout_HitTestTextPosition(lay, (UINT32)e->caret, FALSE, &x, &y, &hm)))
            cx = x;
        int a, b;
        gui_sel_range(e, &a, &b);
        if (a != b) {
            if (a >= e->len) sa = total;
            else if (SUCCEEDED(IDWriteTextLayout_HitTestTextPosition(lay, (UINT32)a, FALSE, &x, &y, &hm)))
                sa = x;
            if (b >= e->len) sb = total;
            else if (SUCCEEDED(IDWriteTextLayout_HitTestTextPosition(lay, (UINT32)b, FALSE, &x, &y, &hm)))
                sb = x;
        }
    }
    if (g_focus == i) { /* 聚焦时保证光标可见 */
        if (cx - e->scroll < 0.0f) e->scroll = cx;
        if (cx - e->scroll > inner_w - 2.0f) e->scroll = cx - inner_w + 2.0f;
    } else { /* 失焦时露出尾部：文件名在尾巴上 */
        e->scroll = (total > inner_w) ? total - inner_w : 0.0f;
    }
    if (e->scroll < 0.0f) e->scroll = 0.0f;
    g_fm[i].caret_x = cx;
    g_fm[i].sel_a = sa;
    g_fm[i].sel_b = sb;
    g_fm[i].total = total;
}

/* 把输入法组字窗摆到光标处；只在焦点/光标/滚动变化时调用，避免每帧打扰 IME */
static void gui_ime_place(void) {
    static int last_focus = -99, last_caret = -1;
    static float last_scroll = -1.0f;
    if (g_focus < 0) { last_focus = -99; return; }
    const GuiEdit *e = &g_edit[g_focus];
    if (g_focus == last_focus && e->caret == last_caret && e->scroll == last_scroll) return;
    last_focus = g_focus;
    last_caret = e->caret;
    last_scroll = e->scroll;
    HIMC imc = ImmGetContext(g_hwnd);
    if (!imc) return;
    const GuiRect r = g_lay.field[g_focus];
    COMPOSITIONFORM cf;
    cf.dwStyle = CFS_POINT;
    cf.ptCurrentPos.x = (LONG)((r.x + 8.0f + g_fm[g_focus].caret_x - e->scroll) * g_dpi / 96.0f);
    cf.ptCurrentPos.y = (LONG)((r.y + r.h - 4.0f) * g_dpi / 96.0f);
    cf.rcArea.left = cf.rcArea.top = cf.rcArea.right = cf.rcArea.bottom = 0;
    ImmSetCompositionWindow(imc, &cf);
    ImmReleaseContext(g_hwnd, imc);
}

static const wchar_t *gui_stage_name(LONG s) {
    switch (s) {
        case 1: return L"FFmpeg 转封装：分片 MP4 + 音频旁路";
        case 2: return L"解密 MP4 视频样本";
        case 3: return L"FFmpeg 合成最终 MP4";
        default: return L"就绪";
    }
}

static void gui_draw_progress(void) {
    const GuiRect r = g_lay.progress;
    gui_round(r, 3.0f, B_TRACK);
    const LONG stage = g_stage, milli = g_frac_milli;
    if (stage > 0) {
        if (milli < 0) { /* 跑马灯：ffmpeg 阶段拿不到可靠总量 */
            const float bw = r.w * 0.28f;
            const float x = r.x + g_anim * (r.w + bw) - bw;
            gui_push_clip(r);
            gui_round((GuiRect){x, r.y, bw, r.h}, 3.0f, B_ACCENT);
            gui_pop_clip();
        } else {
            const float f = gui_clampf((float)milli / 1000.0f, 0.0f, 1.0f);
            if (f > 0.004f) gui_round((GuiRect){r.x, r.y, r.w * f, r.h}, 3.0f, B_ACCENT);
        }
    }
    wchar_t buf[192];
    if (stage <= 0) swprintf(buf, 192, L"就绪 · 三个阶段：转封装 → 解密 → 合成");
    else if (milli < 0) swprintf(buf, 192, L"阶段 %d/3 · %s", (int)stage, gui_stage_name(stage));
    else swprintf(buf, 192, L"阶段 %d/3 · %s · %d%%", (int)stage, gui_stage_name(stage),
                  (int)((milli + 5) / 10));
    gui_text(g_lay.stage, buf, F_SMALL, stage > 0 ? B_ACCENT : B_DIM);
}

/* 调用时已持有 g_log_cs：绘制期间工作线程不能丢弃/搬移原始行 */
static void gui_draw_log(void) {
    const GuiRect r = g_lay.log;
    gui_round(r, 5.0f, B_FIELD);
    gui_round_border(r, 5.0f, B_BORDER, 1.0f);
    const GuiRect inner = {r.x + 10.0f, r.y + 6.0f, r.w - 34.0f, r.h - 12.0f};
    if (inner.w <= 0.0f || inner.h <= 0.0f) return;

    gui_push_clip(inner);
    if (g_rows_n == 0) {
        gui_text((GuiRect){inner.x, inner.y, inner.w, g_log_line_h},
                 L"运行日志显示在这里。可以把 .ts / .mp4 文件直接拖进窗口。", F_LOG, B_DIM);
    } else {
        int first = (int)(g_log_scroll / g_log_line_h);
        if (first < 0) first = 0;
        const float frac = g_log_scroll - (float)first * g_log_line_h;
        for (int i = first; i < g_rows_n; i++) {
            const float y = inner.y + (float)(i - first) * g_log_line_h - frac;
            if (y >= inner.y + inner.h) break;
            if (y + g_log_line_h <= inner.y) continue;
            const GuiLogRow *row = &g_rows[i];
            if (row->line < 0 || row->line >= g_log_n) continue;
            const GuiLogLine *ln = &g_log[row->line];
            int n = row->len;
            if (row->off < 0 || row->off + n > (int)wcslen(ln->s)) continue;
            int b = B_LOGTEXT;
            switch (ln->kind) {
                case LOG_STAGE: b = B_ACCENT; break;
                case LOG_OK: b = B_OK; break;
                case LOG_ERR: b = B_ERR; break;
                case LOG_WARN: b = B_WARN; break;
                default: break;
            }
            gui_text_n((GuiRect){inner.x, y, inner.w, g_log_line_h}, ln->s + row->off, n, F_LOG, b);
        }
    }
    gui_pop_clip();

    if (g_log_max > 0.0f) {
        gui_round(g_lay.log_scroll, 4.0f, B_PANEL);
        gui_round(g_thumb, 4.0f, (g_hot == HIT_SCROLL || g_drag_scroll) ? B_BTN_HOV : B_BORDER);
    }
}

static void gui_paint(void) {
    if (!gui_rt_create()) return;
    gui_layout_update();

    /* 先量三个编辑框（layout 只在本帧存活），顺带把输入法组字窗摆好 */
    IDWriteTextLayout *lays[3] = {NULL, NULL, NULL};
    for (int i = 0; i < 3; i++) {
        const GuiEdit *e = &g_edit[i];
        if (e->len > 0 &&
            SUCCEEDED(IDWriteFactory_CreateTextLayout(g_dw, e->text, (UINT32)e->len, g_fmt[F_BODY],
                                                      1000000.0f, g_lay.field[i].h, &lays[i])) && lays[i]) {
            IDWriteTextLayout_SetWordWrapping(lays[i], DWRITE_WORD_WRAPPING_NO_WRAP);
        }
        gui_field_measure(i, lays[i]);
    }
    gui_ime_place();

    ID2D1RenderTarget *rt = (ID2D1RenderTarget *)g_rt;
    ID2D1RenderTarget_BeginDraw(rt);
    const unsigned bg = gui_palette[B_BG];
    D2D1_COLOR_F clear;
    clear.r = (float)((bg >> 16) & 255) / 255.0f;
    clear.g = (float)((bg >> 8) & 255) / 255.0f;
    clear.b = (float)(bg & 255) / 255.0f;
    clear.a = 1.0f;
    ID2D1RenderTarget_Clear(rt, &clear);

    gui_text(g_lay.title, L"cctv_h5e 视频解密", F_TITLE, B_TEXT);
    /* 版本号右对齐：DrawText 没有右对齐选项，用 layout 量一次宽度 */
    {
        IDWriteTextLayout *lay = NULL;
        const UINT32 n = (UINT32)wcslen(g_version_w);
        float vw = 0.0f;
        if (SUCCEEDED(IDWriteFactory_CreateTextLayout(g_dw, g_version_w, n, g_fmt[F_SMALL],
                                                      100000.0f, 100.0f, &lay)) && lay) {
            DWRITE_TEXT_METRICS m;
            if (SUCCEEDED(IDWriteTextLayout_GetMetrics(lay, &m))) vw = m.width;
            IDWriteTextLayout_Release(lay);
        }
        const float x = g_lay.w - 16.0f - vw;
        gui_text((GuiRect){x > 16.0f ? x : 16.0f, g_lay.version.y, g_lay.w - 16.0f - (x > 16.0f ? x : 16.0f),
                           g_lay.version.h}, g_version_w, F_SMALL, B_DIM);
    }
    gui_text(g_lay.subtitle, L"输入 → FFmpeg 分片 MP4 → NAL 解密 → FFmpeg MP4（音频旁路，全程 -c copy）",
             F_SMALL, B_DIM);
    gui_fill((GuiRect){16.0f, g_lay.sep_y, g_lay.w - 32.0f, 1.0f}, B_BORDER);

    const bool running = (g_running != 0);
    for (int i = 0; i < 3; i++) {
        gui_text(g_lay.label[i], gui_label[i], F_BODY, g_focus == i ? B_ACCENT : B_DIM);
        gui_draw_field(i, lays[i]);
        gui_draw_button(g_lay.browse[i], L"浏览…", HIT_BROWSE0 + i, !running, false);
    }

    gui_draw_progress();
    gui_text(g_lay.status, g_status[0] ? g_status : L"填写路径后点“开始处理”，或按 Enter",
             F_BODY, g_status[0] ? g_status_kind : B_DIM);

    gui_draw_button(g_lay.start, running ? L"处理中…" : L"开始处理", HIT_START, !running, true);
    gui_draw_button(g_lay.stop, L"停止", HIT_STOP, running, false);
    gui_draw_button(g_lay.exit, L"退出", HIT_EXIT, true, false);

    /* 日志放最后：sync 与绘制都在同一把锁里，行号与字符串不会被工作线程搬走 */
    if (g_cs_ready) EnterCriticalSection(&g_log_cs);
    gui_log_sync();
    gui_draw_log();
    if (g_cs_ready) LeaveCriticalSection(&g_log_cs);

    const HRESULT hr = ID2D1RenderTarget_EndDraw(rt, NULL, NULL);
    for (int i = 0; i < 3; i++) if (lays[i]) IDWriteTextLayout_Release(lays[i]);
    if (hr == D2DERR_RECREATE_TARGET) { /* 设备丢失（休眠/换显卡/远程桌面重连） */
        gui_rt_release();
        gui_invalidate();
    }
}

/* ------------------------------- 命中测试 ------------------------------- */

static int gui_hit(float x, float y) {
    for (int i = 0; i < 3; i++) {
        if (gui_inside(g_lay.field[i], x, y)) return HIT_FIELD0 + i;
        if (gui_inside(g_lay.browse[i], x, y)) return HIT_BROWSE0 + i;
    }
    if (gui_inside(g_lay.start, x, y)) return HIT_START;
    if (gui_inside(g_lay.stop, x, y)) return HIT_STOP;
    if (gui_inside(g_lay.exit, x, y)) return HIT_EXIT;
    if (g_log_max > 0.0f && gui_inside(g_lay.log_scroll, x, y)) return HIT_SCROLL;
    if (gui_inside(g_lay.log, x, y)) return HIT_LOG;
    return HIT_NONE;
}

/* 鼠标横坐标 → 字段里的字符下标。单行字段，所以 y 固定取行内，只看 x。 */
static int gui_field_pos(int i, float mx) {
    const GuiEdit *e = &g_edit[i];
    if (e->len == 0) return 0;
    IDWriteTextLayout *lay = NULL;
    if (FAILED(IDWriteFactory_CreateTextLayout(g_dw, e->text, (UINT32)e->len, g_fmt[F_BODY],
                                               1000000.0f, 100.0f, &lay)) || !lay)
        return e->caret;
    IDWriteTextLayout_SetWordWrapping(lay, DWRITE_WORD_WRAPPING_NO_WRAP);
    const float px = mx - (g_lay.field[i].x + 8.0f) + e->scroll;
    BOOL trailing = FALSE, inside = FALSE;
    DWRITE_HIT_TEST_METRICS m;
    int pos = e->len;
    if (SUCCEEDED(IDWriteTextLayout_HitTestPoint(lay, px, 5.0f, &trailing, &inside, &m)))
        pos = (int)m.textPosition + (trailing ? (int)m.length : 0);
    IDWriteTextLayout_Release(lay);
    if (pos < 0) pos = 0;
    if (pos > e->len) pos = e->len;
    return pos;
}

static void gui_set_caret(int i, int pos, bool extend) {
    GuiEdit *e = &g_edit[i];
    if (pos < 0) pos = 0;
    if (pos > e->len) pos = e->len;
    e->caret = pos;
    if (!extend) e->anchor = pos;
    g_caret_on = true;
}

/* --------------------------------- 动作 --------------------------------- */

static void gui_stop(void) {
    if (!g_running) return;
    InterlockedExchange(&g_cancel, 1);
    gui_status(B_WARN, L"正在停止：等当前分片/ffmpeg 子进程收尾…");
    gui_invalidate();
}

static DWORD WINAPI gui_worker(LPVOID arg) {
    (void)arg;
    const int rc = h5e_pipeline(g_job_in, g_job_out, g_job_ff[0] ? g_job_ff : NULL);
    /* 流水线已返回，之后不会再有日志；摘掉钩子，界面不再被工作线程写入 */
    g_log_sink = NULL;
    g_progress_sink = NULL;
    InterlockedExchange(&g_stage, 0);
    InterlockedExchange(&g_frac_milli, -1);
    InterlockedExchange(&g_running, 0);
    PostMessageW(g_hwnd, WM_GUI_DONE, (WPARAM)rc, 0);
    return 0;
}

static void gui_start(void) {
    if (g_running) return;
    if (!gui_validate()) {
        gui_invalidate();
        return;
    }
    gui_log_reset();
    gui_wcopy(g_job_in, GUI_CAP, g_edit[0].text);
    gui_wcopy(g_job_out, GUI_CAP, g_edit[1].text);
    gui_wcopy(g_job_ff, GUI_CAP, g_edit[2].text);
    InterlockedExchange(&g_cancel, 0);
    InterlockedExchange(&g_stage, 0);
    InterlockedExchange(&g_frac_milli, -1);
    g_log_sink = gui_log_sink;
    g_progress_sink = gui_progress_sink;
    InterlockedExchange(&g_running, 1);
    gui_status(B_DIM, L"正在处理，可随时点“停止”中止");
    g_focus = -1;
    g_anim = 0.0f;
    SetTimer(g_hwnd, GUI_TIMER_ANIM, 33, NULL);
    g_thread = CreateThread(NULL, 0, gui_worker, NULL, 0, NULL);
    if (!g_thread) {
        KillTimer(g_hwnd, GUI_TIMER_ANIM);
        g_log_sink = NULL;
        g_progress_sink = NULL;
        InterlockedExchange(&g_running, 0);
        gui_status(B_ERR, L"无法创建工作线程（错误 %lu）", (unsigned long)GetLastError());
    }
    gui_invalidate();
}

/* 原生文件对话框：comdlg32 自带输入法、缩略图与最近位置，比自绘浏览器可靠得多 */
static void gui_browse(int i) {
    wchar_t file[GUI_CAP];
    file[0] = L'\0';
    if (i == 1) {
        if (g_edit[1].len) gui_wcopy(file, GUI_CAP, g_edit[1].text);
        else if (g_edit[0].len) {
            wchar_t derived[GUI_CAP];
            if (gui_derive_output(g_edit[0].text, derived, GUI_CAP)) gui_wcopy(file, GUI_CAP, derived);
        }
    } else if (g_edit[i].len) {
        gui_wcopy(file, GUI_CAP, g_edit[i].text);
    }

    /* 起始目录：取当前值的父目录，没有就用当前工作目录 */
    wchar_t initdir[GUI_CAP];
    initdir[0] = L'\0';
    {
        wchar_t tmp[GUI_CAP];
        gui_wcopy(tmp, GUI_CAP, file);
        size_t n = wcslen(tmp);
        while (n > 0 && tmp[n - 1] != L'\\' && tmp[n - 1] != L'/') n--;
        if (n > 1) {
            tmp[n - 1] = L'\0';
            if (GetFileAttributesW(tmp) != INVALID_FILE_ATTRIBUTES) gui_wcopy(initdir, GUI_CAP, tmp);
        }
    }

    OPENFILENAMEW ofn;
    memset(&ofn, 0, sizeof ofn);
    ofn.lStructSize = sizeof ofn;
    ofn.hwndOwner = g_hwnd;
    ofn.hInstance = g_inst;
    ofn.lpstrFile = file;
    ofn.nMaxFile = GUI_CAP;
    ofn.lpstrInitialDir = initdir[0] ? initdir : NULL;
    ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | OFN_HIDEREADONLY;
    bool ok = false;
    if (i == 0) {
        ofn.lpstrFilter = L"媒体文件 (*.ts;*.mp4)\0*.ts;*.mp4\0所有文件 (*.*)\0*.*\0";
        ofn.lpstrTitle = L"选择输入文件";
        ofn.lpstrDefExt = L"ts";
        ofn.Flags |= OFN_FILEMUSTEXIST;
        ok = GetOpenFileNameW(&ofn) != 0;
    } else if (i == 2) {
        ofn.lpstrFilter = L"ffmpeg.exe\0ffmpeg.exe\0可执行文件 (*.exe)\0*.exe\0";
        ofn.lpstrTitle = L"选择 ffmpeg.exe";
        ofn.lpstrDefExt = L"exe";
        ofn.Flags |= OFN_FILEMUSTEXIST;
        ok = GetOpenFileNameW(&ofn) != 0;
    } else {
        ofn.lpstrFilter = L"MP4 视频 (*.mp4)\0*.mp4\0所有文件 (*.*)\0*.*\0";
        ofn.lpstrTitle = L"选择输出文件";
        ofn.lpstrDefExt = L"mp4";
        ofn.Flags |= OFN_OVERWRITEPROMPT;
        ok = GetSaveFileNameW(&ofn) != 0;
    }
    if (!ok) return;
    if (i == 0) gui_set_input(file);
    else gui_edit_set(&g_edit[i], file);
    g_focus = i;
    gui_status(B_DIM, L"已填入路径，点“开始处理”或按 Enter");
    gui_invalidate();
}

static void gui_activate(int hit) {
    switch (hit) {
        case HIT_BROWSE0: gui_browse(0); break;
        case HIT_BROWSE1: gui_browse(1); break;
        case HIT_BROWSE2: gui_browse(2); break;
        case HIT_START: gui_start(); break;
        case HIT_STOP: gui_stop(); break;
        case HIT_EXIT: PostMessageW(g_hwnd, WM_CLOSE, 0, 0); break;
        default: break;
    }
}

static void gui_log_scroll_by(float dy) {
    g_log_scroll = gui_clampf(g_log_scroll + dy, 0.0f, g_log_max);
    g_log_follow = (g_log_scroll >= g_log_max - 0.5f);
    gui_invalidate();
}

/* -------------------------------- 窗口过程 -------------------------------- */

static LRESULT CALLBACK gui_wndproc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE:
            g_hwnd = hwnd;
            g_dpi = gui_screen_dpi();
            DragAcceptFiles(hwnd, TRUE);
            SetTimer(hwnd, GUI_TIMER_CARET, 530, NULL);
            return 0;

        case WM_ERASEBKGND:
            return 1; /* 背景由 D2D 画，别让 GDI 先刷一遍造成闪烁 */

        case WM_SIZE:
            gui_rt_resize();
            gui_invalidate();
            return 0;

        case WM_DPICHANGED: {
            g_dpi = (float)HIWORD(wParam);
            if (g_dpi < 48.0f || g_dpi > 960.0f) g_dpi = 96.0f;
            const RECT *r = (const RECT *)lParam;
            SetWindowPos(hwnd, NULL, r->left, r->top, r->right - r->left, r->bottom - r->top,
                         SWP_NOZORDER | SWP_NOACTIVATE);
            gui_rt_release(); /* DPI 变了要按新 DPI 重建渲染目标 */
            gui_invalidate();
            return 0;
        }

        case WM_GETMINMAXINFO: {
            MINMAXINFO *mmi = (MINMAXINFO *)lParam;
            const float s = g_dpi / 96.0f;
            RECT wr = {0, 0, (LONG)(GUI_MIN_W * s), (LONG)(GUI_MIN_H * s)};
            const DWORD style = (DWORD)GetWindowLongPtrW(hwnd, GWL_STYLE);
            const DWORD ex = (DWORD)GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
            AdjustWindowRectEx(&wr, style, FALSE, ex);
            mmi->ptMinTrackSize.x = wr.right - wr.left;
            mmi->ptMinTrackSize.y = wr.bottom - wr.top;
            return 0;
        }

        case WM_PAINT: {
            PAINTSTRUCT ps;
            BeginPaint(hwnd, &ps);
            gui_paint();
            EndPaint(hwnd, &ps);
            return 0;
        }

        case WM_TIMER:
            if (wParam == GUI_TIMER_CARET) {
                g_caret_on = !g_caret_on;
                if (g_focus >= 0) gui_invalidate();
            } else if (wParam == GUI_TIMER_ANIM) {
                g_anim += 0.022f;
                if (g_anim > 1.0f) g_anim -= 1.0f;
                gui_invalidate();
            }
            return 0;

        case WM_GUI_LOG:
            gui_invalidate(); /* 真正的折行在 gui_paint → gui_log_sync 里做 */
            return 0;

        case WM_GUI_DONE: {
            const int rc = (int)wParam;
            KillTimer(hwnd, GUI_TIMER_ANIM);
            if (g_thread) { CloseHandle(g_thread); g_thread = NULL; }
            g_final_rc = rc;
            g_log_follow = true;
            if (rc == H5E_RC_OK) gui_status(B_OK, L"完成：%s", g_job_out);
            else if (rc == H5E_RC_CANCELLED) gui_status(B_WARN, L"已停止：临时文件已清理，未产出成品");
            else gui_status(B_ERR, L"处理失败（退出码 %d），详见下方日志", rc);
            if (GetForegroundWindow() != hwnd) {
                FLASHWINFO fi;
                fi.cbSize = sizeof fi;
                fi.hwnd = hwnd;
                fi.dwFlags = FLASHW_TRAY | FLASHW_TIMERNOFG;
                fi.uCount = 0;
                fi.dwTimeout = 0;
                FlashWindowEx(&fi);
            }
            gui_invalidate();
            if (g_close_when_done) DestroyWindow(hwnd);
            return 0;
        }

        case WM_MOUSEMOVE: {
            gui_layout_update();
            const float x = gui_px2dip_x(GET_X_LPARAM(lParam));
            const float y = gui_px2dip_y(GET_Y_LPARAM(lParam));
            if (g_drag_field >= 0) {
                gui_set_caret(g_drag_field, gui_field_pos(g_drag_field, x), true);
                gui_invalidate();
            } else if (g_drag_scroll) {
                const GuiRect t = g_lay.log_scroll;
                const float span = t.h - g_thumb.h;
                if (span > 0.0f)
                    g_log_scroll = gui_clampf((y - g_drag_scroll_off - t.y) / span * g_log_max,
                                              0.0f, g_log_max);
                g_log_follow = (g_log_scroll >= g_log_max - 0.5f);
                gui_invalidate();
            }
            const int hot = gui_hit(x, y);
            if (hot != g_hot) {
                g_hot = hot;
                gui_invalidate();
            }
            LPCWSTR cur = IDC_ARROW;
            if (hot >= HIT_FIELD0 && hot <= HIT_FIELD2) cur = IDC_IBEAM;
            else if ((hot >= HIT_BROWSE0 && hot <= HIT_BROWSE2) || hot == HIT_START ||
                     hot == HIT_STOP || hot == HIT_EXIT) cur = IDC_HAND;
            SetCursor(LoadCursorW(NULL, cur));
            return 0;
        }

        case WM_LBUTTONDOWN: {
            gui_layout_update();
            const float x = gui_px2dip_x(GET_X_LPARAM(lParam));
            const float y = gui_px2dip_y(GET_Y_LPARAM(lParam));
            const int hit = gui_hit(x, y);
            SetCapture(hwnd);
            g_pressed = hit;
            if (hit >= HIT_FIELD0 && hit <= HIT_FIELD2) {
                const int i = hit - HIT_FIELD0;
                g_focus = i;
                const bool shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
                gui_set_caret(i, gui_field_pos(i, x), shift);
                g_drag_field = i;
                g_caret_on = true;
            } else if (hit == HIT_SCROLL) {
                if (gui_inside(g_thumb, x, y)) {
                    g_drag_scroll = true;
                    g_drag_scroll_off = y - g_thumb.y;
                } else {
                    gui_log_scroll_by((y > g_thumb.y ? 1.0f : -1.0f) * (g_lay.log.h - 12.0f));
                }
            } else if (hit != HIT_LOG) {
                g_focus = -1; /* 点按钮/空白：编辑框失去焦点，光标不再闪 */
            }
            gui_invalidate();
            return 0;
        }

        case WM_LBUTTONUP: {
            /* 顺序要紧：ReleaseCapture() 会同步发送 WM_CAPTURECHANGED，
             * 那个分支会清掉 g_pressed，所以先取走再释放捕获。 */
            const int pressed = g_pressed;
            ReleaseCapture();
            gui_layout_update();
            const float x = gui_px2dip_x(GET_X_LPARAM(lParam));
            const float y = gui_px2dip_y(GET_Y_LPARAM(lParam));
            const int hit = gui_hit(x, y);
            g_pressed = HIT_NONE;
            g_drag_field = -1;
            g_drag_scroll = false;
            if (pressed != HIT_NONE && pressed == hit) gui_activate(hit);
            gui_invalidate();
            return 0;
        }

        case WM_LBUTTONDBLCLK: {
            gui_layout_update();
            const float x = gui_px2dip_x(GET_X_LPARAM(lParam));
            const float y = gui_px2dip_y(GET_Y_LPARAM(lParam));
            const int hit = gui_hit(x, y);
            if (hit >= HIT_FIELD0 && hit <= HIT_FIELD2) {
                g_focus = hit - HIT_FIELD0;
                gui_edit_select_all(&g_edit[g_focus]);
                gui_invalidate();
            }
            return 0;
        }

        case WM_CAPTURECHANGED:
            g_pressed = HIT_NONE;
            g_drag_field = -1;
            g_drag_scroll = false;
            return 0;

        case WM_MOUSEWHEEL: {
            gui_layout_update();
            POINT pt = {GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)};
            ScreenToClient(hwnd, &pt);
            const float x = gui_px2dip_x(pt.x), y = gui_px2dip_y(pt.y);
            if (gui_inside(g_lay.log, x, y)) {
                const float lines = (float)GET_WHEEL_DELTA_WPARAM(wParam) / (float)WHEEL_DELTA;
                gui_log_scroll_by(-lines * 3.0f * g_log_line_h);
            }
            return 0;
        }

        case WM_SETCURSOR:
            if (LOWORD(lParam) == HTCLIENT) return TRUE; /* 光标由 WM_MOUSEMOVE 决定 */
            break;

        case WM_KEYDOWN: {
            if (g_running && wParam != VK_ESCAPE) {
                /* 运行中只允许停止与关闭，其余按键不改字段，避免与正在跑的任务混淆 */
                if (wParam == VK_F2) return 0;
            }
            const bool shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
            const bool ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
            switch (wParam) {
                case VK_TAB:
                    g_focus = (g_focus < 0) ? (shift ? 2 : 0) : (g_focus + (shift ? 2 : 1)) % 3;
                    g_caret_on = true;
                    gui_invalidate();
                    return 0;
                case VK_RETURN:
                    gui_start();
                    return 0;
                case VK_ESCAPE:
                    PostMessageW(hwnd, WM_CLOSE, 0, 0);
                    return 0;
                case VK_F2:
                    if (!g_running) gui_browse(g_focus < 0 ? 0 : g_focus);
                    return 0;
                default: break;
            }
            if (g_focus < 0 || g_running) return 0;
            GuiEdit *e = &g_edit[g_focus];
            switch (wParam) {
                case VK_LEFT:
                    gui_set_caret(g_focus, ctrl ? 0 : gui_step_left(e->text, e->caret), shift);
                    break;
                case VK_RIGHT:
                    gui_set_caret(g_focus, ctrl ? e->len : gui_step_right(e->text, e->len, e->caret), shift);
                    break;
                case VK_HOME:
                    gui_set_caret(g_focus, 0, shift);
                    break;
                case VK_END:
                    gui_set_caret(g_focus, e->len, shift);
                    break;
                case VK_BACK:
                    gui_edit_backspace(e);
                    break;
                case VK_DELETE:
                    gui_edit_delete(e);
                    break;
                case 'A':
                    if (ctrl) gui_edit_select_all(e);
                    break;
                case 'C':
                    if (ctrl) gui_copy(g_focus);
                    break;
                case 'X':
                    if (ctrl) { gui_copy(g_focus); gui_edit_replace(e, L"", 0); }
                    break;
                case 'V':
                    if (ctrl) gui_paste(g_focus);
                    break;
                default:
                    return 0;
            }
            g_caret_on = true;
            if (g_status_kind == B_ERR) gui_status(B_DIM, L"");
            gui_invalidate();
            return 0;
        }

        case WM_CHAR: {
            const wchar_t c = (wchar_t)wParam;
            /* 回车/退格/Tab/Esc 已在 WM_KEYDOWN 处理；Ctrl+字母 会产生 0x01..0x1A */
            if (c < 0x20 || c == 0x7F || g_focus < 0 || g_running) return 0;
            gui_edit_replace(&g_edit[g_focus], &c, 1);
            g_caret_on = true;
            if (g_status_kind == B_ERR) gui_status(B_DIM, L"");
            gui_invalidate();
            return 0;
        }

        case WM_IME_COMPOSITION:
            /* 只接“组字结果”。组字过程与候选窗不接管，交给输入法自己画，
             * 位置由 gui_ime_place() 通过 ImmSetCompositionWindow 指定。 */
            if ((lParam & GCS_RESULTSTR) && g_focus >= 0 && !g_running) {
                HIMC imc = ImmGetContext(hwnd);
                if (imc) {
                    const LONG bytes = ImmGetCompositionStringW(imc, GCS_RESULTSTR, NULL, 0);
                    if (bytes > 0) {
                        wchar_t *buf = (wchar_t *)malloc((size_t)bytes + sizeof(wchar_t));
                        if (buf) {
                            ImmGetCompositionStringW(imc, GCS_RESULTSTR, buf, (DWORD)bytes);
                            buf[bytes / (LONG)sizeof(wchar_t)] = L'\0';
                            gui_edit_replace(&g_edit[g_focus], buf, (int)wcslen(buf));
                            free(buf);
                            g_caret_on = true;
                            gui_invalidate();
                        }
                    }
                    ImmReleaseContext(hwnd, imc);
                }
                return 0; /* 已处理，别再让 DefWindowProc 转成 WM_IME_CHAR 重复插入 */
            }
            break;

        case WM_DROPFILES: {
            HDROP hd = (HDROP)wParam;
            wchar_t path[GUI_CAP];
            if (DragQueryFileW(hd, 0, path, GUI_CAP) > 0 && !g_running) {
                const wchar_t *ext = h5e_extension_of(path);
                if (h5e_ext_is(ext, L"ts") || h5e_ext_is(ext, L"mp4")) {
                    gui_set_input(path);
                    gui_status(B_DIM, L"已拖入输入文件，点“开始处理”或按 Enter");
                } else if (h5e_ext_is(ext, L"exe")) {
                    gui_edit_set(&g_edit[2], path);
                    g_focus = 2;
                    gui_status(B_DIM, L"已把拖入的可执行文件填到 ffmpeg 栏");
                } else {
                    gui_status(B_WARN, L"拖入的文件不是 .ts / .mp4（也不是 .exe），已忽略");
                }
                gui_invalidate();
            }
            DragFinish(hd);
            return 0;
        }

        case WM_CLOSE:
            if (g_running) {
                if (MessageBoxW(hwnd, L"任务还在跑，确定要中止并退出吗？", L"cctv_h5e 解密",
                                MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES)
                    return 0;
                g_close_when_done = true;
                gui_stop();
                return 0; /* 等工作线程报 WM_GUI_DONE 再真正销毁 */
            }
            DestroyWindow(hwnd);
            return 0;

        case WM_DESTROY: {
            KillTimer(hwnd, GUI_TIMER_CARET);
            KillTimer(hwnd, GUI_TIMER_ANIM);
            DragAcceptFiles(hwnd, FALSE);
            g_hwnd = NULL;
            if (g_thread) { /* 兜底：正常路径不会走到这里 */
                InterlockedExchange(&g_cancel, 1);
                WaitForSingleObject(g_thread, 5000);
                CloseHandle(g_thread);
                g_thread = NULL;
            }
            g_log_sink = NULL;
            g_progress_sink = NULL;
            gui_rt_release();
            gui_formats_release();
            if (g_dw) { IDWriteFactory_Release(g_dw); g_dw = NULL; }
            if (g_d2d) { ID2D1Factory_Release(g_d2d); g_d2d = NULL; }
            if (g_cs_ready) {
                EnterCriticalSection(&g_log_cs);
                for (int i = 0; i < g_log_n; i++) free(g_log[i].s);
                g_log_n = 0;
                LeaveCriticalSection(&g_log_cs);
                DeleteCriticalSection(&g_log_cs);
                g_cs_ready = false;
            }
            free(g_rows);
            g_rows = NULL;
            g_rows_n = g_rows_cap = 0;
            PostQuitMessage(g_final_rc);
            return 0;
        }

        default: break;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

/* -------------------------------- 启动 -------------------------------- */

static bool gui_init_objects(void) {
    D2D1_FACTORY_OPTIONS opt;
    opt.debugLevel = D2D1_DEBUG_LEVEL_NONE;
    if (FAILED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &IID_ID2D1Factory, &opt,
                                 (void **)&g_d2d)) || !g_d2d)
        return false;
    if (FAILED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, &IID_IDWriteFactory,
                                   (IUnknown **)&g_dw)) || !g_dw)
        return false;
    return gui_formats_create();
}

static int gui_run(HINSTANCE inst, int show) {
    g_inst = inst;
    h5e_wide_from_utf8_buf(H5E_VERSION, g_version_w, sizeof g_version_w / sizeof g_version_w[0]);
    InitializeCriticalSection(&g_log_cs);
    g_cs_ready = true;

    if (!gui_init_objects()) {
        DeleteCriticalSection(&g_log_cs);
        g_cs_ready = false;
        MessageBoxW(NULL,
                    L"无法初始化 Direct2D / DirectWrite。\n"
                    L"本程序需要 Windows 7 以上并安装平台更新（KB2670838）。\n\n"
                    L"也可以改用命令行：\n"
                    L"  dec_gui.exe <输入.ts|.mp4> <输出.mp4> [--ffmpeg <路径>]",
                    L"cctv_h5e 解密", MB_OK | MB_ICONERROR);
        return H5E_RC_USAGE;
    }

    WNDCLASSEXW wc;
    memset(&wc, 0, sizeof wc);
    wc.cbSize = sizeof wc;
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    wc.lpfnWndProc = gui_wndproc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hIcon = LoadIconW(NULL, IDI_APPLICATION);
    wc.lpszClassName = GUI_CLASS;
    /* 背景刷留空：整个客户区都由 D2D 画，WM_ERASEBKGND 直接返回 1 */
    if (!RegisterClassExW(&wc)) {
        MessageBoxW(NULL, L"注册窗口类失败", L"cctv_h5e 解密", MB_OK | MB_ICONERROR);
        return H5E_RC_USAGE;
    }

    g_dpi = gui_screen_dpi();
    const float s = g_dpi / 96.0f;
    RECT wa;
    if (!SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0)) SetRect(&wa, 0, 0, 1280, 800);
    int pw = (int)(920.0f * s), ph = (int)(640.0f * s);
    const int aw = wa.right - wa.left, ah = wa.bottom - wa.top;
    if (pw > aw) pw = aw;
    if (ph > ah) ph = ah;
    const int px = wa.left + (aw - pw) / 2, py = wa.top + (ah - ph) / 2;

    HWND hwnd = CreateWindowExW(0, GUI_CLASS, L"cctv_h5e 解密 — 输入 → 分片 MP4 → 解密 → MP4",
                                WS_OVERLAPPEDWINDOW, px, py, pw, ph, NULL, NULL, inst, NULL);
    if (!hwnd) {
        MessageBoxW(NULL, L"创建窗口失败", L"cctv_h5e 解密", MB_OK | MB_ICONERROR);
        return H5E_RC_USAGE;
    }
    /* WM_CREATE 里已经按窗口所在显示器修正过 g_dpi */
    ShowWindow(hwnd, show == 0 ? SW_SHOWNORMAL : show);
    UpdateWindow(hwnd);

    gui_status(B_DIM, L"填写路径后点“开始处理”；F2 浏览，Enter 开始，Esc 退出");

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    UnregisterClassW(GUI_CLASS, inst);
    return (int)msg.wParam;
}

/* ============================== 命令行入口 ============================== */

/* GUI 子系统没有自己的控制台：带参数从 cmd/PowerShell 启动时附着到父控制台，
 * 并把 CRT 的 stderr/stdout 重新指过去，否则日志会全部丢掉。 */
static bool gui_attach_console(void) {
    if (!AttachConsole(ATTACH_PARENT_PROCESS)) return false;
    FILE *f = NULL;
    f = freopen("CONOUT$", "w", stderr);
    (void)f;
    f = freopen("CONOUT$", "w", stdout);
    (void)f;
    SetConsoleOutputCP(CP_UTF8);
    return true;
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE prev, LPWSTR cmd, int show) {
    (void)prev;
    (void)cmd;
    int argc = 0;
    wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv) return H5E_RC_USAGE;

    /* 无参数：开窗口。带了参数就一律走命令行，行为与 dec_tui.exe 一致。 */
    if (argc == 1) {
        const int rc = gui_run(inst, show);
        LocalFree(argv);
        return rc;
    }

    const bool con = gui_attach_console();
    int rc = H5E_RC_USAGE;
    const wchar_t *ffmpeg_arg = NULL;
    bool args_ok = (argc >= 3);
    for (int i = 3; args_ok && i < argc; i++) {
        if (wcscmp(argv[i], L"--ffmpeg") == 0 && i + 1 < argc) {
            ffmpeg_arg = argv[++i];
            continue;
        }
        if (wcscmp(argv[i], L"--pid") == 0) {
            /* 已废弃：值丢弃，始终用默认 0x100（中间文件只有一条视频轨） */
            char *u = h5e_utf8_from_wide(argv[i]);
            h5e_logf("警告：%s 已废弃并被忽略，视频 PID 固定为 0x%X\n", u ? u : "--pid",
                     H5E_DEFAULT_VIDEO_PID);
            free(u);
            if (i + 1 < argc) ++i;
            continue;
        }
        char *u = h5e_utf8_from_wide(argv[i]);
        h5e_logf("错误：未知参数 %s\n", u ? u : "?");
        free(u);
        args_ok = false;
    }

    if (!args_ok) {
        h5e_logf(
            "cctv_h5e_decrypt（MP4 流水线 · GUI 版）—— 输入 -> 分片 MP4 -> 解密 -> MP4\n"
            "  %s\n"
            "用法: dec_gui.exe <输入.ts|输入.mp4> <输出.mp4> [--ffmpeg <ffmpeg路径>]\n"
            "      dec_gui.exe（不带任何参数：打开图形界面）\n"
            "说明: 视频 PID 固定使用默认值 0x%X（--pid 已废弃）；路径可含空格与中文\n",
            H5E_VERSION, H5E_DEFAULT_VIDEO_PID);
        if (!con)
            MessageBoxW(NULL,
                        L"用法：dec_gui.exe <输入.ts|.mp4> <输出.mp4> [--ffmpeg <路径>]\n"
                        L"不带参数直接运行则打开图形界面。",
                        L"cctv_h5e 解密", MB_OK | MB_ICONINFORMATION);
        LocalFree(argv);
        return H5E_RC_USAGE;
    }

    rc = h5e_pipeline(argv[1], argv[2], ffmpeg_arg);
    if (!con) {
        wchar_t text[GUI_CAP + 128];
        if (rc == H5E_RC_OK)
            swprintf(text, GUI_CAP + 128, L"处理完成：\n%s", argv[2]);
        else
            swprintf(text, GUI_CAP + 128, L"处理失败（退出码 %d）。\n从命令行启动可看到详细日志。", rc);
        MessageBoxW(NULL, text, L"cctv_h5e 解密",
                    MB_OK | (rc == H5E_RC_OK ? MB_ICONINFORMATION : MB_ICONERROR));
    }
    LocalFree(argv);
    return rc;
}

#endif /* _WIN32 */