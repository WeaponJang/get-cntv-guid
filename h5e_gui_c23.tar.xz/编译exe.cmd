@echo off
chcp 65001 >nul
cls
cd /d "%~dp0"

echo. ======== build dec.exe  (dec.c + lib\cctv_h5e_decrypt.hpp) ========
:: Config. The engine is compiled into the exe on every build: no .a / .dll artifact.
:: NOTE: keep all executable lines ASCII-only; cmd mis-parses UTF-8 batch lines.
set "CC=gcc"
set "CXX=g++"
set "WRES=windres"
set "SRC=dec.c"
set "ENGINE=lib\cctv_h5e_decrypt.hpp"
set "ENGINE_OBJ=lib\cctv_h5e_engine.o"
set "RC=version.rc"
set "EXE=dec.exe"
set "RES=dec.res"

echo. C23 / -Os / LTO / gc-sections for the C side; C++17 -O2 for the engine
echo. -static keeps libstdc++ and winpthread inside the exe (single-file output)
set "COMMON=-std=c23 -Os -s -flto -ffunction-sections -fdata-sections -Wl,--gc-sections -DNDEBUG"
set "ENGINE_FLAGS=-x c++ -std=c++17 -O2 -ffunction-sections -fdata-sections -DCCTV_H5E_IMPLEMENTATION -Wno-pragma-once-outside-header"
set "LIBS=-lstdc++ -lwinpthread -lshell32"
echo. clang: set CC=clang / CXX=clang++ and add --target=x86_64-w64-windows-gnu
echo. ======================================================================

if not exist "%SRC%" (echo. [ERROR] source not found: %SRC% & goto :end)
if not exist "%ENGINE%" (echo. [ERROR] engine not found: %ENGINE% & goto :end)
if not exist "%RC%" (echo. [ERROR] resource not found: %RC% & goto :end)

echo. ======================================================================

echo. [1/3] Engine: %ENGINE% (C++17) -^> %ENGINE_OBJ%
%CXX% %ENGINE_FLAGS% -c "%ENGINE%" -o "%ENGINE_OBJ%" || (echo. [ERROR] engine build failed & goto :end)

echo. [2/3] Version resource (windres)
%WRES% -i "%RC%" -O coff -o "%RES%" -DNDEBUG -DBUILD_TARGET || (echo. [ERROR] windres EXE res failed & goto :end)

echo. [3/3] Build EXE: %EXE%  (from %SRC% + engine + version info)
%CC% %COMMON% -static -o "%EXE%" "%SRC%" "%ENGINE_OBJ%" "%RES%" %LIBS% || (echo. [ERROR] EXE build failed & goto :end)

del /q "%RES%" 2>nul
del /q "%ENGINE_OBJ%" 2>nul

echo. [OK] Done: %EXE%  (with version info)
echo.
echo. Usage: dec.exe ^<encrypted.ts^> ^<out.ts^> [--pid 0x100]

:end
pause
