/* ============================================================================
 * dec.c —— （CCTV hls_h5e 新模式 MPEG-TS 解密 CLI）
 * ============================================================================
 * 解密引擎在 lib\cctv_h5e_decrypt.hpp，编译脚本会把它直接编进 exe（无独立库文件）；
 * 本文件只负责文件读写、分块与 PES 对齐。更新 hpp 后重跑编译脚本即可。
 *
 * 用法：dec.exe <加密.ts> <输出.ts> [--pid 0x100]
 * 编译：gcc -std=c23 -Os -s -flto -ffunction-sections -fdata-sections
 *              -Wl,--gc-sections -DNDEBUG -static -o dec.exe dec.c dec.res
 *              lib\cctv_h5e_engine.o -lstdc++ -lwinpthread -lshell32
 *       （见 编译exe.cmd）
 *
 * 内存：切点取视频 PES 起点，峰值内存与文件总大小无关（目标 32MB/块）。
 * 安全：输出先写 <输出>.part，成功后才原子替换；失败不动目标、不动输入。
 * ========================================================================== */
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <wchar.h>

#if !defined(_WIN32)
/* 非 Windows 平台没有宽字符命令行/文件 API，直接提示退出 */
int main(void) {
    fputs("dec.exe 仅支持 Windows\n", stderr);
    return 1;
}
#else

#ifndef WIN32_LEAN_AND_MEAN
#  define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <shellapi.h> /* CommandLineToArgvW：取宽字符命令行，链接需 -lshell32 */
/* 解密引擎 ABI：实现在 lib\cctv_h5e_decrypt.hpp，编译脚本把它直接编进 exe。
 * 与 hpp 末尾的 extern "C" 段一一对应；hpp 改接口时这里同步改。 */
typedef struct cctv_h5e_session cctv_h5e_session;

cctv_h5e_session *cctv_h5e_session_create(void);
void cctv_h5e_session_destroy(cctv_h5e_session *s);
void cctv_h5e_session_reset(cctv_h5e_session *s);
int cctv_h5e_decrypt_nal(cctv_h5e_session *s, uint8_t *nal, size_t *io_nal_len);
int cctv_h5e_decrypt_ts(cctv_h5e_session *s, uint8_t *ts, size_t ts_len, uint16_t vpid);
int cctv_h5e_decrypt_ts_alloc(const uint8_t *ts_in, size_t ts_len, uint8_t **out_ts,
                              size_t *out_len, uint16_t vpid);
void cctv_h5e_free(void *p);
const char *cctv_h5e_version(void);

#define H5E_VERSION "cctv_h5e pure C23 F5/F1+EPB+AF 2.0.0.0"

/* 缓冲按需扩容：*cap 是当前元素容量，elem 是单元素字节数，need 是所需元素数。
 * 容量从 64 起按 2 倍递增；缓冲只在单个 PES 规模内增长，与块大小无关。
 * 返回 0 成功；-1 为溢出或内存不足，此时原缓冲仍然有效。 */
static int h5e_reserve(void **buf, size_t *cap, size_t need, size_t elem) {
    if (need <= *cap) return 0;
    size_t ncap = *cap ? *cap : 64;
    while (ncap < need) {
        if (ncap > SIZE_MAX / 2) {
            ncap = need;
            break;
        }
        ncap <<= 1;
    }
    if (elem == 0 || ncap > SIZE_MAX / elem) return -1;
    void *p = realloc(*buf, ncap * elem);
    if (!p) return -1;
    *buf = p;
    *cap = ncap;
    return 0;
}

/* ====================== 文件级读写（宽字符 API） ====================== */

/* 分块流式解密：切点取视频 PES 起点，每块解完立即写回。
 * 块大小是目标值而非硬上限（尾块、超长 PES 会多补一片）；会话跨块复用，
 * 结果与整文件一次性处理一致，峰值内存与文件总大小无关。
 * 块大小、补给粒度、对齐与切点规则与 dec.c 完全一致。 */
#define DEC_CHUNK_BYTES ((size_t)32 * 1024 * 1024) /* 目标块大小 */
#define DEC_READ_SLICE  ((size_t)4 * 1024 * 1024)  /* 单次补给粒度 */

/* 把文件指针移到 off（用 size_t 偏移，避开 LONG 只有 32 位） */
static bool dec_seek(HANDLE h, size_t off) {
    LARGE_INTEGER li;
    li.QuadPart = (LONGLONG)off;
    return SetFilePointerEx(h, li, NULL, FILE_BEGIN) != 0;
}

/* 在 off 处读 n 字节到 buf；按 256MB 分片调 ReadFile，避开 DWORD 长度上限 */
static bool dec_read_at(HANDLE h, size_t off, uint8_t *buf, size_t n) {
    if (!dec_seek(h, off)) return false;
    size_t got = 0;
    while (got < n) {
        DWORD want = (DWORD)((n - got) > 0x10000000u ? 0x10000000u : (n - got));
        DWORD read = 0;
        if (!ReadFile(h, buf + got, want, &read, NULL) || read == 0) return false;
        got += read;
    }
    return true;
}

/* 在 off 处写 n 字节；分片规则与 dec_read_at 相同 */
static bool dec_write_at(HANDLE h, size_t off, const uint8_t *data, size_t n) {
    if (!dec_seek(h, off)) return false;
    size_t put = 0;
    while (put < n) {
        DWORD want = (DWORD)((n - put) > 0x10000000u ? 0x10000000u : (n - put));
        DWORD wrote = 0;
        if (!WriteFile(h, data + put, want, &wrote, NULL) || wrote == 0) return false;
        put += wrote;
    }
    return true;
}

/* 前置声明：宽字符转 UTF-8，供错误提示打印路径用 */
static char *dec_utf8_from_wide(const wchar_t *w);

/* 生成临时路径 <输出>.part：与目标同目录，后续改名才是同卷原子重命名 */
static wchar_t *dec_temp_path(const wchar_t *out_path) {
    const size_t len = wcslen(out_path);
    if (len == 0 || len > 32000) return NULL;
    wchar_t *p = (wchar_t *)malloc((len + 8) * sizeof(wchar_t));
    if (!p) return NULL;
    memcpy(p, out_path, (len + 1) * sizeof(wchar_t));
    memcpy(p + len, L".part", 6 * sizeof(wchar_t));
    return p;
}

/* 判断一个 TS 包是否为指定视频 PID 的 PES 起点：同步字节 + PID 匹配 + PUSI 置位 */
static bool dec_is_video_pes_start(const uint8_t *pkt, uint16_t vpid) {
    if (pkt[0] != 0x47) return false;
    if ((uint16_t)(((pkt[1] & 0x1f) << 8) | pkt[2]) != vpid) return false;
    return (pkt[1] & 0x40) != 0;
}

/* 扫描缓冲里的视频 PES 起点，给出首个与最后一个的偏移。
 * 块切点用最后一个起点：这样下一块从完整 PES 开头，跨块不会把 PES 切开。 */
static bool dec_scan_video_pes(const uint8_t *data, size_t len, uint16_t vpid, size_t *first,
                               size_t *last) {
    bool found = false;
    size_t f = 0, l = 0;
    for (size_t off = 0; off + 188 <= len; off += 188) {
        if (!dec_is_video_pes_start(data + off, vpid)) continue;
        if (!found) f = off;
        l = off;
        found = true;
    }
    if (found) {
        if (first) *first = f;
        if (last) *last = l;
    }
    return found;
}

/* 读 → 分块解密 → 写，直到文件尾。
 * 返回 >= 0：写出的字节数；-1 参数错；-2 读失败；-3 解密失败（内存不足或
 * 一个视频 NAL 都没解到）；-4 写失败或最终替换失败。 */
static long long dec_decrypt_file_w(const wchar_t *in_path, const wchar_t *out_path, unsigned vpid,
                                    size_t *bytes_written) {
    if (bytes_written) *bytes_written = 0;
    if (!in_path || !out_path) return -1;

    HANDLE hin = CreateFileW(in_path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hin == INVALID_HANDLE_VALUE) return -2;

    LARGE_INTEGER sz;
    if (!GetFileSizeEx(hin, &sz) || sz.QuadPart < 0) {
        CloseHandle(hin);
        return -2;
    }
    const size_t total = (size_t)sz.QuadPart;

    /* 先写 <输出>.part，成功后再原子替换：中途失败不会毁掉已存在的目标，
     * 输入输出同路径时也不会把原文件改坏（代价是需要额外一份磁盘空间）。 */
    wchar_t *tmp_path = dec_temp_path(out_path);
    if (!tmp_path) {
        CloseHandle(hin);
        return -4;
    }
    HANDLE hout = CreateFileW(tmp_path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL, NULL);
    if (hout == INVALID_HANDLE_VALUE) {
        free(tmp_path);
        CloseHandle(hin);
        return -4;
    }

    cctv_h5e_session *session = cctv_h5e_session_create();
    if (!session) {
        DeleteFileW(tmp_path);
        free(tmp_path);
        CloseHandle(hout);
        CloseHandle(hin);
        return -3;
    }

    uint8_t *buf = NULL;
    size_t cap = 0;  /* buf 的容量 */
    size_t n = 0;    /* buf 中待处理的字节数 */
    size_t base = 0; /* buf[0] 对应的文件偏移 */
    size_t nal_total = 0;
    bool pes_aligned = false; /* 只有 buf[0] 对齐到视频 PES 起点时才解密 */
    bool extra = false;       /* 块内找不到切点时，再多读一片后重试 */
    int rc = 0;

    for (;;) {
        /* 1. 补给：读满目标块（extra 时多读一片），或一直读到文件尾 */
        size_t target = extra ? n + DEC_READ_SLICE : DEC_CHUNK_BYTES;
        extra = false;
        while (n < target && base + n < total) {
            size_t want = target - n;
            if (want > DEC_READ_SLICE) want = DEC_READ_SLICE;
            if (want > total - base - n) want = total - base - n;
            if (h5e_reserve((void **)&buf, &cap, n + want, 1) != 0) {
                rc = -3;
                goto done;
            }
            if (!dec_read_at(hin, base + n, buf + n, want)) {
                rc = -2;
                goto done;
            }
            n += want;
        }
        const bool eof = (base + n >= total);

        size_t first = 0, last = 0;
        const bool found = dec_scan_video_pes(buf, n, (uint16_t)vpid, &first, &last);

        /* 2. 对齐：把 buf[0] 挪到首个视频 PES 起点，否则这块没法解密 */
        if (!pes_aligned) {
            if (found && first > 0) {
                /* 前导的非视频包（PAT/PMT/音频等）原样写出，只跳它们本身，
                 * 然后回到循环开头重新对齐 */
                if (!dec_write_at(hout, base, buf, first)) {
                    rc = -4;
                    goto done;
                }
                base += first;
                n -= first;
                memmove(buf, buf + first, n);
                pes_aligned = true;
                continue;
            }
            if (!found && !eof) {
                extra = true;
                continue;
            }
            pes_aligned = (found && first == 0);
            if (!pes_aligned) {
                /* 直到文件尾都没见到视频 PES：剩下的原样写出（随后按解密失败处理） */
                if (n > 0 && !dec_write_at(hout, base, buf, n)) {
                    rc = -4;
                    goto done;
                }
                base += n;
                n = 0;
                break;
            }
        }

        /* 3. 切点：取块内最后一个视频 PES 起点，保证下一块从完整 PES 开始 */
        size_t chunk_len;
        if (last > 0) {
            chunk_len = last;
        } else if (eof) {
            chunk_len = n; /* 尾块：整段交付，含末尾不足 188 字节的残片 */
        } else {
            /* 整块只含一个 PES 起点（超长 PES）：再补一片重试，让切点落在 PES 边界 */
            extra = true;
            continue;
        }

        /* 4. 解密并顺序写回；会话跨块复用，等价于一次性处理整个文件 */
        if (pes_aligned && chunk_len > 0) {
            const long long nc = cctv_h5e_decrypt_ts(session, buf, chunk_len, (uint16_t)vpid);
            if (nc < 0) {
                rc = -3;
                goto done;
            }
            nal_total += (size_t)nc;
        }
        if (chunk_len > 0 && !dec_write_at(hout, base, buf, chunk_len)) {
            rc = -4;
            goto done;
        }

        base += chunk_len;
        n -= chunk_len;
        if (n > 0) memmove(buf, buf + chunk_len, n);
        if (n == 0 && eof) break;
    }

    /* 一个视频 NAL 都没经过会话：多半是 PID 不对或根本不是 TS。
     * 这种情况按失败处理，绝不产出“看着成功其实是原文”的副本。 */
    if (nal_total == 0) {
        rc = -3;
        goto done;
    }

done:
    cctv_h5e_session_destroy(session);
    free(buf);
    if (rc == 0 && !FlushFileBuffers(hout)) rc = -4;
    CloseHandle(hout);
    CloseHandle(hin);
    if (rc == 0 && !MoveFileExW(tmp_path, out_path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        /* 替换失败（目标被占用、只读等）：成品留在 .part 里，方便手动改名 */
        rc = -4;
        char *keep = dec_utf8_from_wide(tmp_path);
        fprintf(stderr, "replace failed, 成品保留在: %s\n", keep ? keep : "?");
        free(keep);
    } else if (rc != 0) {
        DeleteFileW(tmp_path); /* 失败只删自己的临时文件，目标与输入都不碰 */
    }
    free(tmp_path);
    if (rc != 0) return rc;
    if (bytes_written) *bytes_written = base;
    return (long long)base;
}

/* 宽字符路径转 UTF-8，只为把中文路径打印到控制台 */
static char *dec_utf8_from_wide(const wchar_t *w) {
    if (!w) return NULL;
    int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, NULL, 0, NULL, NULL);
    if (n <= 0) return NULL;
    char *s = (char *)malloc((size_t)n);
    if (!s) return NULL;
    if (WideCharToMultiByte(CP_UTF8, 0, w, -1, s, n, NULL, NULL) <= 0) {
        free(s);
        return NULL;
    }
    return s;
}

/* ============================== 命令行入口 ============================== */

int main(void) {
    /* 控制台切到 UTF-8：源码字串本身是 UTF-8，这样中文提示在任何语言的 Windows 下都不乱码 */
    SetConsoleOutputCP(CP_UTF8);

    int argc = 0;
    wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv || argc < 3) {
        fprintf(stderr,
                "cctv_h5e_decrypt — 纯 C23 hls_h5e MPEG-TS 解密\n"
                "  %s\n"
                "用法: dec.exe <加密.ts> <输出.ts> [--pid 0x100]\n",
                H5E_VERSION);
        if (argv) LocalFree(argv);
        return 1;
    }

    /* 只认 --pid（其余参数忽略），默认 0x100 是 CCTV 视频流的常见 PID */
    unsigned vpid = 0x100;
    for (int i = 3; i < argc; i++) {
        if (wcscmp(argv[i], L"--pid") == 0 && i + 1 < argc)
            vpid = (unsigned)wcstoul(argv[++i], NULL, 0);
    }

    size_t written = 0;
    long long rc = dec_decrypt_file_w(argv[1], argv[2], vpid, &written);
    if (rc >= 0) {
        char *out = dec_utf8_from_wide(argv[2]);
        fprintf(stderr, "ok: %zu bytes -> %s (%s)\n", written, out ? out : "?", H5E_VERSION);
        free(out);
        LocalFree(argv);
        return 0;
    }

    const char *msg = "未知错误";
    switch ((int)rc) {
        case -1: msg = "参数错误"; break;
        case -2: msg = "无法读取输入文件"; break;
        case -3: msg = "解密失败（内存不足 / 未找到视频 PES / PID 不对）"; break;
        case -4: msg = "无法写出输出文件（磁盘空间不足或目标被占用）"; break;
        default: break;
    }
    fprintf(stderr, "decrypt failed rc=%lld (%s)\n", rc, msg);
    LocalFree(argv);
    return 1;
}

#endif /* _WIN32 */
