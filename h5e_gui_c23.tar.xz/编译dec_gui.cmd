@echo off
chcp 65001 >nul
cls
cd /d "%~dp0"

echo. ======== build dec_gui.exe  (dec_gui.c + lib\cctv_h5e_decrypt.hpp) ========
:: Config. The engine is compiled into the exe on every build: no .a / .dll artifact.
:: NOTE: keep all executable lines ASCII-only; cmd mis-parses UTF-8 batch lines.
set "CC=gcc"
set "CXX=g++"
set "WRES=windres"
set "SRC=dec_gui.c"
set "ENGINE=lib\cctv_h5e_decrypt.hpp"
set "ENGINE_OBJ=lib\cctv_h5e_engine.o"
set "RC=version.rc"
set "EXE=dec_gui.exe"
set "RES=dec_gui.res"
set "MANIFEST=dec_gui.manifest"
set "NODEF=_nodefault"

echo. UI: Direct2D + DirectWrite, Windows DLLs only (no third-party runtime)
echo. C23 / -Os / LTO / gc-sections for the C side; C++17 -O2 for the engine
echo. -static keeps libstdc++ and winpthread inside the exe (single-file output)
echo. -municode (wWinMain) -mwindows (no console window on double-click)
set "COMMON=-std=c23 -Os -s -flto -ffunction-sections -fdata-sections -Wl,--gc-sections -DNDEBUG"
set "GUIFLAGS=-municode -mwindows"
set "ENGINE_FLAGS=-x c++ -std=c++17 -O2 -ffunction-sections -fdata-sections -DCCTV_H5E_IMPLEMENTATION -Wno-pragma-once-outside-header"
set "LIBS=-ld2d1 -ldwrite -ldxguid -lole32 -lcomdlg32 -limm32 -lstdc++ -lwinpthread -lshell32 -lgdi32 -luser32"
echo. clang: set CC=clang / CXX=clang++ and add --target=x86_64-w64-windows-gnu
echo. manifest: embedded via BUILD_TARGET_GUI (Per-Monitor V2 DPI + comctl32 v6)
echo. ========================================================================

if not exist "%SRC%" (echo. [ERROR] source not found: %SRC% & goto :end)
if not exist "%ENGINE%" (echo. [ERROR] engine not found: %ENGINE% & goto :end)

echo. [1/3] Engine: %ENGINE% (C++17) -^> %ENGINE_OBJ%
%CXX% %ENGINE_FLAGS% -c "%ENGINE%" -o "%ENGINE_OBJ%" || (echo. [ERROR] engine build failed & goto :end)

set "NOFAKE=-B./%NODEF%/"
if not exist "%NODEF%\default-manifest.o" (
    echo. MinGW-w64 endfile always adds default-manifest.o; an empty stub of the same
    echo. name avoids the .rsrc merge failure when our own manifest is embedded.
    if not exist "%NODEF%" mkdir "%NODEF%"
    %CC% -c -x c -o "%NODEF%\default-manifest.o" nul || (echo. [ERROR] stub object failed & goto :end)
)

if not exist "%RC%" goto :nores
if not exist "%MANIFEST%" goto :nores

echo. [2/3] Version resource + manifest (windres)
%WRES% -i "%RC%" -O coff -o "%RES%" -DNDEBUG -DBUILD_TARGET_GUI || (echo. [ERROR] windres res failed & goto :end)

echo. [3/3] Build EXE: %EXE%  (from %SRC% + engine + version info + manifest)
%CC% %COMMON% -static %GUIFLAGS% %NOFAKE% -o "%EXE%" "%SRC%" "%ENGINE_OBJ%" "%RES%" %LIBS% || (echo. [ERROR] EXE build failed & goto :end)

del /q "%RES%" 2>nul
del /q "%ENGINE_OBJ%" 2>nul
goto :ok

:nores
echo. [2/2] Build EXE: %EXE%  (from %SRC% + engine, no resource/manifest)
%CC% %COMMON% -static %GUIFLAGS% %NOFAKE% -o "%EXE%" "%SRC%" "%ENGINE_OBJ%" %LIBS% || (echo. [ERROR] EXE build failed & goto :end)
del /q "%ENGINE_OBJ%" 2>nul

:ok
echo. [OK] Done: %EXE%
for %%F in ("%EXE%") do echo.      Size: %%~zF bytes
echo.
echo. Pipeline: input -^> ffmpeg fragmented MP4 -^> decrypt -^> ffmpeg MP4
echo. Usage: dec_gui.exe ^<in.ts^|in.mp4^> ^<out.mp4^> [--ffmpeg ^<path^>]
echo.        dec_gui.exe                  (no args: open the GUI, Esc quits)
echo. With args it runs the same command-line pipeline and logs to the console.

:end
pause
