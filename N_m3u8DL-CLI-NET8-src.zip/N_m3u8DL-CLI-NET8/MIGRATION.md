# N_m3u8DL-CLI — .NET 8 移植版说明

原项目 [nilaoda/N_m3u8DL-CLI](https://github.com/nilaoda/N_m3u8DL-CLI)（本仓库 Tontonnow fork 同源）基于 **.NET Framework 4.6**。本目录为移植到 **.NET 8 (LTS)** 的完整工程，保持原有功能与命令行行为不变。

## 一、结论：能不能迁移？

**可以，而且工作量很小。** 该项目主体是纯 C# 的控制台程序，对 .NET Framework 专有 API 的依赖极少，全部都有官方等价替代。真正做了修改的代码只有 5 处（共约 60 行）。

## 二、工程层面的变化

| 项目 | 原 (.NET Framework 4.6) | 现 (.NET 8) |
|---|---|---|
| 工程格式 | 旧式 `csproj`（309 行，显式列出每个文件） | SDK 风格 `csproj`（43 行，自动包含 `*.cs`/`*.resx`） |
| 包管理 | `packages.config` + `packages\` 目录 | `PackageReference` 行内引用 |
| 单文件发布 | Costura.Fody + Fody（IL 织入把 DLL 嵌入 EXE） | 官方 `PublishSingleFile`（见下方发布命令） |
| 版本信息 | `Properties/AssemblyInfo.cs` | `csproj` 内 `<Version>` 等属性 |
| 目标框架 | net46 | `net8.0-windows` |

> 想用 **.NET 6**：把 `N_m3u8DL-CLI.csproj` 里的 `<TargetFramework>net8.0-windows</TargetFramework>` 改成 `net6.0-windows` 即可，代码零改动（.NET 6 于 2024 年 11 月已停止支持，建议仍用 .NET 8 LTS）。

## 三、依赖包的取舍

| NuGet 包 | 处理方式 |
|---|---|
| CommandLineParser 2.8.0 | 升级到 **2.9.1**（新增 netstandard2.0 资产，API 兼容） |
| Newtonsoft.Json 13.0.1 | 升级到 **13.0.3**，原样保留 |
| NiL.JS 2.5.1428 | **原版保留**，其自带 netstandard1.6 资产，.NET 8 可直接使用 |
| HttpToSocks5Proxy 1.4.0 | **原版保留**，其自带 netstandard2.0 资产 |
| BrotliSharpLib 0.3.3 | **删除**，改用 .NET 6/8 内置的 `System.IO.Compression.BrotliStream`（`Global.cs` 中去掉了 `using BrotliSharpLib;`，调用处签名完全相同） |
| UACHelper 1.3.0.5 | **删除**，该库无 netstandard 版本；在 `Program.cs` 中用 ~30 行等价实现替代（`WindowsPrincipal` 判断管理员权限 + `ProcessStartInfo.Verb = "runas"` 提权） |
| TaskScheduler 2.8.7 | **删除**，全工程检索确认从未使用 |
| Costura.Fody / Fody / Resource.Embedder | **删除**，单文件发布由 SDK 自带的 `PublishSingleFile` 替代 |
| System.Runtime.CompilerServices.Unsafe | **删除**，.NET 8 运行时自带 |

## 四、代码修改明细（仅 5 处）

1. **`Global.cs` — GetNum()**
   原 `Microsoft.JScript.GlobalObject.parseInt(str, numBase)`（JScript 引擎在 .NET Core 中不存在）→ `Convert.ToInt32(str, numBase)`，对 0x 前缀十六进制等行为一致。

2. **`Global.cs` — GetUrlFileName()**
   原 `System.Web.HttpUtility.UrlDecode`（System.Web 不再默认提供）→ `System.Net.WebUtility.UrlDecode`，`+` 转空格等行为一致。

3. **`Program.cs` — Main() 中的 TLS 设置（重要，不改会启动崩溃）**
   原代码把 `Ssl3 | Tls(1.0) | Tls11 | Tls12` 写入 `ServicePointManager.SecurityProtocol`。.NET 6/8 中写入 Ssl3/Tls1.0 会直接抛 `NotSupportedException`，程序一启动就崩。已改为 `Tls12 | Tls13`。

4. **`Program.cs` — RequireElevated()**
   UACHelper 库替换为等价的 `IsElevated()` / `StartElevated()` 内置实现（见上文表）。

5. **`Program.cs` — 单文件发布下的自身路径**
   原两处 `Assembly.GetExecutingAssembly().Location`（用于注册 URL 协议和 UAC 重启自身）在 .NET 单文件发布模式下永远返回空字符串，会导致这两个功能失效。新增 `GetExecutablePath()`，优先用 .NET 6+ 新增的 `Environment.ProcessPath`（单文件模式下也能取到真实 exe 路径）。

另外：删除了两个 0 字节的空 Designer 文件（`strings.en-US.Designer.cs`、`strings.zh-TW.Designer.cs`）；`.resx` 多语言资源由 SDK 自动编译为附属程序集（`en-US/`、`zh-TW/` 子目录），原有按系统语言自动切换中/繁/英的机制不变。

## 五、如何编译

需要 [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)（Windows 上开发推荐 VS2022 17.8+）。

```bash
# 普通编译（在解决方案目录下）
dotnet build -c Release

# 单文件发布（等价于原来 Costura 打出的单 EXE，依赖框架，需目标机装 .NET 8 运行时，体积小）
dotnet publish -c Release -r win-x64 --self-contained false /p:PublishSingleFile=true

# 完全独立单 EXE（自带运行时，目标机无需安装任何东西，实测约 69MB）
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true
```

> 目标框架为 `net8.0-windows`（程序用到注册表、UAC 提权、win32 控制台 API），仍面向 Windows。如需要跨平台版本（注册表/UAC 相关功能需按平台裁剪），可再讨论。

## 六、验证情况

- Linux + .NET SDK 8.0.404 下 `Release` 编译通过（**0 错误**，15 个警告全部为原代码固有的代码质量提示，与迁移无关），并完成 `win-x64` 自包含单文件发布（根目录的 `N_m3u8DL-CLI_v3.0.2_net8_win-x64.exe` 即该产物，已验证为有效 PE32+ Windows 可执行文件）。
- .NET 8 程序集在运行时正常加载执行（Linux 上按预期止步于 Windows 专属 kernel32 调用，证明程序集本身可正常加载与 JIT）。
- 仅剩 WebClient 系列的过时提示（`SYSLIB0014`，已在 csproj 中降级为不告警；功能正常，.NET 8 仍完整支持 WebClient）。
- 网络下载 / 解密 / 合并等运行时行为与原版一致（未改动相关逻辑）；建议在 Windows 上做一次真实 m3u8 下载的冒烟测试。
